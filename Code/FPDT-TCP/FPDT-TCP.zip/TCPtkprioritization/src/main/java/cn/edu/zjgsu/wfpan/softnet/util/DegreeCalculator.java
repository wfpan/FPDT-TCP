package cn.edu.zjgsu.wfpan.softnet.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Finding key classes in object-oriented software systems by techniques based on static analysis
 * Ioana Sora, Ciprian-Bogdan Chirila
 * 
 * 输入：.net 格式的加权有向软件网络
 * 输出： 类名、无权入度、无权出度、无权度、加权入度、加权出度、加权度
 * 
 * 边权可以是浮点数
 * 
 * @author wfpan
 * @version 2.0 2016-08-05
 */

public class DegreeCalculator {
	/**
	 * @param srcFile
	 *            软件网络地址：加权有向软件网络
	 * @param destFile
	 *            结果保存地址
	 * @throws Exception
	 */
	public static Map<String, Float> calculateDegree(Path srcFilePath) throws Exception {
		
		if (!Files.isRegularFile(srcFilePath))
			throw new RuntimeException("File " + srcFilePath + " does not exists or is not a regular file");
		
		System.out.println("[SNAP] Calculating degree of methods from the file " + srcFilePath.getFileName().toString());
		
		Map<String, Float> degValue = new HashMap<String, Float>();
		
		int nodeNum; // 软件中的节点数，根据文件读入的内容来初始化

		boolean flag = true;

		/** 读入软件网络文件 .net 格式 */
		FileReader reader = new FileReader(srcFilePath.toFile());
		BufferedReader br = new BufferedReader(reader);

		String paramLine = br.readLine(); // 读取节点所在行

		String[] strNodeNum = paramLine.split(" "); // 读取一行，并分割字符串
		nodeNum = Integer.parseInt(strNodeNum[1]); // 获取节点数

		float[][] link = new float[nodeNum][nodeNum]; // 邻接矩阵：权值为实数

		float[] nodeLinkWeight = new float[nodeNum]; // 根据读入的节点数开辟空间
		float[] nodeLinkWeightOut = new float[nodeNum];
		float[] nodeLinkWeightIn = new float[nodeNum];

		int[] nodeDeg = new int[nodeNum];
		int[] nodeDegIn = new int[nodeNum];
		int[] nodeDegOut = new int[nodeNum];

		for (int i = 0; i < nodeNum; i++) {
			for (int j = 0; j < nodeNum; j++) {
				link[i][j] = 0.0f;
			}
		}

		// 获取节点名
		boolean nameFlag = true; // nameFlag 布尔变量，表示是否正在读入节点名
		boolean isArc = false;
		boolean isWeight = false;
		int iNameIndex = 0; // 名字数组下标计数器
		String[] strNodeName = new String[nodeNum]; // 存储节点的名字

		while (nameFlag) {
			String lineText = br.readLine();
			if (lineText.equals("*Edges")) { // 如果读到的是 Arcs 行
				nameFlag = false;
				continue;
			}

			if (lineText.equals("*Arcs")) { // 如果读到无向网络就报错
				nameFlag = false;
				isArc = true;
				continue;
			}

			// 存储节点名
			String strNameTmp = lineText.substring(lineText.indexOf("\"") + 1,
					lineText.lastIndexOf("\""));
			strNodeName[iNameIndex] = strNameTmp;

			iNameIndex++;
		}

		/** 构造邻接矩阵 */
		while (flag) {
			String lineText = br.readLine(); // 读取 Arcs or Edges下的一行
			if (null == lineText) { // 未读到文件尾或最后一个空行
				flag = false;
				continue;
			} else if (lineText.matches("\\s+")) {
				flag = false;
				continue;
			}

			String[] s = lineText.split(" "); // 读取连接的两个节点数值

			if (3 == s.length && !isArc) { // 加权无向版本
				System.out.println("加权无向网络，不符合要求，必须输入加权有向网络");
				isWeight = true;
				link[new Integer(s[0]).intValue() - 1][new Integer(s[1])
						.intValue() - 1] = Float.parseFloat(s[2]);
				link[new Integer(s[1]).intValue() - 1][new Integer(s[0])
						.intValue() - 1] = Float.parseFloat(s[2]);
				System.exit(0);
			} else if (3 == s.length && isArc) { // 加权有向版本
				isWeight = true;
//				System.out.println("加权有向网络");
				link[new Integer(s[0]).intValue() - 1][new Integer(s[1])
						.intValue() - 1] = Float.parseFloat(s[2]);
			} else if (2 == s.length && !isArc) { // 无权无向版本
				System.out.println("无权无向网络，不符合要求，必须输入加权有向网络");
				link[new Integer(s[0]).intValue() - 1][new Integer(s[1])
						.intValue() - 1] = 1;
				link[new Integer(s[1]).intValue() - 1][new Integer(s[0])
						.intValue() - 1] = 1;
				System.exit(0);
			} else if (2 == s.length) { // 无权有向版本
				System.out.println("无权有向网络，不符合要求，必须输入加权有向网络");
				link[new Integer(s[0]).intValue() - 1][new Integer(s[1])
						.intValue() - 1] = 1;
				System.exit(0);
			} else {
				System.out.println("不是一个有效的网络");
				System.exit(0);
			}
		}

		br.close(); // 关闭流
		reader.close(); // 关闭文件

		if (isArc) { // 有向网络
			for (int i = 0; i < nodeNum; i++) {
				float linkWeightOut = 0.0f;
				float linkWeightIn = 0.0f;

				int deg = 0; // 边数
				int degOut = 0;
				int degIn = 0;

				for (int j = 0; j < nodeNum; j++) {
					// if (Math.abs(link[i][j] - 0.0f) >= 0.0000001) {
					if (Float.compare(link[i][j], 0.0f) > 0) {
						linkWeightOut += link[i][j]; // 出边权和
						++degOut;
					}
					// if (Math.abs(link[j][i] - 0.0f) >= 0.0000001) {
					if (Float.compare(link[j][i], 0.0f) > 0) {
						linkWeightIn += link[j][i]; // 入边权和
						++degIn;
					}
					// if (Math.abs(link[i][j] - 0.0f) >= 0.0000001
					// || Math.abs(link[j][i] - 0.0f) >= 0.0000001) {
					if (Float.compare(link[i][j], 0.0f) > 0
							|| Float.compare(link[j][i], 0.0f) > 0) {
						++deg; // 忽略出、入，只统计一次
					}
				}
				// 加权的处理
				nodeLinkWeightOut[i] = linkWeightOut;
				nodeLinkWeightIn[i] = linkWeightIn;
				nodeLinkWeight[i] = linkWeightOut + linkWeightIn;
				// 无权的处理
				nodeDegOut[i] = degOut;
				nodeDegIn[i] = degIn;
				nodeDeg[i] = degOut + degIn;
			}

		} else {
			for (int i = 0; i < nodeNum; i++) {
				float linkWeight = 0.0f; // 出边
				int deg = 0; // 边数

				for (int j = 0; j < nodeNum; j++) {
					if (Math.abs(link[i][j] - 0.0f) >= 0.0000001) {
						linkWeight += link[i][j]; // 出边权和
						++deg;
					}
				}
				nodeLinkWeight[i] = linkWeight;
				nodeDeg[i] = deg;
			}

		}
		
		float maxDegOut = -1.f;
		float minDegOut = 100.f;
		for(int tmp2 = 0; tmp2 < nodeNum; tmp2++) {
			if(nodeDegOut[tmp2]>maxDegOut) {
				maxDegOut = nodeDegOut[tmp2];
			}
			if(nodeDegOut[tmp2]<minDegOut) {
				minDegOut = nodeDegOut[tmp2];
			}
		}

		String orig = null;
		for (int iTmp = 0; iTmp < nodeNum; iTmp++) {
			orig = SignatureFormatter.convertMethodNameSN(strNodeName[iTmp]);
			if(degValue.containsKey(strNodeName[iTmp])) {
				System.err.println(strNodeName[iTmp] + " 已经在 kcValue Map 中了");
			} else {
				degValue.put(orig, (nodeDegOut[iTmp]*1.f-minDegOut)/(maxDegOut-minDegOut));
			}
		}

		System.out.println("[SNAP] Terminate the calculation of the degree of methods");
		return degValue;
	}
}