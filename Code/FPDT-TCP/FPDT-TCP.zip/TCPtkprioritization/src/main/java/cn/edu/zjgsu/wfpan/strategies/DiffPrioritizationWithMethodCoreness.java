package cn.edu.zjgsu.wfpan.strategies;

import it.unina.dieti.tkprio.domain.*;
import it.unina.dieti.tkprio.io.ASTGenerator;
import it.unina.dieti.tkprio.io.CloverCoverageParser;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.MethodMatcher;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.edu.zjgsu.wfpan.softnet.util.GeneralizedCoreness;
import cn.edu.zjgsu.wfpan.softnet.util.SignatureFormatter;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 1. 融入方法的G-Core值
 * */
public class DiffPrioritizationWithMethodCoreness implements PrioritizationStrategyI {

	private final static Logger LOG = LoggerFactory.getLogger(DiffPrioritizationWithMethodCoreness.class);

	private static final String NAME = "diff-GC";

	private Path coverageReportPath;
	private List<Path> previousSources;
	private List<Path> currentSources;

	private CoverageReport coverageReport;
	private MethodSet previousMethods;
	private MethodSet currentMethods;
	
	private Path softwareNetworkPath; //1/4:软件网络文件

	@Override
	public String name() {
		return NAME;
	}

	@Override
	public void setUp(StrategyPaths paths) {
		this.coverageReportPath = paths.getPreviousCoveragePath();
		this.currentSources = paths.getCurrentSources();
		this.previousSources = paths.getPreviousSources();
		
		this.softwareNetworkPath = paths.getSoftwareNetworkPath(); //2/4:增加自己的
	}

	@Override
	public Permutation prioritize(TestSuite suite) {
		this.init();
		suite.mergeWithCoverage(this.coverageReport);

		List<Pair<Method, Method>> matching = MethodMatcher.createMethodMatching(this.previousMethods,
				this.currentMethods);
		Map<String, Boolean> changed = this.getChangedMap(matching);
		
		// 3/4
		Map<String, Float> gcValue = null;
		try {
			gcValue = GeneralizedCoreness.calculateGeneralizedCorenss(this.softwareNetworkPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		// Scoring test cases
		for (Test test : suite) {
			float score = 0f;
			for (Method covered : test.getCoveredMethods()) {
				if (changed.containsKey(covered.getSignature())) {
//					score++;
					if(gcValue.containsKey(SignatureFormatter.convertMethodName(covered.getSignature()))) {
						// 4/4
						score += 1 * gcValue.get(SignatureFormatter.convertMethodName(covered.getSignature()));
						//修改这里*方法的Generalized coreness
//						System.out.println("score = " + score);
					} else {
						System.err.println(covered.getSignature().trim()+" 不在软件网络中");
						System.err.println(SignatureFormatter.convertMethodName(covered.getSignature().trim()).trim()+" 不在软件网络中");
						System.exit(0);
					}
				}
			}
			test.setScore(score);
		}
		Permutation permutation = new Permutation(suite);
		// Sorting the test cases by score in descending order
		permutation.getTests().sort((t1, t2) -> Float.compare(t2.getScore(), t1.getScore()));
		return permutation;
	}

	/**
	 * Initializes data for the prioritization.
	 */
	private void init() {
		if (this.coverageReport == null)
			this.loadCoverage();
		if (this.currentMethods == null)
			this.currentMethods = this.loadMethods(this.currentSources);
		if (this.previousMethods == null)
			this.previousMethods = this.loadMethods(this.previousSources);
	}

	private void loadCoverage() {
		LOG.info("Loading coverage report");
		CloverCoverageParser parser = new CloverCoverageParser();
		this.coverageReport = parser.parse(this.coverageReportPath);
	}

	private MethodSet loadMethods(List<Path> sources) {
		MethodSet globalMethodSet = new MethodSet();
		// Generating the methods for all source files and merging all together
		ASTGenerator generator = new ASTGenerator();
		for (Path source : sources) {
			MethodSet sourceMethodSet = generator.generateFromSource(source, false); // No ASTs creation
			globalMethodSet.merge(sourceMethodSet);
		}
		return globalMethodSet;
	}

	/**
	 * Creates the map of changed methods with key equals to the method's signature
	 * and value as a boolean stating if the method has changed (true) or is
	 * unchanged (false).
	 *
	 * @param matching The method matching
	 * @return The map of changed methods by their signature
	 */
	private Map<String, Boolean> getChangedMap(List<Pair<Method, Method>> matching) {
		Map<String, Boolean> changed = new HashMap<>();
		for (Pair<Method, Method> pair : matching) {
			Method previous = pair.getLeft();
			Method current = pair.getRight();
			// Ensuring methods are not abstract
			if (previous.getBody() != null && current.getBody() != null) {
				boolean methodChanged = !previous.getBody().equals(current.getBody());
				changed.put(previous.getSignature(), methodChanged);
			}
		}
		return changed;
	}

}
