package cn.edu.zjgsu.wfpan.softnet.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class ReadMethodBuggyProb {
	private static float max;
	private static float min;
	
	public static void getMaxMin(Path txtFilePath) throws IOException {
		max = 0.f;
		min = 0.f;

		if (!Files.isRegularFile(txtFilePath))
			throw new RuntimeException("File " + txtFilePath + " does not exists or is not a regular file");

		System.out.println(
				"[SNAP] reading method buggy probability values from the file " + txtFilePath.getFileName().toString());

		Map<String, Float> result = new LinkedHashMap<>(); // 保持顺序

		try (BufferedReader br = new BufferedReader(new FileReader(txtFilePath.toFile()))) {
			// 1. 读标题行
//            String titleLine = br.readLine();
//            if (titleLine == null) {
//                throw new IOException("TXT 文件为空");
//            }
//
//            // 按逗号切分，取第 3 个部分
//            String[] titleParts = titleLine.split("##", -1);
//            if (titleParts.length < 2) {
//                throw new IOException("数据行不足 2 列");
//            }
//            float headerValue = Float.parseFloat(titleParts[2].trim());
//            result.put("defaultCogValueForZero", headerValue);
			// 如果你想把标题行的这个值也存进去，可自定义 key；示例里先忽略

			// 2. 读后续数据行
			String line;
			while ((line = br.readLine()) != null) {
				if (line.trim().isEmpty()) {
					continue; // 跳过空行
				}
				String[] parts = line.split("##", -1);
				if (parts.length < 2) {
					throw new IOException("数据行不足 2 列: " + line);
				}
				String key = parts[0].trim();
				float value = Float.parseFloat(parts[1].trim());
				

				// 不直接放，名字修改后放入
//              result.put(key, value);
//                String orig = SignatureFormatter.convertMethodNameSN(key);
				// 转为 software network中类似的格式，没有返回值
				if (key.contains(".(")) {
					continue;
				}
				
				if(value > max) {
					max = value;
				}
				if(value<min) {
					min = value;
				}
			}
		}
	}

	/**
	 * 解析指定格式的 CSV 文件
	 *
	 * @param csvPath 文件路径
	 * @return Map<String, Float> key = 字符串字段, value = float 字段
	 * @throws IOException 读取文件异常
	 */
	public static Map<String, Float> parseTxt(Path txtFilePath) throws IOException {

		if (!Files.isRegularFile(txtFilePath))
			throw new RuntimeException("File " + txtFilePath + " does not exists or is not a regular file");

		System.out.println(
				"[SNAP] reading method buggy probability values from the file " + txtFilePath.getFileName().toString());

		getMaxMin(txtFilePath);
		
		Map<String, Float> result = new LinkedHashMap<>(); // 保持顺序

		try (BufferedReader br = new BufferedReader(new FileReader(txtFilePath.toFile()))) {
			// 1. 读标题行
//            String titleLine = br.readLine();
//            if (titleLine == null) {
//                throw new IOException("TXT 文件为空");
//            }
//
//            // 按逗号切分，取第 3 个部分
//            String[] titleParts = titleLine.split("##", -1);
//            if (titleParts.length < 2) {
//                throw new IOException("数据行不足 2 列");
//            }
//            float headerValue = Float.parseFloat(titleParts[2].trim());
//            result.put("defaultCogValueForZero", headerValue);
			// 如果你想把标题行的这个值也存进去，可自定义 key；示例里先忽略

			// 2. 读后续数据行
			String line;
			while ((line = br.readLine()) != null) {
				if (line.trim().isEmpty()) {
					continue; // 跳过空行
				}
				String[] parts = line.split("##", -1);
				if (parts.length < 2) {
					throw new IOException("数据行不足 2 列: " + line);
				}
				String key = parts[0].trim();
				float value = Float.parseFloat(parts[1].trim());
				
				value = (value-min)/(max-min);

				// 不直接放，名字修改后放入
//              result.put(key, value);
//                String orig = SignatureFormatter.convertMethodNameSN(key);
				// 转为 software network中类似的格式，没有返回值
				if (key.contains(".(")) {
					continue;
				}
				System.out.println("before " + key);
				
				//<init>
				key = key.replace("<? extends java.lang.annotation.Annotation>...", "").replace("...", "");
				key = key.replace("<init>", "init");
				key = key.replace("$(", "(");
				key = key.replace("$",".");
//                System.out.println(BuggyMethodNameParser.parse(key));
				String orig = BuggyMethodNameParser.parse(key).toString();
				System.out.println("after " + orig);

				if (key.startsWith(
						"org.assertj.core.internal.Classes.assertIsAssignableFrom(org.assertj.core.api.AssertionInfo")) {
//					System.exit(0);
				}

				if (result.containsKey(orig)) {
					System.err.println(orig + " 已经在 buggyValue Map 中了");
//					System.exit(0);
					if (value > result.get(orig)) {
						result.put(orig, value);
					}
				} else {
//					prValue.put(strNodeName[iTmp], (float)fPageRankBak[iTmp]);
					result.put(orig, value);
//					if("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String".equals(strNodeName[iTmp])) {
//						System.err.println("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String" + "\n" + orig);
//					}
				}

			}
		}

		return result;
	}

	public static Map<String, Float> parseBuggyMethodsTxt(Path buggyMethodsTxt) throws IOException {

		if (!Files.isRegularFile(buggyMethodsTxt))
			throw new RuntimeException("File " + buggyMethodsTxt + " does not exists or is not a regular file");

		System.out
				.println("[SNAP] reading buggy method list from the file " + buggyMethodsTxt.getFileName().toString());

		Map<String, Float> result = new LinkedHashMap<>(); // 保持顺序

		try (BufferedReader br = new BufferedReader(new FileReader(buggyMethodsTxt.toFile()))) {
			// 1. 读标题行
			String titleLine = br.readLine();
			if (titleLine == null) {
				throw new IOException("TXT 文件为空");
			}

			// 按逗号切分，取第 3 个部分
			String[] titleParts = titleLine.split("##", -1);
			if (titleParts.length < 6) {
				throw new IOException("数据行不足 6 列");
			}
//            float headerValue = Float.parseFloat(titleParts[2].trim());
//            result.put("defaultCogValueForZero", headerValue);
			// 如果你想把标题行的这个值也存进去，可自定义 key；示例里先忽略

			// 2. 读后续数据行
			String line;
			while ((line = br.readLine()) != null) {
				if (line.trim().isEmpty()) {
					continue; // 跳过空行
				}
				String[] parts = line.split("##", -1);
				if (parts.length < 6) {
					throw new IOException("数据行不足 6 列: " + line);
				}
				String key = parts[0].trim();
				float value = Float.parseFloat(parts[parts.length - 1].trim());

				// 不直接放，名字修改后放入
//              result.put(key, value);
//                String orig = SignatureFormatter.convertMethodNameSN(key);
				// 转为 software network中类似的格式，没有返回值
				if (key.contains(".(")) {
					continue;
				}

				System.out.println(BuggyMethodNameParser.parse(key));
				String orig = BuggyMethodNameParser.parse(key).toString();

				if (result.containsKey(orig)) {
					System.err.println(orig + " 已经在 buggyValue Map 中了");
					if (value > result.get(orig)) {
						result.put(orig, value);
					}
				} else {
//					prValue.put(strNodeName[iTmp], (float)fPageRankBak[iTmp]);
					result.put(orig, value);
//					if("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String".equals(strNodeName[iTmp])) {
//						System.err.println("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String" + "\n" + orig);
//					}
				}

			}
		}

		return result;
	}

	// 简单测试
	public static void main(String[] args) throws IOException {
		Path p = Path.of(
				"D:\\E-Code\\OU-JavaCourse\\Dataset\\Projects\\assertj\\eee3ad92ce3ba261cd99435254b0c8574711f5b8\\bugPredictions.txt");
		parseTxt(p);
//        try {
//            Map<String, Float> map = parseCsv("D:\\E-Code\\OU-JavaCourse\\Dataset\\Projects\\assertj\\0f78d7e2ccbeb7bb39ebc5f0510ba84df7c52a5a\\methodCogValue.csv");
//            map.forEach((k, v) -> System.out.println(k + " -> " + v));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
	}
}
