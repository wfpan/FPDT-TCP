package cn.edu.zjgsu.wfpan.softnet.util;

import java.util.*;
import java.util.stream.Collectors;

public final class PrNormalizer {

    /**
     * Min-Max 标准化：value -> (value - min) / (max - min)
     * 若所有值相同，则统一返回 0。
     */
    public static Map<String, Float> normalize(Map<String, Float> prValue) {
        if (prValue == null || prValue.isEmpty()) {
            return Collections.emptyMap();
        }

        // 统一用 double 计算，避免 float 精度误差
        double min = prValue.values()
                            .stream()
                            .mapToDouble(Float::doubleValue)
                            .min()
                            .orElse(0.0);

        double max = prValue.values()
                            .stream()
                            .mapToDouble(Float::doubleValue)
                            .max()
                            .orElse(0.0);

        double range = max - min;

        // 绝对误差阈值：1 e-9（可按需要调）
        if (Math.abs(range) < 1e-9) {
            return prValue.keySet()
                          .stream()
                          .collect(Collectors.toMap(k -> k, k -> 0.0f));
        }

        return prValue.entrySet()
                      .stream()
                      .collect(Collectors.toMap(
                              Map.Entry::getKey,
                              e -> (float) ((e.getValue() - min) / range)
                      ));
    }

    /* 演示 */
    public static void main(String[] args) {
        Map<String, Float> prValue = Map.of(
                "com.foo.Controller.handle", 1f,
                "com.foo.Service.process",     3f,
                "com.foo.Util.helper",         2f
        );

        Map<String, Float> normalized = normalize(prValue);
        normalized.forEach((k, v) -> System.out.printf("%s : %.6f%n", k, v));
    }
}
