package cn.edu.zjgsu.wfpan.strategies.helpers;

import java.util.List;

import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDF2;
import it.unina.dieti.tkprio.domain.Method;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.rtp.strategies.helpers.QSSelectorI;

/**
 * TotalIDFCoverageSelector2
 * 覆盖的方法个数越多、方法累加IDF越大，越优先
 * TotalIDFCoverageSelector2跟TotalIDFCoverageSelector相比：这里考虑的是累加IDF，那边考虑的是最大IDF
 * 这里使用的是 selectStrategyV 的策略：覆盖的方法越多、方法的累积IDF越大，越优先选择
 * */
public class TotalIDFCoverageSelector2 implements QSSelectorI {
	
	//原始的
	public Test selectStrategyI(List<Test> equivalenceClass) {
		Test selected = null;
		int maxCovered = -1;
		for (Test test : equivalenceClass) {
			int covered = test.getCoveredMethods().size();
			if (covered > maxCovered) {
				selected = test;
				maxCovered = covered;
			}
		}
		return selected;
	}
	
	public Test selectStrategyII(List<Test> equivalenceClass) {
		Test selected = null;
		List<Method> mList = null;
		float sumIDF = 0.f;
		float maxSumIDF = -1.f;
		float diSim = 0.f;

		int maxCnt = -1;
		int minCnt = 1000;
		int cnt = 0;
		for (Test test : equivalenceClass) {
			cnt = test.getCoveredMethods().size();
			if(cnt > maxCnt) {
				maxCnt = cnt;
			}
			if(cnt<minCnt) {
				minCnt = cnt;
			}
		}
		
		for (Test test : equivalenceClass) {
			sumIDF = 0.f;
			mList = test.getCoveredMethods();
			//考虑 IDF
			for (Method m : mList) {
				if (MTKPrioritizationWithMethodCognitiveIDF2.similarities.containsKey(m.getSignature())) {
//					diSim = (1 - MTKPrioritizationWithMethodCognitiveIDF2.similarities.get(m.getSignature()));
//					sumIDF += diSim * MTKPrioritizationWithMethodCognitiveIDF2.methodIDF.get(m.getSignature());
				sumIDF += MTKPrioritizationWithMethodCognitiveIDF2.methodIDF.get(m.getSignature());
//					if(diSim>0) {
//						cnt++;
//					}
				}
			}
			//考虑有几个变了
			if(maxCnt!=minCnt) {
				sumIDF = sumIDF * ((mList.size()-minCnt)/(maxCnt-minCnt));
			}
			
			if (sumIDF > maxSumIDF) {
				selected = test;
				maxSumIDF = sumIDF;
			}
		}
		return selected;
	}
	
	public Test selectStrategyIII(List<Test> equivalenceClass) {
		Test selected = null;
		List<Method> mList = null;

		double maxIDF = -1.d;
		double tmpIDF = 0.f;
		double newScore = 0.d;
		double maxScore = -1.d;
		
		for (Test test : equivalenceClass) {
			mList = test.getCoveredMethods();
			
			for (Method m : mList) {
				tmpIDF = MTKPrioritizationWithMethodCognitiveIDF2.methodIDF.get(m.getSignature());
				if (tmpIDF > maxIDF) {
					maxIDF = tmpIDF;
				}
			}
			
			newScore = test.getScore()*maxIDF;
			
			if (newScore > maxScore) {
				selected = test;
				maxScore = newScore;
			}
		}
		return selected;
	}
	
	public Test selectStrategyIV(List<Test> equivalenceClass) {
		Test selected = null;
		List<Method> mList = null;

		double maxIDF = -1.d;
		double tmpIDF = 0.f;
		double newScore = 0.d;
		double maxScore = -1.d;
		
		int maxCnt = -1;
		int minCnt = 1000;
		int cnt = 0;
		for (Test test : equivalenceClass) {
			cnt = test.getCoveredMethods().size();
			if(cnt > maxCnt) {
				maxCnt = cnt;
			}
			if(cnt<minCnt) {
				minCnt = cnt;
			}
		}
		
		for (Test test : equivalenceClass) {
			mList = test.getCoveredMethods();
			
			for (Method m : mList) {
				tmpIDF = MTKPrioritizationWithMethodCognitiveIDF2.methodIDF.get(m.getSignature());
				if (tmpIDF > maxIDF) {
					maxIDF = tmpIDF;
				}
			}
			
//			newScore = mList.size()*maxIDF;
			//覆盖的方法个数多一点、IDF大一点的用例被优先选择
			if(maxCnt!=minCnt) {
				newScore = (mList.size()-minCnt)/(maxCnt-minCnt)*maxIDF;
//				System.out.println("不相等");
//				System.exit(0);
			} else {
				newScore = (mList.size())/(maxCnt)*maxIDF;
			}
			
			if (newScore > maxScore) {
				selected = test;
				maxScore = newScore;
			}
		}
		return selected;
	}
	
	public static boolean isEqual(double a, double b) {
	    final double EPS = 1e-10;          // 根据业务调整精度
	    return Math.abs(a - b) < EPS;
	}

	/**覆盖的方法个数越多、方法累加IDF越大，越优先*/
	public Test selectStrategyV(List<Test> equivalenceClass) {
		Test selected = null;
		List<Method> mList = null;

		double maxSumIDF = -1.d;
		double minSumIDF = 100.d;
		double tmpIDF = 0.f;
		double newScore = 0.d;
		double maxScore = -1.d;
		
		int maxCnt = -1;
		int minCnt = 1000;
		int cnt = 0;
		for (Test test : equivalenceClass) {
			cnt = test.getCoveredMethods().size();
			if(cnt > maxCnt) {
				maxCnt = cnt;
			}
			if(cnt<minCnt) {
				minCnt = cnt;
			}
		}
		
		double sumIDF = 0.d;
		
		for (Test test : equivalenceClass) {
			mList = test.getCoveredMethods();

			for (Method m : mList) {
				tmpIDF = MTKPrioritizationWithMethodCognitiveIDF2.methodIDF.get(m.getSignature());
				sumIDF += tmpIDF;
			}
			
			if(sumIDF > maxSumIDF) {
				maxSumIDF = sumIDF;
			}
			if(sumIDF < minSumIDF) {
				minSumIDF = sumIDF;
			}
			sumIDF = 0.d;
		}
		
		sumIDF = 0.d;
		for (Test test : equivalenceClass) {
			mList = test.getCoveredMethods();
			
			for (Method m : mList) {
				tmpIDF = MTKPrioritizationWithMethodCognitiveIDF2.methodIDF.get(m.getSignature());
				sumIDF += tmpIDF;
			}
			//覆盖的方法个数多一点、IDF大一点的用例被优先选择
			if(maxCnt!=minCnt) {
				if(!isEqual(maxSumIDF, minSumIDF)) {
					newScore = ((mList.size()-minCnt)/(maxCnt-minCnt))*((sumIDF-minSumIDF)/(maxSumIDF-minSumIDF));
				} else {
					newScore = ((mList.size()-minCnt)/(maxCnt-minCnt))*(sumIDF/maxSumIDF);
				}
//				System.out.println("不相等");
//				System.exit(0);
			} else {
				if(!isEqual(maxSumIDF, minSumIDF)) {
					newScore = ((mList.size())/(maxCnt))*((sumIDF-minSumIDF)/(maxSumIDF-minSumIDF));
				} else {
					newScore = ((mList.size())/(maxCnt))*(sumIDF/maxSumIDF);
				}
				
			}
			
			if (newScore > maxScore) {
				selected = test;
				maxScore = newScore;
			}
			sumIDF = 0.d;
		}
		return selected;
	}

	@Override
	public Test select(List<Test> equivalenceClass) {
		return selectStrategyV(equivalenceClass);
//		if(!QuotientSetIDFPrioritization.bIDF) {
//			return selectStrategyI(equivalenceClass);
//		} else {
//			return selectStrategyII(equivalenceClass);
//		}
	}
}
