package cn.edu.zjgsu.wfpan.strategies;

import it.unina.dieti.tkprio.ast.ASTRepresentation;
import it.unina.dieti.tkprio.domain.*;
import it.unina.dieti.tkprio.io.ASTGenerator;
import it.unina.dieti.tkprio.io.CloverCoverageParser;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import it.uniroma2.sag.kelp.kernel.tree.PartialTreeKernel;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.edu.zjgsu.wfpan.softnet.util.ClassRank;
import cn.edu.zjgsu.wfpan.softnet.util.GeneralizedCoreness;
import cn.edu.zjgsu.wfpan.softnet.util.SignatureFormatter;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static it.unina.dieti.tkprio.rtp.strategies.helpers.MethodMatcher.createMethodMatching;

/**
 * 1.这里可以融入方法的G-Core
 * */
public class MTKPrioritizationWithMethodCoreness implements PrioritizationStrategyI {

	private static final Logger LOG = LoggerFactory.getLogger(MTKPrioritizationWithMethodCoreness.class);

	public static final String NAME = "MTK-GC"; //自己的方法的名字

	private Path coverageReportPath;
	private List<Path> previousSources;
	private List<Path> currentSources;

	private MethodSet previousMethods;
	private MethodSet currentMethods;
	private CoverageReport coverageReport;
	
	private Path softwareNetworkPath; //软件网络文件

	private final PartialTreeKernel ptk = new PartialTreeKernel(.7f, .4f, 1f, "0");

	@Override
	public String name() {
		return NAME;
	}

	@Override
	public void setUp(StrategyPaths paths) {
		this.coverageReportPath = paths.getPreviousCoveragePath();
		this.currentSources = paths.getCurrentSources();
		this.previousSources = paths.getPreviousSources();
		this.softwareNetworkPath = paths.getSoftwareNetworkPath(); //增加自己的
	}

	/**这里排的是 previous 和 current 公共部分的 test case
	 * 可以理解为：在previous版本中的执行的用例
	 * */
	@Override
	public Permutation prioritize(TestSuite suite) {
		//Initializes data for the prioritization, including coverageReport, currentMethods, and previousMethods.
		this.init();
		suite.mergeWithCoverage(this.coverageReport);
		List<Pair<Method, Method>> matching = createMethodMatching(this.previousMethods, this.currentMethods);
		// Evaluating methods' similarity
		Map<String, Float> similarities = this.getSimilarityMap(matching);
		
		Map<String, Float> gcValue = null;
		try {
			gcValue = GeneralizedCoreness.calculateGeneralizedCorenss(this.softwareNetworkPath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Scoring test cases
		for (Test test : suite) {
			float score = 0f;
			for (Method covered : test.getCoveredMethods()) {
				if (similarities.containsKey(covered.getSignature())) {
					if(gcValue.containsKey(SignatureFormatter.convertMethodName(covered.getSignature()))) {
						score += (1 - similarities.get(covered.getSignature()))
								*gcValue.get(SignatureFormatter.convertMethodName(covered.getSignature()));
						//修改这里*方法的Generalized coreness
//						System.out.println("score = " + score);
					} else {
						System.err.println(covered.getSignature().trim()+" 不在软件网络中");
						System.err.println(SignatureFormatter.convertMethodName(covered.getSignature().trim()).trim()+" 不在软件网络中");
						System.exit(0);
					}
				}
			}
			test.setScore(score);
		}
		
/*		//Scoring test cases 原来的版本
		for (Test test : suite) {
			float score = 0f;
			for (Method covered : test.getCoveredMethods()) {
				if (similarities.containsKey(covered.getSignature())) {
					
					if(prValue.containsKey(covered.getSignature()))
					
					score += (1 - similarities.get(covered.getSignature()));//修改这里*方法重要性
				}
			test.setScore(score);
			}
		}
*/		
		Permutation permutation = new Permutation(suite);
		// Sorting the test cases by score in descending order
		permutation.getTests().sort((t1, t2) -> Float.compare(t2.getScore(), t1.getScore()));
		return permutation;
	}

	/**
	 * Initializes data for the prioritization, including coverageReport,
	 * currentMethods, and previousMethods.
	 * 
	 */
	private void init() {
		if (this.coverageReport == null)
			this.loadCoverage();
		if (this.currentMethods == null)
			this.currentMethods = this.loadMethods(this.currentSources);
		if (this.previousMethods == null)
			this.previousMethods = this.loadMethods(this.previousSources);
	}

	private void loadCoverage() {
		LOG.info("Loading coverage report");
		CloverCoverageParser parser = new CloverCoverageParser();
		this.coverageReport = parser.parse(this.coverageReportPath);
	}

	/**
	 * 这里设置method的各种特性，包括其AST ASTs are created
	 */
	private MethodSet loadMethods(List<Path> sources) {
		MethodSet globalMethodSet = new MethodSet();
		// Generating the methods for all source files and merging all together
		ASTGenerator generator = new ASTGenerator();
		for (Path source : sources) {
			MethodSet sourceMethodSet = generator.generateFromSource(source, true); // ASTs are created
			globalMethodSet.merge(sourceMethodSet);
		}
		return globalMethodSet;
	}

	private Map<String, Float> getSimilarityMap(List<Pair<Method, Method>> matching) {
		Map<String, Float> similarities = new HashMap<>();
		for (Pair<Method, Method> pair : matching) {
			Method previous = pair.getLeft();
			Method current = pair.getRight();
			// Avoids comparing abstract methods and unchanged methods
			if (previous.getAst() != null && current.getAst() != null
					&& !previous.getBody().equals(current.getBody())) {
				// Evaluating PTK and adding the similarity
				float sim = this.normalizedPtk(previous.getAst(), current.getAst());
				//the sim is set to the previous method as we calculate the score on the previous project
				similarities.put(previous.getSignature(), sim);
//				System.out.println("方法名是: " + previous.getSignature());
//				System.exit(0);
			}
		}
		return similarities;
	}

	private float normalizedPtk(ASTRepresentation previous, ASTRepresentation current) {
		float xx = this.ptk.kernelComputation(previous, previous);
		float yy = this.ptk.kernelComputation(current, current);
		float xy = this.ptk.kernelComputation(previous, current);
		// Normalizing
		return (float) (xy / Math.sqrt(xx * yy));
	}
}
