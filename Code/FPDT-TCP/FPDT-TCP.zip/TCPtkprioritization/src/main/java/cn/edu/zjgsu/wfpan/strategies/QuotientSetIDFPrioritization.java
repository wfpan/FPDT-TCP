package cn.edu.zjgsu.wfpan.strategies;

import it.unina.dieti.tkprio.domain.Method;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.QSSelectorI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import cn.edu.zjgsu.wfpan.strategies.helpers.TotalIDFCoverageSelector;

/**
 * QuotientSetIDFPrioritization vs. QuotientSetIDFPrioritization2
 * 区别：
 * 这里第二次选择的时候没有清空已选择的method集
 * 这里使用的是(构造函数中) TotalIDFCoverageSelector()
 * */
public class QuotientSetIDFPrioritization implements PrioritizationStrategyI {

	private final static String SUFFIX = "-QSIDF";

	private final PrioritizationStrategyI strategy;

	private final QSSelectorI selector;

	/**
	 * QuotientSetIDFPrioritization vs. QuotientSetIDFPrioritization2
	 * 区别：
	 * 这里第二次选择的时候没有清空已选择的method集
	 * 这里使用的是(构造函数中) TotalIDFCoverageSelector()
	 * */
	public QuotientSetIDFPrioritization(PrioritizationStrategyI strategy) {
		this(strategy, new TotalIDFCoverageSelector());
	}

	public QuotientSetIDFPrioritization(PrioritizationStrategyI strategy, QSSelectorI selector) {
		this.strategy = strategy;
		this.selector = selector;
	}

	@Override
	public String name() {
		return this.strategy.name() + SUFFIX;
	}

	@Override
	public void setUp(StrategyPaths paths) {
		// Proxying to the original strategy setUp method
		this.strategy.setUp(paths);
	}
	
	public static boolean bIDF = false; //一个指示器

	@Override
	public Permutation prioritize(TestSuite suite) {
		// Creating the quotient set using the wrapped prioritization strategy
		Map<Float, List<Test>> quotientSet = this.createQuotientSet(this.strategy.prioritize(suite));
		// Obtaining zero scored class and removing it from the QS
		List<Test> zeroClass = null;
		if (quotientSet.containsKey(0f)) {
			zeroClass = quotientSet.get(0f);
			quotientSet.remove(0f);
		}
		Permutation permutation = new Permutation();
		// Obtaining sorted scores (using as a queue)
		List<Float> scores = quotientSet.keySet().stream().sorted((s1, s2) -> Float.compare(s2, s1))
				.collect(Collectors.toList());
		
//		int classCnt = scores.size(); // 记录有多少个类别
//		int totalCnt = quotientSet.get(scores.get(0)).size();
//		boolean BLater = false;
//		int testCnt = suite.getTests().size();
//		int already = 0;
//		Test prevSelected = null;
		
		List<Method> alreadyList = new ArrayList<Method>();
		int alreadyCnt = 0;
		int scoreCnt = scores.size();
		
		while (!scores.isEmpty()) {
			// Retrieving the first score
			float actual = scores.remove(0);
			List<Test> equivalenceClass = quotientSet.get(actual);
			// Selecting a test from the equivalence class
			Test selected = this.selector.select(equivalenceClass);
			
			/**************新策略1/2上边界***********************************/
			alreadyCnt++;//记录已经判断过的类别数
//			System.out.println(actual);
			if (alreadyCnt <= scoreCnt && alreadyList.containsAll(selected.getCoveredMethods())) {
				// 若已走过一轮，后面肯定都有重复了。这个策略就失效了，就直接沿用原来的方法
//				System.out.println(" 包含了：" + actual);
				scores.add(actual); //上面去掉了，这里再放回去
//				System.exit(0);
				continue;
			}
			/**************新策略1/2下边界***********************************/
			
			equivalenceClass.remove(selected);
			permutation.addTest(selected);
			// Adding the score in last position if there are still test cases
			if (!equivalenceClass.isEmpty()) {
				scores.add(actual);
			}
			
			/**************新策略2/2上边界***********************************/
			//讲已经跑过的测试用例覆盖的方法做个并集
			alreadyList.addAll(selected.getCoveredMethods());
			/**************新策略2/2下边界***********************************/
			
//			already++;
//			if(already*1.f/testCnt>0.2 && !BLater) {
//				BLater = true;
//				bIDF = true;
//			}
			
		}
		// Adding back the zero class if it was present
		if (zeroClass != null)
			for (Test test : zeroClass)
				permutation.addTest(test);
		return permutation;
	}

	//直接放入 Float 对结果没影响，可以做到等值判断的
	private Map<Float, List<Test>> createQuotientSet(Permutation permutation) {
		Map<Float, List<Test>> quotient = new HashMap<>();
		for (Test test : permutation) {
			if (!quotient.containsKey(test.getScore()))
				quotient.put(test.getScore(), new LinkedList<>());
			quotient.get(test.getScore()).add(test);
		}
		return quotient;
	}
	
	@Deprecated
	private Map<Float, List<Test>> createQuotientSet2(Permutation permutation) {
		Map<Float, List<Test>> quotient = new HashMap<>();
		float eps = 1e-6f;
		for (Test test : permutation) {
			float target = test.getScore();
			boolean contains = quotient.keySet()
                    .stream()
                    .anyMatch(k -> Math.abs(k - target) < eps);
			
			if (!contains) {
				quotient.put(test.getScore(), new LinkedList<>());
			}
			
			List<Test> tList = quotient.entrySet()
	                 .stream()
	                 .filter(e -> Math.abs(e.getKey() - target) < eps)
	                 .map(Map.Entry::getValue)
	                 .findFirst()          // 只拿第一条
	                 .orElse(Collections.emptyList());        // 如果没有返回 null，也可以 orElseThrow()
			tList.add(test);
		}
		return quotient;
	}

}
