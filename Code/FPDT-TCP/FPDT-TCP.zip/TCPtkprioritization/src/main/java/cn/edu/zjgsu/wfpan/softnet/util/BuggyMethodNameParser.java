package cn.edu.zjgsu.wfpan.softnet.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 解析方法全名的工具类，支持提取类名、方法名，并对参数列表进行格式化处理
 * 处理规则：1. 从类名中分离方法名与参数列表 2. 参数类型保留最后一个"."后的内容 3. 移除泛型中的<>及内部内容
 */
public class BuggyMethodNameParser {

    // 匹配方法全名的正则表达式：捕获类名（组1）、方法名（组2）、参数列表（组3）
    // 格式示例：org.assertj.core.api.AbstractAssert.AbstractAssert(A,java.lang.Class<?>)
    private static final Pattern METHOD_FULL_NAME_PATTERN = 
        Pattern.compile("^([\\w.]+)\\.([\\w]+)\\((.*)\\)$");

    /**
     * 解析方法全名，返回包含类名、方法名、处理后参数列表的结果对象
     * @param fullMethodName 方法全名（格式如：org.assertj.core.api.AbstractAssert.AbstractAssert(A,java.lang.Class<?>)）
     * @return MethodParseResult 解析结果，包含类名、方法名、处理后的参数列表；若格式不匹配则返回null
     */
    public static MethodParseResult parse(String fullMethodName) {
        // 校验输入合法性
        if (fullMethodName == null || fullMethodName.trim().isEmpty()) {
            throw new IllegalArgumentException("Method full name cannot be null or empty");
        }

        Matcher matcher = METHOD_FULL_NAME_PATTERN.matcher(fullMethodName.trim());
        if (!matcher.matches()) {
            // 若不匹配预期格式，返回null或可自定义异常
            return null;
        }

        //org.joda.example.time.AgeCalculator$FieldGroup.<init>(java.awt.event.ItemListener,java.lang.String,int)
        
        // 提取捕获组内容：组1=类名，组2=方法名，组3=原始参数列表
        String className = matcher.group(1);
        String methodName = matcher.group(2);
        String rawParameters = matcher.group(3);

        // 处理参数列表：分割参数、格式化每个参数类型
        List<String> processedParams = processParameters(rawParameters);

        // 构建并返回解析结果
        return new MethodParseResult(className, methodName, processedParams);
    }

    /**
     * 处理原始参数列表：分割参数、移除泛型、保留类型最后一个"."后的内容
     * @param rawParameters 原始参数列表（如："A,java.lang.Class<?>"）
     * @return 处理后的参数列表（如：["A", "Class"]）
     */
    private static List<String> processParameters(String rawParameters) {
        List<String> processedParams = new ArrayList<>();
        if (rawParameters == null || rawParameters.trim().isEmpty()) {
            return processedParams; // 无参数时返回空列表
        }

        // 分割参数（处理参数间可能的空格，如"A, java.lang.Class<?>"）
        String[] paramArray = rawParameters.split("\\s*,\\s*");

        for (String param : paramArray) {
            // 步骤1：移除泛型中的<>及内部内容（如"java.lang.Class<?>" → "java.lang.Class"）
            String paramWithoutGeneric = removeGenericContent(param);
            // 步骤2：保留参数类型最后一个"."后的内容（如"java.lang.Class" → "Class"；"A" → "A"）
            String simplifiedParam = simplifyParamType(paramWithoutGeneric);
            processedParams.add(simplifiedParam);
        }

        return processedParams;
    }

    /**
     * 移除参数类型中的泛型内容（如"List<String>" → "List"，"Map<Integer,String>" → "Map"）
     * @param param 带泛型的参数类型
     * @return 移除泛型后的参数类型
     */
    private static String removeGenericContent(String param) {
        // 匹配第一个"<"到最后一个">"的内容并替换为空
        return param.replaceAll("<.*>", "");
    }

    /**
     * 简化参数类型：保留最后一个"."后的内容，无"."则返回原字符串
     * @param paramType 原始参数类型（如"java.lang.Class"、"A"）
     * @return 简化后的参数类型（如"Class"、"A"）
     */
    private static String simplifyParamType(String paramType) {
        int lastDotIndex = paramType.lastIndexOf('.');
        return lastDotIndex == -1 ? paramType : paramType.substring(lastDotIndex + 1);
    }

    /**
     * 解析结果的封装类，用于存储类名、方法名、处理后的参数列表
     */
    public static class MethodParseResult {
        private final String className;
        private final String methodName;
        private final List<String> processedParameters;
        private final String parameterString;

        public MethodParseResult(String className, String methodName, List<String> processedParameters) {
            this.className = className;
            this.methodName = methodName;
            this.processedParameters = processedParameters;
            this.parameterString = null;
        }

        // Getter方法
        public String getClassName() {
            return className;
        }

        public String getMethodName() {
            return methodName;
        }

        public List<String> getProcessedParameters() {
            return new ArrayList<>(processedParameters); // 返回副本，避免外部修改
        }
        
		public String getParameterString() {
			String result = "";
			if (null != processedParameters) {
				for (String str : processedParameters) {
					result += "@" + str;
				}
				return result.replace("[]", "").replace("<?@?>", "");
//				return result;
			} else {
				return "";
			}
		}

        // 重写toString，便于打印查看结果
        @Override
        public String toString() {
//            return "MethodParseResult{" +
//                    "className='" + className + '\'' +
//                    ", methodName='" + methodName + '\'' +
//                    ", processedParameters=" + processedParameters +
//                    '}';
        	return className+"."+ methodName + getParameterString();
        }
    }

    // 测试示例
    public static void main(String[] args) {
        BuggyMethodNameParser parser = new BuggyMethodNameParser();
        
        String testMethod4 = "org.joda.example.time.AgeCalculator$FieldGroup.<init>(java.awt.event.ItemListener,java.lang.String,int)";
        MethodParseResult result4 = parser.parse(testMethod4);
        System.out.println("Test Case 2 Result: " + result4);
        
        System.out.println(parser.parse("org.assertj.core.api.Condition_constructor_with_description_Test.should_set_description()"));
        
        // 测试用例1：含泛型、多圆点参数的方法名
        String testMethod1 = "org.assertj.core.api.AbstractAssert.AbstractAssert(A,java.lang.Class<?>)";
        MethodParseResult result1 = parser.parse(testMethod1);
        System.out.println("Test Case 1 Result: " + result1);
        // 预期输出：MethodParseResult{className='org.assertj.core.api.AbstractAssert', methodName='AbstractAssert', processedParameters=[A, Class]}

        // 测试用例2：无泛型、多参数的方法名
        String testMethod2 = "com.example.Service.getUserById(Long,java.util.Date)";
        MethodParseResult result2 = parser.parse(testMethod2);
        System.out.println("Test Case 2 Result: " + result2);
        // 预期输出：MethodParseResult{className='com.example.Service', methodName='getUserById', processedParameters=[Long, Date]}

        // 测试用例3：无参数的方法名
        String testMethod3 = "com.example.Utils.init()";
        MethodParseResult result3 = parser.parse(testMethod3);
        System.out.println("Test Case 3 Result: " + result3);
        // 预期输出：MethodParseResult{className='com.example.Utils', methodName='init', processedParameters=[]}
    }
}


