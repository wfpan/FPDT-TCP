package cn.edu.zjgsu.wfpan.softnet.util;

import java.util.regex.Pattern;

public final class MethodNameSimplifier {

    /**
     * 按规则简化全限定方法名。
     *
     * @param fullName 形如 "a.b.C.D.E.method"
     * @return 简化后的名字，如 "a.b.C.method"
     */
    public static String simplify(String fullName) {
        if (fullName == null || fullName.isEmpty()) {
            return fullName;
        }

        String[] parts = fullName.split("\\.");
        int len = parts.length;
        if (len <= 2) {               // 至少要有包/类 + 方法
            return fullName;
        }

        // 方法名固定到最后一段
        String method = parts[len - 1];

        // 从倒数第二段开始向左探测
        int keep = len - 2;          // 先假设最后一段类名就是 keep
        while (keep > 0 && isUpperCamel(parts[keep])) {
            keep--;                  // 向左合并连续大写段
        }
        // 循环结束后，parts[keep] 就是“最左边”的那段大写类名

        // 重新拼接：包路径 + 保留类名 + 方法名
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i <= keep+1; i++) {
            sb.append(parts[i]).append('.');
        }
        sb.append(method);
        return sb.toString();
    }

    /** 判断是否是首字母大写的段（内部类或最外层类）。 */
    private static boolean isUpperCamel(String s) {
        return !s.isEmpty() && Character.isUpperCase(s.charAt(0));
    }

    /* ------------------ 演示 ------------------ */
    public static void main(String[] args) {
        System.out.println(simplify(
                "org.assertj.core.error.BasicErrorMessageFactory.length"));
        // -> org.assertj.core.error.BasicErrorMessageFactory.length

        System.out.println(simplify(
                "org.assertj.core.error.BasicErrorMessageFactory.Good.UnquotedString.length"));
        // -> org.assertj.core.error.BasicErrorMessageFactory.length

        System.out.println(simplify("com.example.MyClass.Inner.<init>"));
        // -> com.example.MyClass.<init>

        System.out.println(simplify("Top.<clinit>"));
        System.out.print(simplify("org.la4j.matrix.AbstractMatrix.withSolver@LinearAlgebra.SolverFactory"));
        // -> Top.<clinit>
    }
}
