package cn.edu.zjgsu.wfpan.softnet.util.ifit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 以下是使用Java语言实现求无向图中一个点到其它所有点指定长度的所有路径，以及路径上的边权和，并计算图中一个点出发，
 * 指定长度内的所有节点的集合的代码。要求定义图的类为Graph，边的类为Edge
 */
class Graph {
	private int V; // 顶点数量
	private List<Edge>[] adjList; // 邻接表
	
	static List<Path> pathList;
	static Map<Integer,Map<Integer,List<Path>>> node2order2PathList = new HashMap<Integer,Map<Integer,List<Graph.Path>>>();

	@SuppressWarnings("unchecked")
	public Graph(int V) {
		this.V = V;
		adjList = new ArrayList[V];
		for (int i = 0; i < V; i++) {
			adjList[i] = new ArrayList<>();
		}
	}

	class Path {
		List<Integer> pp = new ArrayList<Integer>();
		double weight;
		public Path(List<Integer> path, double weight) {
			this.setPp(path);
			this.weight = weight;
		}
		
		public Path() {
			super();
		}

		public void setPp(List<Integer> pp) {
			//不这样拷贝结果不对
			for(int i=0; i<pp.size();i++) {
				this.pp.add(pp.get(i));
			}
		}

		public void setWeight(double weight) {
			this.weight = weight;
		}

		public List<Integer> getPp() {
			return pp;
		}

		public double getWeight() {
			return weight;
		}

		@Override
		public String toString() {
			return "Path [path=" + pp + ", weight=" + weight + "]";
		}
	}
	
	// 边的类定义
	private class Edge {
		int v;
		double weight;

		Edge(int v, double weight) {
			this.v = v;
			this.weight = weight;
		}
	}

	// 添加边
	public void addEdge(int v, int w, double weight) {
		adjList[v].add(new Edge(w, weight));
		adjList[w].add(new Edge(v, weight));
	}

	// 求无向图中一个点到其它所有点指定长度的所有路径以及路径上的边权和
	/**start开始，length为长度（order）*/
	public void findAllPathsAndWeight(int start, int length) {
		boolean[] visited = new boolean[V];
		List<Integer> path = new ArrayList<>();
		path.add(start);
		double[] weightSum = new double[1];
		weightSum[0] = 0;
		findAllPathsAndWeightUtil(start, start, length, visited, path, weightSum);
	}

	private void findAllPathsAndWeightUtil(int start, int currentVertex, int length, boolean[] visited,
			List<Integer> path, double[] weightSum) {
		visited[currentVertex] = true;

		if (length == 0) {
//			System.out.println("This Path: " + path);
//			System.out.println("Weight Sum on the path: " + weightSum[0]);
//			System.out.println(path);
			Graph.pathList.add(new Path(path,weightSum[0]));//把得到的路径加进去 wfpan
			
		} else {
			for (Edge edge : adjList[currentVertex]) {
				if (!visited[edge.v]) {
					path.add(edge.v);
					weightSum[0] += edge.weight;
					findAllPathsAndWeightUtil(start, edge.v, length - 1, visited, path, weightSum);
					weightSum[0] -= edge.weight;
					path.remove(path.size() - 1);
				}
			}
		}

		visited[currentVertex] = false;
	}

	// 计算从指定点出发，指定长度内的所有节点的集合
	public Set<Integer> findNodesWithinLength(int start, int length) {
		Set<Integer> nodes = new HashSet<>();
		boolean[] visited = new boolean[V];
		nodes.add(start);
		visited[start] = true;
		findNodesWithinLengthUtil(start, length, visited, nodes);
		return nodes;
	}

	private void findNodesWithinLengthUtil(int start, int length, boolean[] visited, Set<Integer> nodes) {
		if (length == 0) {
			return;
		}

		for (Edge edge : adjList[start]) {
			if (!visited[edge.v]) {
				nodes.add(edge.v);
				visited[edge.v] = true;
				findNodesWithinLengthUtil(edge.v, length - 1, visited, nodes);
			}
		}
	}

}

public class ComputePathv6 {
	
	public static double computeIFij(int i, int j, int order, double[] prRank, Graph graph) {
		//初始化列表，否则不能用
		Graph.pathList = new ArrayList<Graph.Path>();
		int cnt = 0;
		double sum = 0.d;

		//计算从j开始长度为0rder的出发路线
		graph.findAllPathsAndWeight(j, order);
		
		//判断出发的path是不是hi已经求过了，求过了直接取：好像优化不起作用
		/*if(Graph.node2order2PathList.containsKey(j)) {
			if(Graph.node2order2PathList.get(j).containsKey(order)) {
				Graph.pathList = Graph.node2order2PathList.get(j).get(order);
				System.out.println("找到了 pathlist " + Graph.pathList);
				System.exit(0);
			} else {
				graph.findAllPathsAndWeight(j, order);
				Map<Integer, List<Graph.Path>> orderPathlist = new HashMap<>();
				orderPathlist.put(order, Graph.pathList);
				Graph.node2order2PathList.put(j, orderPathlist);
			}
		} else {
			graph.findAllPathsAndWeight(j, order);
			Map<Integer, List<Graph.Path>> orderPathlist = new HashMap<>();
			orderPathlist.put(order, Graph.pathList);
			Graph.node2order2PathList.put(j, orderPathlist);
		}*/
		
		/*System.out.println("输出所有路径");
		for(int k=0; k<Graph.pathList.size();k++) {
			System.out.println(Graph.pathList.get(k));
		}*/
		
		if(Graph.pathList.size()>0) {
			for(int t =0; t<Graph.pathList.size(); t++) {
				if(Graph.pathList.get(t).pp.contains(i)) {
					//j出发包含i
					cnt++;
//					System.out.println("找到一个");
//					System.exit(0);
				}
			}
			sum += ((cnt*1.0d)/Graph.pathList.size()) * prRank[i] * prRank[j] * 1.0d/(order * order);
		}
		return sum;
	}

	public static double run(int i, Graph graph, double[] prRank) {
		/*Graph graph = new Graph(5);
		graph.addEdge(0, 1, 2);
		graph.addEdge(0, 4, 3);
		graph.addEdge(1, 2, 6);
		graph.addEdge(1, 3, 4);
		graph.addEdge(1, 4, 5);
		graph.addEdge(2, 3, 3);
		graph.addEdge(3, 4, 1);*/
		
		//计算节点 i 的重要性
//		int i = 0;

		//这里求的是i的邻居集：j取自哪里。我们这里求3-order内的邻居。order=length
//		System.out.println("\nNodes within order 3 starting from vertex "+ i + ":");

		Set<Integer> nodes = graph.findNodesWithinLength(i, 3);
//		nodes.remove(i); //去掉i本身，只保留其邻居
//		System.out.println("nodes: " + nodes);
//		System.exit(0);
		
		
		double sum = 0.d;
		
		Iterator<Integer> iter = nodes.iterator();
		Integer j = null;
		while(iter.hasNext()) {
			j = iter.next();
			if(i==j) {
				continue;
			}
			for(int o=1; o<=3; o++) {
				//从1-order一直求到3-order
				sum += computeIFij(i,j,o, prRank,graph);
			}
		}
		
//		prRank[i] = sum;
		return sum; 

//		System.out.println("All paths of length 3 from vertex 0:");
//		graph.findAllPathsAndWeight(0, 3);

	}

	public static void main(String[] args) {
		/*Graph graph = new Graph(5);
		graph.addEdge(0, 1, 2);
		graph.addEdge(0, 4, 3);
		graph.addEdge(1, 2, 6);
		graph.addEdge(1, 3, 4);
		graph.addEdge(1, 4, 5);
		graph.addEdge(2, 3, 3);
		graph.addEdge(3, 4, 1);

		System.out.println("All paths of length 3 from vertex 0:");
		graph.findAllPathsAndWeight(0, 3);

		System.out.println("\nNodes within length 2 starting from vertex 0:");
		Set<Integer> nodes = graph.findNodesWithinLength(0, 2);
		System.out.println(nodes);*/
//		run(args);
	}
}
