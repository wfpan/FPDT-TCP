package cn.edu.zjgsu.wfpan.softnet.util.ifit;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.edu.zjgsu.wfpan.softnet.util.PrNormalizer;
import cn.edu.zjgsu.wfpan.softnet.util.SignatureFormatter;

//import cn.edu.zjgsu.resultshow.JTableResultShow;

/**
 * Pride
 * 浮点数加权 PageRank 算法
 * 输入：.net 格式的加权有向软件网络
 * 输出：软件实体及其相应的weighted PR(这个pagerank算法是从TSE中的那个pagerank算法改进而来) 值
 * 注：虽然本文演示用的是方法层次的网络文件，但是这个程序对任何一级的网络都是适用的
 * 
 * Pride中使用的改进的PageRank算法
 * 使用的pagerank算法是从TSE的PageRank算法改进而来
 * Title: Ranking Software Packages for Maintenance based on Multilayer Software Networks
 * Weighted PageRank: PR_w(p_i) = \frac{(1 - d) \times InLinks(p_i)}{\sum\nolimits_{k = 1}^N {InLinks(p_k)} } 
 * + d\sum\limits_{p_j \in M({p_i})} {\frac{PR_w(p_j)}{OutLinks(p_j)}}
 * @author wfpan
 * @version 1.0
 * 2018-07-04
 * 
 * 2020-07-29 从 WeightedPageRank4PackRank_wfpan.java修改而来，两个一样
 * 2020-07-29 pagerank结果扩大了1000倍，即原来是0.00000001 * 1000
 * 2020-08-01 这个版本的公式与TSE的一样！！！！！
 * 2020-08-01 PageRank算从TSE的改进而来，主要是改进了公式的前半部分
 * 2021-01-19 对输出的结果文件进行去重边处理
 */

public class PersonalizedPRiFit {
	/**
	 * 
	 * @param srcFile 软件网络地址：加权有向网络
	 * @param destFile 结果保存地址
	 * @throws Exception
	 */
	public static Map<String, Float> getClassRankValue(Map<String,Float> methodFP, Path srcFilePath) throws Exception {

		if (!Files.isRegularFile(srcFilePath))
			throw new RuntimeException("File " + srcFilePath + " does not exists or is not a regular file");
		
		System.out.println("[SNAP] Calculating method importance from the file " + srcFilePath.getFileName().toString());
		
		Map<String, Float> prValue = new HashMap<String, Float>();
		
		int nodeNum; // 软件中的节点数，根据文件读入的内容来初始化

		double rank = 0f; // 中间变量，保存rank值得中间值
		double value = 0f; // 计算后的pagerank值

		boolean flag = true;

		FileReader reader = new FileReader(srcFilePath.toFile());
		BufferedReader br = new BufferedReader(reader);
		
		String paramLine = br.readLine(); // 读取节点所在行
		
		String[] strNodeNum = paramLine.split(" "); // 读取一行，并分割字符串
		nodeNum = Integer.parseInt(strNodeNum[1]); // 获取节点数

		double[][] link = new double[nodeNum][nodeNum]; // 邻接矩阵：权值为实数
		
		int[] outLink = new int[nodeNum]; // 根据读入的节点数开辟空间
		int[] outLinkDeg = new int[nodeNum]; // 根据读入的节点数开辟空间
		int[] inLink = new int[nodeNum]; // 根据读入的节点数开辟空间
		int[] inLinkDeg = new int[nodeNum]; // 根据读入的节点数开辟空间
		int inLSum = 0; //入度和
		int outLSum = 0; //入度和
		int inLDegSum = 0; //入度和
		int outLDegSum = 0; //入度和
		
		
		double[] copyPR = new double[nodeNum];
		double[] fPageRankBak = new double[nodeNum]; //保存前一次的 PageRank 值
		double fSqDev = 0f;
		
		//获取节点名
		boolean nameFlag = true; // nameFlag 布尔变量，表示是否正在读入节点名
		int iNameIndex = 0; // 名字数组下标计数器
		String[] strNodeName = new String[nodeNum]; // 存储节点的名字

		while (nameFlag) {
			String lineText = br.readLine();
			if (lineText.equals("*Arcs")) { // 如果读到的是 Arcs 行
				nameFlag = false;
				continue;
			}
			
			if(lineText.equals("*Edges")) { // 如果读到无向网络就报错
				System.exit(0);
			}
			
			String strNameTmp = lineText.substring(lineText.indexOf("\"") + 1,
					lineText.lastIndexOf("\""));
			strNodeName[iNameIndex] = strNameTmp; // 存储节点名
			
			iNameIndex++;
		}

		/**
		 * 
		 * 节点 PageRank 值初值
		 * 
		 */
		double[] tempPR = new double[nodeNum];
		for (int i = 0; i < nodeNum; i++) {
//			tempPR[i] = 1.0f/nodeNum; // 初始化时候各个节点的 PageRank 值
			//---
			String tmpName = SignatureFormatter.convertMethodNameSN(strNodeName[i]);
			if(methodFP.containsKey(tmpName)) {
				tempPR[i] = methodFP.get(SignatureFormatter.convertMethodNameSN(strNodeName[i]));
			} else {
				tempPR[i] = 0.f;
			}
			
		}
		
		//构建图 2023=06-28
		Graph graph = new Graph(nodeNum);
//		graph.addEdge(0, 1, 2);

		/**
		 * 
		 * 构造邻接矩阵
		 * 
		 */
		while (flag) {
			String lineText = br.readLine(); // 读取 Arcs 下的一行
			if (null == lineText) { // 未读到文件尾
				flag = false;
				continue;
			}
			
			String[] s = lineText.split(" "); // 读取连接的两个节点数值

			if(3==s.length) { // 加权版本
				//原来方向
//				link[Integer.parseInt(s[0]) - 1][Integer.parseInt(s[1]) - 1] 
//						= Double.parseDouble(s[2]); // 2014-08-23
//				graph.addEdge(Integer.parseInt(s[0]) - 1, Integer.parseInt(s[1]) - 1, Double.parseDouble(s[2]));
				
				link[Integer.parseInt(s[1]) - 1][Integer.parseInt(s[0]) - 1] 
						= Double.parseDouble(s[2]); // 2014-08-23
				graph.addEdge(Integer.parseInt(s[1]) - 1, Integer.parseInt(s[0]) - 1, Double.parseDouble(s[2]));
				
			}
			else if(2==s.length) { // 无权版本
				System.exit(0);
			}
		}

		br.close(); // 关闭流
		reader.close(); // 关闭文件

		/**
		 * 
		 * 统计节点出度和入度：加权后的
		 * 
		 */
		for (int i = 0; i < nodeNum; i++) {
			int links = 0;
			int linksDeg = 0;
			int inL = 0;
			int inLDeg = 0;
			for (int j = 0; j < nodeNum; j++) {
				if (Math.abs(link[i][j]-0.0f) >= 0.0000001) { //if (link[i][j] != 0) 浮点数判断是否为 0
					links += link[i][j];
					linksDeg += 1;
				}
				if (Math.abs(link[j][i]-0.0f) >= 0.0000001) { //入度
					inL += link[j][i];
					inLDeg += 1;
				}
			}
			outLink[i] = links; // 节点出度
			outLinkDeg[i] = linksDeg; // 节点出度
			inLink[i] = inL;//节点入度
			inLinkDeg[i] = inLDeg;//节点入度
			inLSum += inLink[i];
			outLSum += outLink[i];
			inLDegSum += inLinkDeg[i];
			outLDegSum += outLinkDeg[i];
		}
		System.out.println("");

		/**
		 * 
		 * 计算各个节点PageRank值
		 * 
		 */
		for (int m = 0; ; m++) { // 循环迭代。PS:迭代到一定的精度自动退出
			
//			System.out.println("第" + (m + 1) + "次运行开始！");
			
			for (int x = 0; x < tempPR.length; x++) { // 数组拷贝
				copyPR[x] = tempPR[x];
			}
			
			double sum = 0f; // PageRank临时求和变量
			String tmpName = null;
			
			// 这个循环是为了得到本轮各个节点计算后的 PR 值,将得到一个新的 PR 值数组
			for (int node = 0; node < nodeNum; node++) {
				// 使用 copyPR[] 进行计算
				for (int j = 0; j < nodeNum; j++) {
//					int var = link[j][node]; // 权值为整数
					double var = link[j][node]; // 权值为实数的情况

//					if (var == 0) {
					if(Math.abs(var-0.0f) < 0.0000001) { // 刚开始是上面句，错误了。已更正
						continue; // 没有链接就跳过
					} else {
						rank = rank + ( copyPR[j]* link[j][node])/ (outLink[j]); // 2020-08-01 考虑出边的个数
					}
				}
				
				tmpName = SignatureFormatter.convertMethodNameSN(strNodeName[node]);
				float tmpFP = 0.f;
				if(methodFP.containsKey(tmpName)) {
					tmpFP = methodFP.get(tmpName);
				}

				value = rank
						* 0.85d
						+ 0.15d * tmpFP; // 这个得到该节点在本轮迭代的最后值
				
				if(Double.isNaN(value)) {
					System.out.println("not a number");
					System.out.println(inLSum + outLSum);
					System.out.println(inLDegSum + outLDegSum);
					System.out.println(((inLSum + outLSum) * (inLDegSum + outLDegSum)));
					System.out.println(((inLSum + outLSum) * (inLDegSum + outLDegSum)));
					System.exit(0);
				}
				
				sum += value;
				fSqDev += (value - fPageRankBak[node]) * (value - fPageRankBak[node]);
				fPageRankBak[node] = value; // 保存上一次运行的值
				tempPR[node] = value;
				rank = 0f; // 本节点计算完成后，中间变量清零
			}

			double tmpValue = 0.d;
			
			String orig = null;
			if (Math.sqrt(fSqDev) < 1e-15 || (m + 1 > 10000)) { // 当方差小于一定精度时就推出循环
				System.out.println("[SNAP] ClassRank is terminated");
				// Arrays.sort(fPageRankBak);
				for (int iTmp = 0; iTmp < fPageRankBak.length; iTmp++) {
					orig = SignatureFormatter.convertMethodNameSN(strNodeName[iTmp]);
					if(prValue.containsKey(orig)) {
						System.err.println(strNodeName[iTmp] + " 已经在 prVAlue Map 中了");
					} else {
						tmpValue = ComputePathv6.run(iTmp, graph, fPageRankBak);
						prValue.put(orig, (float)tmpValue);
//						if("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String".equals(strNodeName[iTmp])) {
//							System.err.println("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String" + "\n" + orig);
//						}
					}
				}
				break;
			} else {
				fSqDev = 0;
			}
		}
		//标准化一下
		prValue = PrNormalizer.normalize(prValue);
		return prValue;
	}
	
	public static void showTime() {
		Calendar c = Calendar.getInstance();// 刷新时间
		String time = c.get(Calendar.HOUR_OF_DAY) + ":" + c.get(Calendar.MINUTE) + ":" + c.get(Calendar.SECOND) + ":" + c.get(Calendar.MILLISECOND);
		System.out.println("The current time is : " + time);
	}
	
	/**
     * 获取路径下的所有文件/文件夹
     * @param directoryPath 需要遍历的文件夹路径
     * @param isAddDirectory 是否将子文件夹的路径也添加到list集合中
     * @return
     */
    public static List<String> getAllFile(String directoryPath,boolean isAddDirectory) {
        List<String> list = new ArrayList<String>();
        File baseFile = new File(directoryPath);
        if (baseFile.isFile() || !baseFile.exists()) {
            return list;
        }
        File[] files = baseFile.listFiles();
        for (File file : files) {
            if (file.isDirectory()) {
                if(isAddDirectory){
                    list.add(file.getAbsolutePath());
                }
                list.addAll(getAllFile(file.getAbsolutePath(),isAddDirectory));
            } else {
                list.add(file.getAbsolutePath());
            }
        }
        return list;
    }
	
//	public static void main2(String[] args) {
//		showTime();
//		try {
//			String rootPath = null;
//			String dir = "D:\\04 论文创作\\06 中国科学_2020_MinClass\\shiyanThree\\";
//			dir = "D:\\04 论文创作\\06 中国科学_2020_MinClass\\实验\\完全正确的softnet\\";
//			dir = "D:\\04 论文创作\\06 中国科学_2020_MinClass\\shiyanThree\\";
//			//shiyanTwo4Time
//			dir = "D:\\04 论文创作\\06 中国科学_2020_MinClass\\shiyanTwo4Time\\";
//			dir = "C:\\shiyanTwo4Time\\";
//			
//			rootPath = dir + "WDCDN_TSE\\AllSoftNets_TSE\\";
//			rootPath = dir + "CCN_WD_LiuShiRan\\AllSoftNets_LiuShiRan\\";
//			rootPath = dir + "CCN_WD_Kang\\AllSoftNets_Kang\\";
//			rootPath = dir + "CCN_WD_Sora\\AllSoftNets_Sora\\";
////			rootPath = "D:\\04 论文创作\\07 TSE_2020_CoreBug__审稿ing\\实验\\20200801\\软件网络\\";
////			rootPath = "E:\\workspace_20151227\\examples4papers\\src\\SNAP-softnet_run_1\\example\\";
//			rootPath = "D:\\04 论文创作\\140 TSE_2020_TopCore_Comment_审稿ing\\实验\\rj\\xx\\qu_5types\\";
//			rootPath = "D:\\04 论文创作\\140 TSE_2020_TopCore_Comment_审稿ing\\实验\\rj\\xx\\wfpan_9types\\";
//			rootPath = "C:\\Users\\lenovo\\Desktop\\例子\\";
//			rootPath = "D:\\04 论文创作\\140 TSE_2020_TopCore_Comment_审稿ing\\实验\\rj\\xx\\9types0418\\";
//			
//			rootPath = "D:\\04 论文创作\\140 TSE_2020_TopCore_Comment_审稿ing\\实验\\wt实验\\SoftNet\\Sora\\01Sora\\";
//			
//			rootPath = "F:\\04 论文创作\\05 TSE_2020_EASE\\实验\\newSys\\CCN_WD_FGCS\\";
//			rootPath = "F:\\04 论文创作\\05 TSE_2020_EASE\\实验\\newSys\\CCN_WD_Kang\\";
//			rootPath = "F:\\04 论文创作\\05 TSE_2020_EASE\\实验\\newSys\\CCN_WD_Sora\\";
//
//			rootPath = dir + "CCN_WD_FGCS\\AllSoftNets_FGCS\\";
//			
//			
////			String[] projects = {"drjava","jmol", "genoviz"};
////			String[] projects = {"example"};
//			
//			//关键类识别
////			String[] projects = {"ant_main","argouml","gwtportlets","javaclient","jedit","jgap","jhotdraw","jmeter_core","Mars","Maze","neuroph","tomcat","wro4j"};
//			String[] projects = {"jedit"};
////			String[] projects = {"nanoXML","jexcelapi","jgrapht"};
////			String[] projects = {"JPMC","log4j-2.3","PDFBox-2.0.7","Xerces-2.11.0","xuml-compiler-0.4.8"};
//			
//			/*String[] projects = {"camel", "drjava", "equinox", "genoviz", "htmlunit2.7", "ivy", "jdtcore",
//					"jikesrvm3.0", "jmol", "JPPF-5.0", "jump1.9.0", "jump1.9.0", "log4j", "lucene", "poi","synapse","tomcat","velocity","xalan"};*/
////			String[] projects = {"CDN","ICDN","E"};
////			String[] projects = {"camel","drjava","equinox",
////					"genoviz","htmlunit2.7","ivy","jdtcore",
////					"jikesrvm3.0","jmol","JPPF-5.0","jump1.9.0","log4j","lucene","poi","synapse","tomcat","velocity","xalan"};
//			
//			String filePath = null;
//			for (String path : projects) {
//				System.out.println(path + ": start");
//				showTime();
//				System.out.println("Process " + path);
//				/** SoftNet GDN */
//	//			filePath = rootPath + "SoftNet_" + path + ".txt";
//				filePath = rootPath + "9EXTENDS_IMPLEMENTS_FUNC_PARAM_GLOBAL_VAR_CALLS_LOCAL_VAR_FUNC_RET_INSTANTIATES_ACCESS_MCN_WDCDN_SoftNet_" + path + ".net";
//				filePath = rootPath + "LiuShiRan_WDCDN_SoftNet_" + path + ".net";
//				filePath = rootPath + "WD_5EXTENDS_IMPLEMENTS_FUNC_PARAM_GLOBAL_VAR_FUNC_RET_MCN_WDCDN_SoftNet_" + path + ".net";
//				filePath = rootPath + "SoftNet_" + path + ".net";
//				filePath = rootPath + "WD_9EXTENDS_IMPLEMENTS_FUNC_PARAM_GLOBAL_VAR_CALLS_LOCAL_VAR_FUNC_RET_INSTANTIATES_ACCESS_MCN_WDCDN_SoftNet_" + path + ".net";
//
//				filePath = rootPath + "Kang_WDCDN_SoftNet_" + path + ".net";
//				filePath = rootPath + "Sora_WDCDN_SoftNet_" + path + ".net";
//				filePath = rootPath + "CCN_SoftNet_FGCS_" + path + ".net";
//				
//				
//				//把所有方法合并在一起
//				
//				/*A_index_wun_wfpan.calculateAindex(filePath, filePath + "_a-index.txt");
//				ConnTotalW_Sora.calculateDegree(filePath, filePath + "_ConnTotalUW-Sora.txt");
//				ForwardBackOriginalPageRank_Sora.calculatePageRank(filePath, filePath + "_ForwardBackPageRank-Sora.txt");
//				ForwardOriginalPageRank_Sora.getPackageRank(filePath, filePath + "_ForwardPageRank-Sora.txt");
//				GeneralizedKCoreCaculator_wdn_wfpan.calculateWeightedKCore(filePath, filePath
//						+ "_g-core.txt", new String[]{"id","name","in WC","out WC","in-out WC","in_out RWC"});
//				H_index_uun_wfpan.calculateHindex(filePath, filePath + "_h-index.txt");
//				KCoreCaculator_uun_wfpan.calculateWeightedKShell(filePath, filePath
//						+ "_k-core.txt");
//				WeightedPageRank_ShiranLiu.calculatePageRank(filePath, filePath + "_LiuPageRank.txt");
//				
//				
//				WeightedKShellCaculator_wun_Garas.calculateWeightedKShell(filePath, filePath
//						+ "_wk-core.txt");*/
//			/*	GeneralizedKCoreCaculator_wdn_wfpan.calculateWeightedKCore(filePath, filePath
//						+ "_g-core.txt", new String[]{"id","name","in WC","out WC","in-out WC","in_out RWC"});
//						*/
//				PersonalizedPRiFit.getTSEPageRank(filePath, filePath + "_TSEPageRank_v15.txt");
//				System.out.println(path + ": end");
//				showTime();
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		showTime();
//	}
	
//	public static void main(String[] args) {
//		showTime();
//		//CCN_SoftNet_FGCS_PDFBox-2.0.7.net
//		String filePath = "F:\\04 论文创作\\04 ICSE_iFit改进\\实验\\CCN_SoftNet_FGCS_ant_main.net";
//		try {
//				PersonalizedPRiFit.getTSEPageRank(filePath, filePath + "_TSEPageRank_v15.txt");
//				System.out.println("finish.");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		showTime();
//	}

}