package cn.edu.zjgsu.wfpan.strategies;

import it.unina.dieti.tkprio.ast.ASTRepresentation;
import it.unina.dieti.tkprio.domain.*;
import it.unina.dieti.tkprio.io.ASTGenerator;
import it.unina.dieti.tkprio.io.CloverCoverageParser;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import it.uniroma2.sag.kelp.kernel.tree.PartialTreeKernel;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.edu.zjgsu.wfpan.softnet.util.ClassRank;
import cn.edu.zjgsu.wfpan.softnet.util.ReadMethodBuggyProb;
import cn.edu.zjgsu.wfpan.softnet.util.ReadMethodCognitive;
import cn.edu.zjgsu.wfpan.softnet.util.SignatureFormatter;

import java.nio.file.Path;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static it.unina.dieti.tkprio.rtp.strategies.helpers.MethodMatcher.createMethodMatching;

/**
 * 1.融入方法的认知复杂度
 * 2.融入方法在测试用例中的IDF，出现的少IDF大 
 * */
public class MTKPrioritizationWithIDFBugPrediction implements PrioritizationStrategyI {

	private static final Logger LOG = LoggerFactory.getLogger(MTKPrioritizationWithIDFBugPrediction.class);

	public static final String NAME = "MTK-IDFBug"; //自己的方法的名字

	private Path coverageReportPath;
	private List<Path> previousSources;
	private List<Path> currentSources;

	private MethodSet previousMethods;
	private MethodSet currentMethods;
	private CoverageReport coverageReport;
	
	private Path cognitiveFilePath; //cognitiveFilePath
	private Path buggyFilePath; //buggyFilePath
	//增加一个路径需要修改多出地方: 1. 下面方法内的this.cognitiveFilePath; 2. Experiment中createPaths内; 
	//3. StrategyPaths类内 定义及getter/setter方法
	
	private Map<String,Double> methodIDF = null;

	private final PartialTreeKernel ptk = new PartialTreeKernel(.7f, .4f, 1f, "0");

	@Override
	public String name() {
		return NAME;
	}

	@Override
	public void setUp(StrategyPaths paths) {
		this.coverageReportPath = paths.getPreviousCoveragePath();
		this.currentSources = paths.getCurrentSources();
		this.previousSources = paths.getPreviousSources();
		
		this.cognitiveFilePath = paths.getCognitiveFilePath(); //增加自己的
		this.buggyFilePath = paths.getBuggyFilePath();
	}
	
	/**我自己定义的，用于计算method的IDF*/
	private void calculateMethodIDF(TestSuite suite) {
		methodIDF = new HashMap<String, Double>();
		double cnt = 0;
		// Scoring test cases
		for (Test test : suite) {
			float score = 0f;
			for (Method covered : test.getCoveredMethods()) {
				if(methodIDF.containsKey(covered.getSignature())) {
					cnt = methodIDF.get(covered.getSignature());
					methodIDF.put(covered.getSignature(), cnt+1);
				} else {
					methodIDF.put(covered.getSignature(), 1.d);
				}
			}
		}
		//IDF(t) = log ( N / (df(t)+1) )
		methodIDF.replaceAll((k, v) -> Math.log((suite.getTests().size()+1)/(v+1)));
		
		// 1. 找出最大、最小值
		final double EPS = 1e-12;
		double max = Collections.max(methodIDF.values());
		double min = Collections.min(methodIDF.values());
		double range = max - min;          // 范围

		// 2. 防除 0：如果所有值都相同，range==0，统一设为 0 或其他缺省值
		if (Math.abs(range) < EPS) {
			methodIDF.replaceAll((k, v) -> 1.d);
		} else {
		    // 3. 最大-最小归一化
			methodIDF.replaceAll((k, v) -> (v - min) / range);
		}
	}

	/**这里排的是 previous 和 current 公共部分的 test case
	 * 可以理解为：在previous版本中的执行的用例
	 * */
	@Override
	public Permutation prioritize(TestSuite suite) {
		//Initializes data for the prioritization, including coverageReport, currentMethods, and previousMethods.
		this.init();
		suite.mergeWithCoverage(this.coverageReport);
		List<Pair<Method, Method>> matching = createMethodMatching(this.previousMethods, this.currentMethods);
		// Evaluating methods' similarity
		Map<String, Float> similarities = this.getSimilarityMap(matching);
		
//		Map<String, Float> methodCogValue = null;
//		try {
////			methodCogValue = ClassRank.getClassRankValue(this.cognitiveFilePath);
//			methodCogValue = ReadMethodCognitive.parseCsv(this.cognitiveFilePath);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		Map<String, Float> methodBuggyProb = null;
		try {
//			methodCogValue = ClassRank.getClassRankValue(this.cognitiveFilePath);
			methodBuggyProb = ReadMethodBuggyProb.parseTxt(this.buggyFilePath);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//计算方法的IDF，也就是方法被测试用例覆盖的唯一性。覆盖的少，IDF就大
		calculateMethodIDF(suite);
		double mIDF = 0.d;
		
		// Scoring test cases
		for (Test test : suite) {
			float score = 0f;
			for (Method covered : test.getCoveredMethods()) {
				if (similarities.containsKey(covered.getSignature())) {
					//加入IDF值
					if(methodIDF.containsKey(covered.getSignature())) {
						mIDF = methodIDF.get(covered.getSignature());
					} else {
						System.err.println(covered.getSignature() + " 的IDF值不存在");
					}
					
					String newCoveredMN = SignatureFormatter.convertMethodName(covered.getSignature());

					// 若存在直接取值，若不存在取默认值0(这里做了+1/最大值 处理了的)
					float bp = 0.f;
					if (methodBuggyProb.containsKey(newCoveredMN)) {
						bp = methodBuggyProb.get(newCoveredMN);
					} else if (methodBuggyProb.containsKey(newCoveredMN + "[]")) {
						bp = methodBuggyProb.get(newCoveredMN + "[]");
					} else {
						System.err.println(newCoveredMN + " 不在 methodBuggyProb Map 中");
						System.exit(0);
					}

					score += (1 - similarities.get(covered.getSignature())) * mIDF * bp;// 修改这里*方法重要性
//						System.out.println("score = " + score);
				}
			}
			test.setScore(score);
		}
		
/*		//Scoring test cases 原来的版本
		for (Test test : suite) {
			float score = 0f;
			for (Method covered : test.getCoveredMethods()) {
				if (similarities.containsKey(covered.getSignature())) {
					
					if(prValue.containsKey(covered.getSignature()))
					
					score += (1 - similarities.get(covered.getSignature()));//修改这里*方法重要性
				}
			test.setScore(score);
			}
		}
*/		
		Permutation permutation = new Permutation(suite);
		// Sorting the test cases by score in descending order
		permutation.getTests().sort((t1, t2) -> Float.compare(t2.getScore(), t1.getScore()));
		return permutation;
	}

	/**
	 * Initializes data for the prioritization, including coverageReport,
	 * currentMethods, and previousMethods.
	 * 
	 */
	private void init() {
		if (this.coverageReport == null)
			this.loadCoverage();
		if (this.currentMethods == null)
			this.currentMethods = this.loadMethods(this.currentSources);
		if (this.previousMethods == null)
			this.previousMethods = this.loadMethods(this.previousSources);
	}

	private void loadCoverage() {
		LOG.info("Loading coverage report");
		CloverCoverageParser parser = new CloverCoverageParser();
		this.coverageReport = parser.parse(this.coverageReportPath);
	}

	/**
	 * 这里设置method的各种特性，包括其AST ASTs are created
	 */
	private MethodSet loadMethods(List<Path> sources) {
		MethodSet globalMethodSet = new MethodSet();
		// Generating the methods for all source files and merging all together
		ASTGenerator generator = new ASTGenerator();
		for (Path source : sources) {
			MethodSet sourceMethodSet = generator.generateFromSource(source, true); // ASTs are created
			globalMethodSet.merge(sourceMethodSet);
		}
		return globalMethodSet;
	}

	private Map<String, Float> getSimilarityMap(List<Pair<Method, Method>> matching) {
		Map<String, Float> similarities = new HashMap<>();
		for (Pair<Method, Method> pair : matching) {
			Method previous = pair.getLeft();
			Method current = pair.getRight();
			// Avoids comparing abstract methods and unchanged methods
			if (previous.getAst() != null && current.getAst() != null
					&& !previous.getBody().equals(current.getBody())) {
				// Evaluating PTK and adding the similarity
				float sim = this.normalizedPtk(previous.getAst(), current.getAst());
				//the sim is set to the previous method as we calculate the score on the previous project
				similarities.put(previous.getSignature(), sim);
//				System.out.println("方法名是: " + previous.getSignature());
//				System.exit(0);
			}
		}
		return similarities;
	}

	private float normalizedPtk(ASTRepresentation previous, ASTRepresentation current) {
		float xx = this.ptk.kernelComputation(previous, previous);
		float yy = this.ptk.kernelComputation(current, current);
		float xy = this.ptk.kernelComputation(previous, current);
		// Normalizing
		return (float) (xy / Math.sqrt(xx * yy));
	}
}
