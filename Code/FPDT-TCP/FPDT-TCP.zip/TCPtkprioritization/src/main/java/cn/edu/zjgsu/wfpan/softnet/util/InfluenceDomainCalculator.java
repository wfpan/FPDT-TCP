package cn.edu.zjgsu.wfpan.softnet.util;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class InfluenceDomainCalculator {
    // 存储反向邻接表: key是节点, value是指向该节点的所有节点列表
    private Map<Integer, List<Integer>> reverseAdjacencyList;
    
    private Map<Integer, String> nodeID2Name;
    public Map<String, Float> name2Size;
    // 图中所有节点的集合
    private Set<Integer> allNodes;
    // 最大步数
    private int maxSteps;

    public InfluenceDomainCalculator(int maxSteps) {
        this.reverseAdjacencyList = new HashMap<>();
        this.allNodes = new HashSet<>();
        this.maxSteps = maxSteps;
        this.nodeID2Name = new HashMap<>();
        this.name2Size = new HashMap<String, Float>();
    }

    // 从Pajek .net文件读取图
    public void readNetFile(File filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        
        // 跳过文件头直到*Edges或*Arcs行
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.startsWith("*Vertices")) {
                // 处理顶点信息
                int numVertices = Integer.parseInt(line.split("\\s+")[1]);
                // 读取每个顶点的定义
                for (int i = 0; i < numVertices; i++) {
                    line = reader.readLine().trim();
                    if (line.isEmpty()) continue;
                    
                    // 提取顶点ID
                    String[] parts = line.split("\\s+");
                    int nodeId = Integer.parseInt(parts[0]);
                    allNodes.add(nodeId);
                    reverseAdjacencyList.putIfAbsent(nodeId, new ArrayList<>());
                    nodeID2Name.putIfAbsent(nodeId, parts[1].replaceAll("^\"|\"$", ""));
                }
            } else if (line.startsWith("*Arcs") || line.startsWith("*Edges")) {
                // 处理边信息（有向边）
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;
                    
                    // 解析边：源节点 目标节点 权重
                    String[] parts = line.split("\\s+");
                    if (parts.length < 2) continue;
                    
                    int source = Integer.parseInt(parts[0]);
                    int target = Integer.parseInt(parts[1]);
                    
                    // 对于影响域计算，我们需要反向关系：添加source到target的反向邻接表
                    reverseAdjacencyList.get(target).add(source);
                    
                    // 确保源节点在图中存在
                    allNodes.add(source);
                    reverseAdjacencyList.putIfAbsent(source, new ArrayList<>());
                }
                break;
            }
        }
        reader.close();
    }

    // 计算单个节点的影响域
    public Set<Integer> calculateInfluenceDomain(int node) {
        Set<Integer> influenceDomain = new HashSet<>();
        Queue<Integer> queue = new LinkedList<>();
        Map<Integer, Integer> distance = new HashMap<>();
        
        // 初始化：将起始节点加入队列
        influenceDomain.add(node);
        queue.add(node);
        distance.put(node, 0);
        
        // BFS遍历计算影响域
        while (!queue.isEmpty()) {
            int current = queue.poll();
            int currentDist = distance.get(current);
            
            // 如果当前距离已达到最大步数，不再继续
            if (currentDist >= maxSteps) {
                continue;
            }
            
            // 遍历所有指向当前节点的节点（通过反向邻接表）
            for (int neighbor : reverseAdjacencyList.getOrDefault(current, Collections.emptyList())) {
                if (!influenceDomain.contains(neighbor)) {
                    influenceDomain.add(neighbor);
                    queue.add(neighbor);
                    distance.put(neighbor, currentDist + 1);
                }
            }
        }
        
        return influenceDomain;
    }

    // 计算所有节点的影响域并输出结果
    public void calculateAndPrintAllDomains() {
        System.out.println("节点ID\t影响域大小\t影响域节点");
        System.out.println("----------------------------------------");
        float max = -1; 
        float min = 1000;
        
        for (int node : allNodes) {
            Set<Integer> domain = calculateInfluenceDomain(node);
            if(domain.size()>max) {
            	max = domain.size();
            }
            if(domain.size()<min) {
            	min = domain.size();
            }
        }
        
        String orig = "";
        for (int node : allNodes) {
            Set<Integer> domain = calculateInfluenceDomain(node);
            orig = SignatureFormatter.convertMethodNameSN(nodeID2Name.get(node));
            name2Size.putIfAbsent(orig, (domain.size()-min)*1.f/(max-min));
//          System.out.printf("%d\t%d\t\t%s%n", node, domain.size(), domain);
        }
    }
    
    public Map<String, Float> getName2Size() {
		return name2Size;
	}

	public void setName2Size(Map<String, Float> name2Size) {
		this.name2Size = name2Size;
	}
	
	public static Map<String, Float> getInfSize(Path filePath, int ms) {
		
		if (!Files.isRegularFile(filePath))
			throw new RuntimeException("File " + filePath + " does not exists or is not a regular file");
    	
    	System.out.println("[SNAP] reading Influence Size values from the file " + filePath.getFileName().toString());
		
		InfluenceDomainCalculator calculator = null;
		try {
            int maxSteps = ms;
            calculator = new InfluenceDomainCalculator(maxSteps);
            calculator.readNetFile(filePath.toFile());
            calculator.calculateAndPrintAllDomains();
        } catch (NumberFormatException e) {
            System.out.println("错误: 最大步数必须是整数");
        } catch (IOException e) {
            System.out.println("文件读取错误: " + e.getMessage());
        }
        return calculator.getName2Size();
    }

//	public static void main(String[] args) {
//        // 检查命令行参数
//        if (args.length < 2) {
//            System.out.println("用法: java InfluenceDomainCalculator <net文件路径> <最大步数>");
//            System.out.println("示例: java InfluenceDomainCalculator graph.net 2");
//            return;
//        }
//
//        try {
//            String filePath = args[0];
//            int maxSteps = Integer.parseInt(args[1]);
//            
//            InfluenceDomainCalculator calculator = new InfluenceDomainCalculator(maxSteps);
//            calculator.readNetFile(filePath);
//            calculator.calculateAndPrintAllDomains();
//        } catch (NumberFormatException e) {
//            System.out.println("错误: 最大步数必须是整数");
//        } catch (IOException e) {
//            System.out.println("文件读取错误: " + e.getMessage());
//        }
//    }
}

