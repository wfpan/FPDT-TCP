package cn.edu.zjgsu.wfpan.softnet.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

public class BetweennessCalculator {

    public static Map<String, Double> getBetweennessMap(Path filePath) {
        Map<String, Double> betweennessMap = calculateBetweenness(filePath.toFile());
        return betweennessMap;
        // 打印结果
//        for (Map.Entry<String, Double> entry : betweennessMap.entrySet()) {
//            System.out.println("Node: " + entry.getKey() + ", Normalized Betweenness: " + entry.getValue());
//        }
    }

    public static Map<String, Double> calculateBetweenness(File filePath) {
        Map<String, Integer> nodeMap = new HashMap<>();
        List<String[]> edges = new ArrayList<>();
        int nodeCount = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("*Vertices")) {
                    nodeCount = Integer.parseInt(line.split(" ")[1]);
                    for (int i = 0; i < nodeCount; i++) {
                        line = br.readLine().trim();
                        String[] parts = line.split(" ");
                        String nodeName = parts[1].replace("\"", "");
                        nodeMap.put(nodeName, i);
                    }
                } else if (line.startsWith("*Edges")) {
                    while ((line = br.readLine()) != null && !line.startsWith("*")) {
                        line = line.trim();
                        String[] parts = line.split(" ");
                        String source = parts[0];
                        String target = parts[1];
                        double weight = Double.parseDouble(parts[2]);
                        edges.add(new String[]{source, target, String.valueOf(weight)});
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 初始化邻接表
        List<List<Edge>> adjacencyList = new ArrayList<>();
        for (int i = 0; i < nodeCount; i++) {
            adjacencyList.add(new ArrayList<>());
        }

        for (String[] edge : edges) {
            int source = nodeMap.get(edge[0]);
            int target = nodeMap.get(edge[1]);
            double weight = Double.parseDouble(edge[2]);
            adjacencyList.get(source).add(new Edge(target, weight));
        }

        // 计算betweenness
        double[] betweenness = new double[nodeCount];
        for (int source = 0; source < nodeCount; source++) {
            betweenness[source] = calculateSingleSourceBetweenness(source, adjacencyList);
        }

        // 标准化betweenness
        double min = Arrays.stream(betweenness).min().orElse(0.0);
        double max = Arrays.stream(betweenness).max().orElse(0.0);
        Map<String, Double> normalizedBetweennessMap = new HashMap<>();
        String orig = "";
        for (Map.Entry<String, Integer> entry : nodeMap.entrySet()) {
            String nodeName = entry.getKey();
            int nodeIndex = entry.getValue();
            double normalizedValue = (betweenness[nodeIndex] - min) / (max - min);
            orig = SignatureFormatter.convertMethodNameSN(nodeName);
            normalizedBetweennessMap.put(orig, normalizedValue);
        }

        return normalizedBetweennessMap;
    }

    private static double calculateSingleSourceBetweenness(int source, List<List<Edge>> adjacencyList) {
        int n = adjacencyList.size();
        double[] sigma = new double[n];
        double[] delta = new double[n];
        double[] distance = new double[n];
        int[] predecessors = new int[n];
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new LinkedList<>();

        Arrays.fill(sigma, 0.0);
        Arrays.fill(delta, 0.0);
        Arrays.fill(distance, Integer.MAX_VALUE);
        Arrays.fill(predecessors, -1);
        Arrays.fill(visited, false);

        sigma[source] = 1.0;
        distance[source] = 0.0;
        queue.add(source);

        while (!queue.isEmpty()) {
            int current = queue.poll();
            visited[current] = true;

            for (Edge edge : adjacencyList.get(current)) {
                int neighbor = edge.target;
                double weight = edge.weight;

                if (distance[current] + weight < distance[neighbor]) {
                    distance[neighbor] = distance[current] + weight;
                    sigma[neighbor] = sigma[current];
                    predecessors[neighbor] = current;
                    if (!visited[neighbor]) {
                        queue.add(neighbor);
                    }
                } else if (distance[current] + weight == distance[neighbor]) {
                    sigma[neighbor] += sigma[current];
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (i != source) {
                delta[i] = sigma[i] / sigma[source];
            }
        }

        return Arrays.stream(delta).sum();
    }

    static class Edge {
        int target;
        double weight;

        Edge(int target, double weight) {
            this.target = target;
            this.weight = weight;
        }
    }
}
