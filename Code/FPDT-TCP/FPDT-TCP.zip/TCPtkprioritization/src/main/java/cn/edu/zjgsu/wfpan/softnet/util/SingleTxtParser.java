package cn.edu.zjgsu.wfpan.softnet.util;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class SingleTxtParser {

	/** 解析单个文件，返回所有数据行 */
	public static List<DataRow> parse(String filePath) throws Exception {
		return Files.lines(Paths.get(filePath)) // 逐行读取
				.skip(1) // 跳过第一行（字段名）
				.filter(line -> !line.trim().isEmpty()).map(line -> line.split("##", -1))
				.filter(parts -> parts.length == 7)
				.map(parts -> new DataRow(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]))
				.collect(Collectors.toList());
	}
	
	/**
     * 将文件内容按行读取到 List<String>。
     *
     * @param path     文件路径
     * @param charset  字符集（可传 null，默认 UTF-8）
     * @return 每行内容组成的 List
     * @throws IOException 读取失败时抛出
     */
    public static List<String> readLines(Path path, Charset charset) throws IOException {
        if (charset == null) {
            charset = Charset.forName("UTF-8");
        }
        try (var lines = Files.lines(path, charset)) {
            return lines.collect(Collectors.toList());
        }
    }

    /* 重载：默认 UTF-8 */
    public static List<String> readLines(Path path) throws IOException {
        return readLines(path, null);
    }
    
    /**
     * 将 List<String> 写入文件，替换原有内容。
     *
     * @param path     目标文件路径（不存在会自动创建，存在则覆盖）
     * @param lines    待写入的行集合
     * @param charset  字符集（可传 null，默认 UTF-8）
     * @throws IOException 写入失败时抛出
     */
    public static void writeLines(Path path,
                                  List<String> lines,
                                  Charset charset) throws IOException {
        if (charset == null) {
            charset = Charset.forName("UTF-8");
        }
        Files.write(path, lines, charset);
    }

    /* 重载：默认 UTF-8 */
    public static void writeLines(Path path, List<String> lines) throws IOException {
        writeLines(path, lines, null);
    }

	// 简单演示
	public static void main(String[] args) throws Exception {
		List<DataRow> rows = parse(
				"D:\\E-Code\\OU-JavaCourse\\Dataset\\Projects\\assertj\\302749391bd489fd9803824b814bd3842b5c0111\\buggyMethods.txt");
		rows.forEach(System.out::println);
	}
}
