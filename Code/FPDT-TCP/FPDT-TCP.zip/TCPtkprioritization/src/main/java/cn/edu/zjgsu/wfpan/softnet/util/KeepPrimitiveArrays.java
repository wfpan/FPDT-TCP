package cn.edu.zjgsu.wfpan.softnet.util;

/**保留基本类型数据后面的[]，去掉其他类型后的[]*/
public class KeepPrimitiveArrays {

    /** 基本类型正则片段 */
    private static final String PRIMITIVE_REGEX =
            "(?:boolean|byte|short|int|long|char|float|double)";

    /**
     * 仅保留基本类型后的 []，其余全部删除
     */
    public static String retainPrimitiveBrackets(String input) {
        if (input == null) return null;

        /*
         * (?<=\bPRIMITIVE)   前面必须是完整的基本类型单词
         * (?:\[\])*          把基本类型后面的 [] 全部捕获
         * |                  或者
         * \[\]               任何其他位置的 []
         * 替换为：$1         也就是只保留第一组（基本类型后的 []）
         */
        return input.replaceAll(
                "(?<=\\b" + PRIMITIVE_REGEX + ")(\\[\\])*|\\[\\]", "$1");
    }

    /* ------------------ 演示 ------------------ */
    public static void main(String[] args) {
        String[] samples = {
                "int[]",
                "char[][]",
                "boolean[]",
                "java.lang.String[]",
                "Map<String,int[]>",
                "MyClass[]",
                "List<byte[]>",
                "double",
                "Integer[]"
        };
        for (String s : samples) {
            System.out.printf("%-25s -> %s%n", s, retainPrimitiveBrackets(s));
        }
    }
}
