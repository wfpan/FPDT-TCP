package cn.edu.zjgsu.wfpan.softnet.util;

/**
 * 读取指定 CSV：
 *  第1列：java文件路径
 *  第2列：忽略
 *  第3列：方法声明
 *  第4列：float
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 1. 先用计算认知复杂度的那个程序，计算得到方法级的认知复杂度 java_methodCogComplexity.csv
 * 2. 提供前缀
 * 3. 提供method call network
 * 4. 提供 cogValue.csv 保存了每个方法的认知复杂度（有可能为0，可以给他+1）
 * 5. 用认知复杂度去乘以 修改的多少，可以用来判断测试用例的优先级
 * 
 * 读取相关文件，构建方法的认知复杂度值*/

public class CsvReader {
	//@SuppressWarnings("rawtypes") 
	
    // 1. 直接写死 CSV 文件路径
	private static final String version = "0222f08f40c96263aa8ee7180215fa7030fbd3f6";
	private static final String projectName = "scribe";
	private static final String basePath = "D:\\E-Code\\OU-JavaCourse\\Dataset\\Projects\\"+projectName;
    private static final String CSV_PATH = basePath + "\\" + version + "\\" + "main_methodCogComplexity.csv";
    private static final String prefix = basePath + "\\" + version + "\\" + "src\\main\\java\\";
    //D:\E-Code\OU-JavaCourse\Dataset\Projects\joda-time\60fd89df9d362047035484217b4c161a360e58a5\src\main\java\
    private static final String pajeknet = basePath + "\\" + version + "\\" + "SoftNet\\MCN_Pan\\MCN_WD_SoftNet.net";
    private static final String cogValue = basePath + "\\" + version + "\\" + "methodCogValue.csv";
    private static float maxCogValue = 0.f;
    
    private static Map<String,String> newName2OldName = null;
    private static Map<String,Float> cogMap = null;
    
    private static final String PRIMITIVE_REGEX =
//            "(?:boolean|byte|short|int|long|char|float|double)";
    		"(?:boolean|byte|short|int|long|char|float|double)";
    
    /**基本类型后的[]要保留，其他类型后如果有[]都得删除*/
    public static String clean(String type) {
    	if (type == null) return null;
//        return type.replaceAll(
//                "(?<=\\b" + PRIMITIVE_REGEX + ")(\\[\\])*|\\[\\]", "$1");
    	
    	return Pattern.compile("@([^@]*?)(\\[]*)").matcher(type).replaceAll(m ->
        "@" +
        m.group(1).replaceFirst(
                "\\b(?:" + PRIMITIVE_REGEX + ")$", "$0") +
        (m.group(1).matches("\\b(?:" + PRIMITIVE_REGEX + ")$") ? m.group(2) : ""));
    	
    }
    
    public static void saveMapToCsv(Map<String, Float> map) throws IOException {
        String fileName = cogValue;                // 程序内指定
        boolean flag = true;
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            for (Map.Entry<String, Float> e : map.entrySet()) {
            	if(flag) {
            		bw.write("methodName,cogValue,"+1/maxCogValue);
            		bw.newLine();
            		flag = false;
            	}
                bw.write(e.getKey());
                bw.write(',');
                bw.write(e.getValue()+"");
                bw.newLine();
            }
        }
    }

    /**读取method_cognitive.csv文件*/
    public static void parseCSV() {
    	cogMap = new HashMap<String, Float>();
    	
        Path path = Paths.get(CSV_PATH);
        if (!Files.exists(path)) {
            System.err.println("文件不存在: " + CSV_PATH);
            return;
        }

        try (BufferedReader br = Files.newBufferedReader(path)) {
            String line;
            boolean firstLine = true;
            while ((line = br.readLine()) != null) {
                if (firstLine) {            // 跳过标题
                    firstLine = false;
                    continue;
                }
                
                if(line.contains("@SuppressWarnings")) {
//                	System.out.println(line);
                	//ComparatorBasedComparisonStrategy(@SuppressWarnings("rawtypes") Comparator comparator)
                	line = line.replace("\"","").replace("@SuppressWarnings(rawtypes) ", "");
//                	System.out.println(line);
//                	System.exit(0);
                }
                
                line = line.replaceAll("@SuppressWarnings\\(\"rawtypes\"\\)\\s*", "");
                
                line = line.trim();
                if (line.isEmpty()) continue;

                /* -------- 只按第1、第2、最后1个逗号分割 -------- */
                int firstComma  = line.indexOf(',');
                int secondComma = line.indexOf(',', firstComma + 1);
                int lastComma   = line.lastIndexOf(',');

                if (firstComma < 0 || secondComma < 0 || lastComma < 0 ||
                    lastComma <= secondComma) {
                    System.err.println("格式错误，跳过: " + line);
                    continue;
                }

                // col0
                String javaPath   = line.substring(0, firstComma).trim().replace(prefix,"").replace(".java", "").replace("\\", ".");
                // col2（从 secondComma 之后，到最后逗号之前）
                String methodDecl = line.substring(secondComma + 1, lastComma).trim().replace("\"", "");
                // col3
                String floatPart  = line.substring(lastComma + 1).trim();

                float value;
                try {
                    value = Float.parseFloat(floatPart);
                    if(value>maxCogValue) {
                    	maxCogValue = value;
                    }
                } catch (NumberFormatException e) {
                    System.err.println("第四列不是 float，跳过: " + line);
                    continue;
                }
                //转为net文件方法名规范
                String fullMethodName = javaPath + "." + MethodSignatureParser.toCompact(methodDecl); 
                //去掉返回值部分
                String newFullMethodName = fullMethodName.substring(0,fullMethodName.lastIndexOf("#")).trim();
                
                newFullMethodName = newFullMethodName.replace("[]", "");
                
                //org.la4j.factory.Factory.createMatrix@double[][]
                
//				if (newFullMethodName.contains("@double[][]") && !newFullMethodName.equals("org.la4j.factory.Basic1DFactory.createMatrix@double[][]")) {
//					newFullMethodName = newFullMethodName.replace("[]", "");
//				}
//                if("org.la4j.matrix.dense.Basic1DMatrix.Basic1DMatrix@double[][]".equals(newFullMethodName)) {
//                	newFullMethodName = newFullMethodName.replace("[]", "");
//                }
                
//                if("org.la4j.factory.Basic2DFactory.createMatrix@double[][]".equals(newFullMethodName)) {
//                	newFullMethodName = newFullMethodName.replace("[]", "");
//                }
//                
//                if("org.la4j.factory.Factory.createMatrix@double[][]".equals(newFullMethodName)) {
//                	newFullMethodName = newFullMethodName.replace("[]", "");
//                }
//                
//                if("org.la4j.factory.Factory.createVector@double[]".equals(newFullMethodName)) {
//                	newFullMethodName = newFullMethodName.replace("[]", "");
//                }
//                
//                if("org.la4j.matrix.dense.Basic1DMatrix.Basic1DMatrix@int@int@double[]".equals(newFullMethodName)) {
//                	newFullMethodName = newFullMethodName.replace("[]", "");
//                }
                
                if(newFullMethodName.contains("@LinearAlgebra.")) {
                	newFullMethodName = newFullMethodName.replace("@LinearAlgebra.", "@");
                }
                
                if(newFullMethodName.contains("@Vectors.")) {
                	newFullMethodName = newFullMethodName.replace("@Vectors.", "@");
                }
                
                
                //去掉非基本类型后的[][]
                String newFMN = clean(newFullMethodName);
                float tmpValue = 0;
                //newName是类名+方法名（去掉了返回值） vs oldName是net中的名字
                if(newName2OldName.containsKey(newFMN.trim())) {
                	String oldName = newName2OldName.get(newFMN.trim());
                	if(!cogMap.containsKey(oldName)) {
                    	cogMap.put(oldName, value);
                    } else {
                    	tmpValue = cogMap.get(oldName);
                    	if(value>tmpValue) {
                    		cogMap.put(oldName, value); //多个重复，保留最大的那个
                    	}
                    	System.err.println(fullMethodName + " is already in the Map");
                    }
                } else {
                	System.err.println(newFullMethodName + " is not in the software network ");
                	System.out.println(newFMN);
                	System.exit(0);
                }

                // TODO: 这里可调用 MethodSigParser.toCompact(methodDecl)
                System.out.printf("文件=%s | 方法=%s | 数值=%.3f%n",
                                  javaPath, methodDecl, value);
                System.out.println(fullMethodName);
                
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //cog value +1 避免cog 为0的情况，除以max值，单位化一下
        cogMap.replaceAll((k, v) -> (v+1) / maxCogValue);
        
    }
    
    /**
     * 读取 Pajek .net 文件里 *vertices 段中的节点名称
     * @param netPath .net 文件完整路径
     * @return 节点名称列表；若文件不存在或格式异常返回空 List
     */
    public static void readVertexNames(String netPath) {
    	newName2OldName = new HashMap<String, String>();
    	
        Path path = Paths.get(netPath);
        if (!Files.exists(path)) {
            System.err.println(path + " is not therein.");;          // 文件不存在直接返回空列表
        }

        try (BufferedReader br = Files.newBufferedReader(path)) {
            String line;
            boolean inVertices = false;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // 进入 *vertices 段
                if (line.toLowerCase().startsWith("*vertices")) {
                    inVertices = true;
                    continue;
                }

                // 遇到新的段标识则退出
                if (line.startsWith("*")) {
                    break;
                }

                if (inVertices) {
                    // 每行格式：序号 "名称" 或 序号 名称 ...
                    // 用空白分隔，第 2 列就是名称（去掉引号）
                    String[] parts = line.split("\\s+", 3);
                    if (parts.length >= 2) {
                        String name = parts[1];
                        // 去掉首尾引号
                        if (name.startsWith("\"") && name.endsWith("\"") && name.length() > 1) {
                            name = name.substring(1, name.length() - 1);
                        }
//                      nodeNames.add(name);
                        String newName = name.substring(0,name.lastIndexOf("#"));
                        System.out.println(newName);
                        if(name.startsWith("org.assertj.core.error.BasicErrorMessageFactory.unquotedString@String")) {
//                        	System.exit(0);
                        	//org.assertj.core.error.BasicErrorMessageFactory.unquotedString@String
                        	//org.assertj.core.error.BasicErrorMessageFactory.UnquotedString@String
                        	//org.assertj.core.error.BasicErrorMessageFactory.UnquotedString@String
                        }
                        
                        if(newName.contains("@LinearAlgebra.")) {
                        	newName = newName.replace("@LinearAlgebra.", "@");
                        }
                        
                        if(newName.contains("@Vectors.")) {
                        	newName = newName.replace("@Vectors.", "@");
                        }
                        
                        String newName2 = MethodNameSimplifier.simplify(newName);
                        newName2 = newName2.replace("[]", ""); //去掉所有[][] 有时候可能会错 重载
                        if(!newName2OldName.containsKey(newName2)) {
                        	System.out.println("1 " + newName);
                        	newName2OldName.put(newName2.trim(), name.trim());
//                        	if(newName.equals("org.assertj.core.error.BasicErrorMessageFactory.toString")) {
//                        		System.out.println("333" + newName);
//                        		System.exit(0);
//                        	}
                        } else {
                        	System.err.println(newName2 + " is already in the map");
//                        	System.exit(0);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
//        if(newName2OldName.containsKey("org.assertj.core.error.BasicErrorMessageFactory.UnquotedString@String")) {
//        	System.out.println("存在");
//        	System.exit(0);
//        }
//      System.exit(0);
    }
    
    public static void main(String[] args) {
    	try {
    		readVertexNames(pajeknet);
    		parseCSV();
			saveMapToCsv(cogMap);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println("over");
	}
}
