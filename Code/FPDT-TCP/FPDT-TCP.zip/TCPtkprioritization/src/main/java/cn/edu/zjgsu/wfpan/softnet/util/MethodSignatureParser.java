package cn.edu.zjgsu.wfpan.softnet.util;

import java.util.ArrayList;
import java.util.List;

/**将认知复杂度计算中的 方法名，转为SNAP支持的结构
 * void AbstractArrayAssert(final A actual, final Class<?> selfType) 转为
 * AbstractArrayAssert@A@Class#void
 * */
public final class MethodSignatureParser {

    // 去掉所有 <...>（支持嵌套）
    private static String stripGeneric(String s) {
        int depth = 0;
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '<') depth++;
            else if (c == '>') depth--;
            else if (depth == 0) sb.append(c);
        }
        return sb.toString();
    }

    /**转为net中的方法命名规范*/
    public static String toCompact(String raw) {
        raw = stripGeneric(raw).trim();

        /* 1. 分离返回值与方法名+参数表 */
        int close = raw.lastIndexOf(')');
        if (close == -1) throw new IllegalArgumentException("Bad signature");

        String head = raw.substring(0, close + 1);
        String tail = raw.substring(close + 1).trim();   // 括号后内容

        /* 2. 捕获返回值类型 */
        String returnType;
        if (!tail.isEmpty()) {                           // 括号后有显式类型
            returnType = tail.trim();
        } else {                                         // 括号后为空
            int open = head.lastIndexOf('(');
            String before = head.substring(0, open).trim();
            // 前面最后一个空格前的片段就是返回值
            int lastSpace = before.lastIndexOf(' ');
            if (lastSpace >= 0) {
            	String[] tk = before.substring(0, lastSpace).trim()
                .split("\\s+");
                returnType = tk[tk.length - 1];                    // 取真实类型
            } else {
                returnType = "void";                      // 完全没有写返回值
            }
        }

        /* 3. 方法名 */
        int open = head.lastIndexOf('(');
        String beforeParen = head.substring(0, open).trim();
        String[] tokens = beforeParen.split("\\s+");
        String methodName = tokens[tokens.length - 1];

        /* 4. 拆分参数并清洗类型 */
        String paramPart = head.substring(open + 1, close).trim();
        List<String> paramTypes = new ArrayList<>();
        if (!paramPart.isEmpty()) {
            for (String seg : paramPart.split(",")) {
                seg = seg.trim();
                seg = seg.replace("...", "");      // 去掉可变参数
                String[] tks = seg.split("\\s+");
                paramTypes.add(tks[tks.length - 2]); // 倒数第二个是类型
            }
        }

        /* 5. 组装结果 */
        StringBuilder sb = new StringBuilder(methodName);
        for (String t : paramTypes) sb.append('@').append(t);
        sb.append('#').append(returnType);
        return sb.toString();
    }

    /* ---------- 单元测试 ---------- */
    public static void main(String[] args) {
        String[][] tests = {
            {"void AbstractArrayAssert(final A actual, final Class<?> selfType)",
             "AbstractArrayAssert@A@Class#void"},

            {"int foo(String s, Map<String, List<Integer>> m)",
             "foo@String@Map#int"},

            {"List<String> bar()",
             "bar#List"},

            {"protected static native void nativeMethod(int[] a, long l)",
             "nativeMethod@int[]@long#void"},
            
            {"protected static native void nativeMethod(int[][] a, long l)",
            "nativeMethod@int[][]@long#void"},

            {"void method(String s, Object... args)",
             "method@String@Object#void"},

            {"void var(int a, String... b)",
             "var@int@String#void"},

            {"<T> T generic(List<T> list)",
             "generic@List#T"},

            {"noReturn()",
             "noReturn#void"}
        };

        for (String[] t : tests) {
            String actual = toCompact(t[0]);
            if (!actual.equals(t[1])) {
                System.err.printf("FAIL: %s%n  expect: %s%n  actual: %s%n",
                                  t[0], t[1], actual);
            } else {
                System.out.println("PASS: " + actual);
            }
        }
    }
}
