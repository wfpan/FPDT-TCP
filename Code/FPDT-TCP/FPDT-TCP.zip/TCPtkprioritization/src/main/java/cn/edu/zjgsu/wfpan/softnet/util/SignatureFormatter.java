package cn.edu.zjgsu.wfpan.softnet.util;

import java.util.ArrayList;
import java.util.List;
//SignatureFormatter
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignatureFormatter {
	private static final String PRIMITIVE_REGEX =
//          "(?:boolean|byte|short|int|long|char|float|double)";
  		"(?:boolean|byte|short|int|long|char|float|double)";
	
    public static void main(String[] args) {
    	
    	String test1 = "org.assertj.core.api.AbstractAssert.AbstractAssert(A,java.lang.Class<?>)"; 
    	System.out.println(convertMethodName(test1));
    	System.exit(0);
    	
    	String type = "org.la4j.factory.Basic1DFactory.createMatrix@double@M[][]@int[][]";  
    	// 处理
    	String result2 = Pattern.compile("@([^@]*?)(\\[]*)").matcher(type).replaceAll(m ->
        "@" +
        m.group(1).replaceFirst(
                "\\b(?:" + PRIMITIVE_REGEX + ")$", "$0") +
        (m.group(1).matches("\\b(?:" + PRIMITIVE_REGEX + ")$") ? m.group(2) : ""));
    	
    	System.out.println(result2);
    	
    	String original = "ComparatorBasedComparisonStrategy(@SuppressWarnings(\"rawtypes\") Comparator comparator)";

    	// 替换 @SuppressWarnings("rawtypes") 及其后面可能的空白
    	String cleaned = original.replaceAll("@SuppressWarnings\\(\"rawtypes\"\\)\\s*", "");

    	System.out.println(cleaned);
    	// 输出：ComparatorBasedComparisonStrategy(Comparator comparator)
    	System.exit(0);
    	
    	
        // 包含复杂嵌套尖括号的测试用例
        String[] testCases = {
            "test.Complex#case1(Type&lt;&lt;&gt;&gt;)",
            "test.Complex#case2(Type&lt;,&lt;&gt;&gt;)",
            "test.Complex#case3(Type&lt;&lt;&gt;,&lt;&gt;&gt;)",
            "test.Complex#case4(First&lt;Second&lt;Third&gt;&gt;, Fourth&lt;Fifth&lt;Sixth&lt;Seventh&gt;&gt;&gt;)",
            "test.Complex#case5(Mixed&lt;int, List&lt;String&gt;, Map&lt;Long, Object&gt;&gt;)",
            "test.Complex#case5(Map&lt;List&lt;Integer&gt;,Set&lt;Map&lt;Integer,String&gt;&gt;)",
            "test.Complex#case5(Map<List<Integer>,Set<Map<Integer,String>>)",
            "com.wfpan#getName(int,int)"
            
        };
        
        // 执行测试并输出结果
        for (String testCase : testCases) {
            System.out.println("输入: " + testCase);
            String result = convertMethodName(testCase);
            System.out.println("输出: " + result);
            System.out.println("----------------------------------------");
        }
        System.out.println(convertMethodNameSN("org.assertj.core.error.MessageFormatter.format@Description[]@String[]@Object#String"));
    }
    
    public static String convertMethodNameSN(String input) {
    	return input.substring(0,input.lastIndexOf("#")).replace("[]", "");
    }
    
    /**
     * 将方法表示从原始格式转换为目标格式
     * 
     * @param input 输入的方法表示字符串
     * @return 转换后的方法表示字符串
     */
    public static String convertMethodName(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        
        // 解码HTML实体
        String decodedInput = input.replace("&lt;", "<").replace("&gt;", ">").replace("[]","");
        
        // 分割类名和方法部分
        String[] parts = decodedInput.split("#", 2);
        if (parts.length != 2) {
            return input;
        }
        
        String className = parts[0];
        String methodPart = parts[1];
        
        // 提取方法名和参数列表
        Pattern pattern = Pattern.compile("(\\w+)\\((.*)\\)");
        Matcher matcher = pattern.matcher(methodPart);
        
        if (!matcher.matches()) {
            return input;
        }
        
        String methodName = matcher.group(1);
        String parameters = matcher.group(2);
        
        // 处理参数列表
        List<String> processedParams = new ArrayList<>();
        if (!parameters.trim().isEmpty()) {
            // 处理包含逗号的复杂参数分割（确保逗号是参数分隔符而非泛型内部的逗号）
            String[] paramArray = splitParameters(parameters);
            for (String param : paramArray) {
                String trimmedParam = param.trim();
                String paramWithoutGeneric = removeGeneric(trimmedParam);
                processedParams.add(paramWithoutGeneric);
            }
        }
        
        // 构建结果
        StringBuilder result = new StringBuilder();
        result.append(className).append(".").append(methodName);
        
        if (!processedParams.isEmpty()) {
            for (String param : processedParams) {
                result.append("@").append(param);
            }
        }
        
        return result.toString();
    }
    
    /**
     * 智能分割参数列表，处理泛型内部包含逗号的情况
     */
    private static String[] splitParameters(String parameters) {
        List<String> paramList = new ArrayList<>();
        StringBuilder currentParam = new StringBuilder();
        int genericDepth = 0; // 跟踪泛型嵌套深度
        
        for (char c : parameters.toCharArray()) {
            if (c == '<') {
                genericDepth++;
                currentParam.append(c);
            } else if (c == '>') {
                genericDepth--;
                if (genericDepth < 0) genericDepth = 0; // 防止异常情况
                currentParam.append(c);
            } else if (c == ',' && genericDepth == 0) {
                // 只有当不在泛型内部时，逗号才作为参数分隔符
                paramList.add(currentParam.toString().trim());
                currentParam.setLength(0); // 重置当前参数
            } else {
                currentParam.append(c);
            }
        }
        
        // 添加最后一个参数
        if (currentParam.length() > 0) {
            paramList.add(currentParam.toString().trim());
        }
        
        return paramList.toArray(new String[0]);
    }
    
    /**
     * 移除参数类型中的泛型部分，无论有多少层复杂嵌套
     * 只保留第一个'<'之前的内容
     */
    private static String removeGeneric(String param) {
        int firstGenericStart = param.indexOf('<');
        if (firstGenericStart > 0) {
            return param.substring(0, firstGenericStart);
        }
        return param;
    }
}





