package cn.edu.zjgsu.wfpan.file.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * 指定完整CSV路径，追加一行数据工具类
 * 自动：文件不存在则创建 + 首次写入表头 + 后续只追加数据行
 */
public class CsvFileWriterUtil {

    // 记录每个csv文件是否已写过表头
    private final java.util.Map<String, Boolean> FILE_HEADER_FLAG = new java.util.HashMap<>();

    /**
     * 初始化写入表头
     * @param fullCsvPath CSV完整绝对/相对路径
     * @param headerList  表头列名集合
     */
    public void writeHeader(String fullCsvPath, List<String> headerList) {
        // 已标记写过表头，直接返回
        if (FILE_HEADER_FLAG.getOrDefault(fullCsvPath, false)) {
            return;
        }

        File csvFile = new File(fullCsvPath);
        // 父目录不存在则创建
        if (!csvFile.getParentFile().exists()) {
            csvFile.getParentFile().mkdirs();
        }

        // 文件已存在，说明已有表头，标记后返回
        if (csvFile.exists()) {
            FILE_HEADER_FLAG.put(fullCsvPath, true);
            return;
        }

        // 新建文件，写入表头
        try (PrintWriter pw = new PrintWriter(new FileWriter(csvFile))) {
            pw.println(formatCsvLine(headerList));
            FILE_HEADER_FLAG.put(fullCsvPath, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 向指定CSV文件【追加一行数据】
     * @param fullCsvPath CSV完整路径
     * @param rowData     一行的每列数据
     */
    public void appendOneLine(String fullCsvPath, List<String> rowData) {
        File csvFile = new File(fullCsvPath);
        // 父目录不存在先建
        if (!csvFile.getParentFile().exists()) {
            csvFile.getParentFile().mkdirs();
        }

        // 追加模式写入
        try (PrintWriter pw = new PrintWriter(new FileWriter(csvFile, true))) {
            pw.println(formatCsvLine(rowData));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 格式化标准CSV一行，自动转义逗号、双引号、换行符
     */
    private String formatCsvLine(List<String> row) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < row.size(); i++) {
            String cell = row.get(i) == null ? "" : row.get(i);
            // 包含特殊字符则用双引号包裹，内部双引号转义
            if (cell.contains(",") || cell.contains("\"") || cell.contains("\n") || cell.contains("\r")) {
                cell = "\"" + cell.replace("\"", "\"\"") + "\"";
            }
            sb.append(cell);
            if (i != row.size() - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }


    // ========== 测试用法 ==========
    public static void main(String[] args) {
        // 1. 自定义完整CSV路径
        String csvPath = "D:/log/method_perf.csv";
        
        CsvFileWriterUtil csv = new CsvFileWriterUtil();

        // 2. 只需要调用一次写表头，后续不用再管
        csv.writeHeader(csvPath, List.of("方法名", "执行耗时ms", "记录时间", "备注"));

        // 3. 随时追加一行数据
        csv.appendOneLine(csvPath, List.of(
                "calcPrice",
                "45.678",
                new java.sql.Timestamp(System.currentTimeMillis()).toString(),
                "性能测试批次1"
        ));

        // 再追加一行
        csv.appendOneLine(csvPath, List.of(
                "sortData",
                "123.456",
                new java.sql.Timestamp(System.currentTimeMillis()).toString(),
                "排序算法耗时"
        ));
    }
}
