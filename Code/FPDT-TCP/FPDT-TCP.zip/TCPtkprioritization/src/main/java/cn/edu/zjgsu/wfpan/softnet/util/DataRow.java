package cn.edu.zjgsu.wfpan.softnet.util;

public class DataRow {
	public final String methodName;
	public final String filePath;
	public final String dataId; //mutant id
	public final String line;
	public final String original;
	public final String replacement;
	public final String tag;
	public DataRow(String methodName, String filePath, String dataId, String line, String original, String replacement,
			String tag) {
		super();
		this.methodName = methodName;
		this.filePath = filePath;
		this.dataId = dataId;
		this.line = line;
		this.original = original;
		this.replacement = replacement;
		this.tag = tag;
	}
	public String getMethodName() {
		return methodName;
	}
	public String getFilePath() {
		return filePath;
	}
	public String getDataId() {
		return dataId;
	}
	public String getLine() {
		return line;
	}
	public String getOriginal() {
		return original;
	}
	public String getReplacement() {
		return replacement;
	}
	public String getTag() {
		return tag;
	}
	@Override
	public String toString() {
		return "DataRow [methodName=" + methodName + ", filePath=" + filePath + ", dataId=" + dataId + ", line=" + line
				+ ", original=" + original + ", replacement=" + replacement + ", tag=" + tag + "]";
	}
}
