package cn.edu.zjgsu.wfpan.softnet.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class ReadMethodCognitive {

    /**
     * 解析指定格式的 CSV 文件
     *
     * @param csvPath 文件路径
     * @return Map<String, Float>  key = 字符串字段, value = float 字段
     * @throws IOException 读取文件异常
     */
    public static Map<String, Float> parseCsv(Path csvFilePath) throws IOException {
    	
    	if (!Files.isRegularFile(csvFilePath))
			throw new RuntimeException("File " + csvFilePath + " does not exists or is not a regular file");
    	
//    	System.out.println("[SNAP] reading method Cognitive values from the file " + csvFilePath.getFileName().toString());
    	
        Map<String, Float> result = new LinkedHashMap<>();   // 保持顺序

        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath.toFile()))) {
            // 1. 读标题行
            String titleLine = br.readLine();
            if (titleLine == null) {
                throw new IOException("CSV 文件为空");
            }

            // 按逗号切分，取第 3 个部分
            String[] titleParts = titleLine.split(",", -1);
            if (titleParts.length < 3) {
                throw new IOException("标题行不足 3 列");
            }
            float headerValue = Float.parseFloat(titleParts[2].trim());
            result.put("defaultCogValueForZero", headerValue);
            // 如果你想把标题行的这个值也存进去，可自定义 key；示例里先忽略

            // 2. 读后续数据行
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;   // 跳过空行
                }
                String[] parts = line.split(",", -1);
                if (parts.length < 2) {
                    throw new IOException("数据行不足 2 列: " + line);
                }
                String key = parts[0].trim();
              float value = Float.parseFloat(parts[1].trim()); //coc= coc+1
                
                //不直接放，名字修改后放入
//              result.put(key, value);
                String orig = SignatureFormatter.convertMethodNameSN(key);
                if(result.containsKey(orig)) {
//					System.err.println(orig + " 已经在 prVAlue Map 中了");
					if(value>result.get(orig)) {
						result.put(orig, value);
					}
				} else {
//					prValue.put(strNodeName[iTmp], (float)fPageRankBak[iTmp]);
					result.put(orig, value);
//					if("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String".equals(strNodeName[iTmp])) {
//						System.err.println("org.assertj.core.error.MessageFormatter.format@Description@String@Object#String" + "\n" + orig);
//					}
				}
                
            }
        }

        return result;
    }

    // 简单测试
    public static void main(String[] args) {
//        try {
//            Map<String, Float> map = parseCsv("D:\\E-Code\\OU-JavaCourse\\Dataset\\Projects\\assertj\\0f78d7e2ccbeb7bb39ebc5f0510ba84df7c52a5a\\methodCogValue.csv");
//            map.forEach((k, v) -> System.out.println(k + " -> " + v));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }
}
