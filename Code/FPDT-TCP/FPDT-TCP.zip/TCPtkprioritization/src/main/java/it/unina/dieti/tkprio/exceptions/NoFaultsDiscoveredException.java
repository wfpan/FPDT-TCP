package it.unina.dieti.tkprio.exceptions;

public class NoFaultsDiscoveredException extends RuntimeException {

  public NoFaultsDiscoveredException(String message) {
    super(message);
  }
}
