package it.unina.dieti.tkprio.rtp.strategies.helpers;

import it.unina.dieti.tkprio.domain.CoverageReport;
import it.unina.dieti.tkprio.domain.Method;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import org.apache.commons.collections4.BidiMap;
import org.apache.commons.collections4.bidimap.DualHashBidiMap;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Coverage matrix class used with ART-MaxMin and Genetic strategies.
 * */
public class CoverageMatrix {

  private int numTests;

  private int numElements;

  private boolean[][] m;

  private BidiMap<Test, Integer> testMap;

  public static CoverageMatrix create(TestSuite suite, CoverageReport report) {
    CoverageMatrix matrix = new CoverageMatrix();
    Map<String, Integer> elementsToIdMap = mapElementsToId(report);
    matrix.testMap = mapTestsToId(suite);
    matrix.numTests = matrix.testMap.size();
    matrix.numElements = elementsToIdMap.size();
    // Filling matrix entries
    matrix.m = new boolean[matrix.numTests][matrix.numElements];
    for(Test test: suite) {
      int testId = matrix.testMap.get(test);
      for(Method covered: test.getCoveredMethods()) {
        int methodId = elementsToIdMap.get(covered.getSignature());
        matrix.m[testId][methodId] = true;
      }
    }
    return matrix;
  }

  private static Map<String, Integer> mapElementsToId(CoverageReport report) {
    Map<String, Integer> map = new HashMap<>();
    int id = 0;
    for(Method method: report.getMethods())
      map.put(method.getSignature(), id++);
    return map;
  }

  private static BidiMap<Test, Integer> mapTestsToId(TestSuite suite) {
    BidiMap<Test, Integer> map = new DualHashBidiMap<>();
    int id = 0;
    for(Test t : suite)
      map.put(t, id++);
    return map;
  }

  public boolean isCovered(int test, int element) {
    return m[test][element];
  }

  public boolean isCovered(Test t, int element) {
    return m[this.testMap.get(t)][element];
  }

  private CoverageMatrix() {
  }

  public int getTestIndex(Test t) {
    return this.testMap.get(t);
  }

  public Test getTestFromIndex(int index) {
    return this.testMap.inverseBidiMap().get(index);
  }

  public enum Granularity {
    STATEMENT, BRANCH, METHOD
  }

  public int getNumTests() {
    return numTests;
  }

  public int getNumElements() {
    return numElements;
  }

  public boolean[][] getRawMatrix() {
    return this.m;
  }

  public Collection<Test> getTests() {
    return this.testMap.keySet();
  }

}
