package it.unina.dieti.tkprio;

import io.github.cdimascio.dotenv.Dotenv;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**set database root, project folder, faultMatricesFold, dbPath, and resultsFolder*/
public class Configuration {
	/**a static Configuration object*/
	private static Configuration instance;
	
	/**DATASET.ROOT=D:/E-Code/OU-JavaCourse/Dataset*/
	private final Path datasetRoot;
	
	/**DATASET.FOLDERS.PROJECTS=Projects*/
	private final Path projectsFolder;

	/**DATASET.FOLDERS.FAULT_MATRICES=FaultMatrices*/
	private final Path faultMatricesFolder;

	/**EXPERIMENTS.DB.LOCATION=D:/E-Code/OU-JavaCourse/Dataset/Results/sqlite.db*/
	private final Path dbPath;
	
	/**RESULTS.FOLDER=D:/E-Code/OU-JavaCourse/Dataset/Results*/
	private final Path resultsFolder;

	private Configuration(Path datasetRoot, String projectsFolder, String faultMatricesFolder, Path dbPath,
			Path resultsFolder) {
		//D:/E-Code/OU-JavaCourse/Dataset
		this.datasetRoot = datasetRoot;
		if (!Files.isDirectory(this.datasetRoot))
			throw new RuntimeException("Invalid dataset root: " + this.datasetRoot);
		
		//D:/E-Code/OU-JavaCourse/Dataset/Projects
		this.projectsFolder = datasetRoot.resolve(projectsFolder);
		if (!Files.isDirectory(this.projectsFolder))
			throw new RuntimeException("Invalid projects folder: " + this.projectsFolder);
		
		//D:/E-Code/OU-JavaCourse/Dataset/FaultMatrices
		this.faultMatricesFolder = datasetRoot.resolve(faultMatricesFolder);
		if (!Files.isDirectory(this.faultMatricesFolder))
			throw new RuntimeException("Invalid folder for fault matrices: " + this.faultMatricesFolder);
		
//		this.softwareNetworkPath = datasetRoot.resolve(projectsFolder);
		
		//D:/E-Code/OU-JavaCourse/Dataset/Results/sqlite.db
		this.dbPath = dbPath;
		
		// Creating the results directory if needed
		if (!Files.exists(resultsFolder)) {
			try {
				Files.createDirectories(resultsFolder);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		//D:/E-Code/OU-JavaCourse/Dataset/Results
		this.resultsFolder = resultsFolder;
	}

	public Path getDatasetRoot() {
		return this.datasetRoot;
	}

	public Path getProjectsFolder() {
		return this.projectsFolder;
	}

	public Path getFaultMatricesFolder() {
		return this.faultMatricesFolder;
	}

	public Path getDatabasePath() {
		return dbPath;
	}

	public Path getResultsFolder() {
		return resultsFolder;
	}

	/**从.env读取各个路径，并创建一个configuration对象*/
	public static Configuration fromDotenv() {
		if (instance == null) {
			Dotenv dotenv = Dotenv.load();
			//DATASET.ROOT=D:/E-Code/OU-JavaCourse/Dataset
			String root = dotenv.get("DATASET.ROOT");
			//DATASET.FOLDERS.PROJECTS=Projects
			String projectsFolder = dotenv.get("DATASET.FOLDERS.PROJECTS");
			//DATASET.FOLDERS.FAULT_MATRICES=FaultMatrices
			String faultMatricesFolder = dotenv.get("DATASET.FOLDERS.FAULT_MATRICES");
			//EXPERIMENTS.DB.LOCATION=D:/E-Code/OU-JavaCourse/Dataset/Results/sqlite.db
			String dbPath = dotenv.get("EXPERIMENTS.DB.LOCATION");
			//RESULTS.FOLDER=D:/E-Code/OU-JavaCourse/Dataset/Results
			String resultFolder = dotenv.get("RESULTS.FOLDER");
			if (root == null || projectsFolder == null || faultMatricesFolder == null || dbPath == null
					|| resultFolder == null)
				throw new RuntimeException(".env file invalid: have you set it properly?");
			instance = new Configuration(Path.of(root), projectsFolder, faultMatricesFolder, Path.of(dbPath),
					Path.of(resultFolder));
		}
		return instance;
	}

}
