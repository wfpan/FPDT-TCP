package it.unina.dieti.tkprio.rtp.metrics;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.exceptions.NoFaultsDiscoveredException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

public class APFDMetric implements MetricI {

	private static final Logger LOG = LoggerFactory.getLogger(APFDMetric.class);

	public static final String NAME = "APFD";

	private FaultMatrix matrix;

	@Override
	public void setUp(FaultMatrix matrix) {
		this.matrix = matrix;
	}

	@Override
	public String name() {
		return NAME;
	}

	@Override
	public float evaluate(Permutation permutation) {
		Set<Integer> faults = this.matrix.getFaultsDiscoveredByPermutation(permutation);
		if (faults.isEmpty()) {
			LOG.warn("No faults discovered by permutation when evaluating " + NAME);
			throw new NoFaultsDiscoveredException("No faults discovered by permutation");
		}
		int m = 0; // Discovered faults
		int n = permutation.getTests().size();
		float sum = 0;
		for (int fault : faults) {
			int testIdx = this.firstTestDiscoveringFault(permutation, fault);
			if (testIdx != -1) {
				// Fault discovered
				m++;
				sum += testIdx;
			}
		}
		// Evaluating APFD formula
		return 1 - (sum / (n * m)) + 1 / (float) (2 * n);
	}

	private int firstTestDiscoveringFault(Permutation permutation, int fault) {
		int idx = 1;
		for (Test test : permutation) {
			if (this.matrix.discover(test.getName(), fault))
				return idx;
			idx++;
		}
		return -1; // No fault discovered
	}
}
