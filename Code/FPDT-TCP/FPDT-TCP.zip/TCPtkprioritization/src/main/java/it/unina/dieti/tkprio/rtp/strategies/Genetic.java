/*******************************************************************************
 * MIT License
 *
 * Copyright (c) 2023 Università degli Studi di Napoli Federico II
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

package it.unina.dieti.tkprio.rtp.strategies;

/*
 * Genetic Algorithm for Test Case Prioritization.
 * Note: To generate multiple random numbers, we use the Knuth shuffle - A simple algorithm to generate a permutation of n items uniformly at random.
 * Yafeng.Lu@cs.utdallas.edu
 */

import it.unina.dieti.tkprio.domain.CoverageReport;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.io.CloverCoverageParser;
import it.unina.dieti.tkprio.rtp.strategies.helpers.CoverageMatrix;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Genetic implements PrioritizationStrategyI {
  private Path coverageReportPath;

  int GenesNum = 0; //How Many Test Cases.
  final int PopulationSize = 100; //The size of the Population.
  final float CrossoverProbability = 0.8f, MutationProbability = 0.1f; //The Probabilities to Crossover and Mutation.
  static String Directory, matrixFile;

  private CoverageMatrix cm;  // Coverage matrix domain implementation from unina
  char[][] coverageMatrix; //Store the test case coverage information(Matrix).
  int[][] Population; //Store all the Chromosomes in the Population.
  ArrayList<Integer> testCaseCovered = new ArrayList<Integer>(); //Store the Methods that are covered in the Coverage file.

  int[] resultSequence = new int[this.GenesNum]; //Store the Result Test Case Sequence.

  static int Nth = 0; //The Nth Generation.

  private void fillCoverageMatrix() {
    this.coverageMatrix = new char[this.cm.getNumTests()][this.cm.getNumElements()];
    for(Test t: this.cm.getTests()) {
      int i = this.cm.getTestIndex(t);
      for(int j = 0; j < this.cm.getNumElements(); j++)
        this.coverageMatrix[i][j] = this.cm.isCovered(i, j) ? '1' : '0';
    }
    this.testCaseCovered.clear();
    this.initParameters();
  }

  private void initParameters() {
    this.GenesNum = this.cm.getNumTests();
    this.Population = new int[this.PopulationSize][this.GenesNum];
    int columnNum = this.cm.getNumElements();
    // Adding covering test cases to elements
    for(int i=0; i<columnNum; i++){
      boolean covered = false;
      for(int j = 0; j< this.coverageMatrix.length; j++){
        if(this.coverageMatrix[j][i] == '1'){
          covered = true;
          break;
        }
      }
      if(covered){
        this.testCaseCovered.add(i);
      }
    }
  }

  //Read the Coverage File and Store the value to the APBC, APDC or APSC Matrix.
  public float getCoverageMatrix(String coverageFile){
    float metric = 0;

    try{
      BufferedReader br = new BufferedReader(new FileReader(coverageFile));
      //char[][] CoverageMatrix; //Store the test case coverage information(Matrix).
      ArrayList<String> tempAl = new ArrayList<String>();
      int columnNum = 0;
      String line;
      //Read all the rows from the Coverage Matrix and store then in an ArrayList for further process.
      while((line = br.readLine()) != null){
        //System.out.println(line+"\n");
        if(columnNum == 0){
          columnNum = line.length();
        }else if(columnNum != line.length()){
          System.out.println("ERROR: The line from Coverage Matrix File is WORNG.\n"+line);
          System.exit(1);
        }
        tempAl.add(line);
      }
      this.coverageMatrix = new char[tempAl.size()][columnNum]; //Initialize the Coverage Matrix.
      this.GenesNum = tempAl.size(); //Initialize the GenesNum, which is the Test Case Number.
      this.Population = new int[this.PopulationSize][this.GenesNum]; // Initialize the Population.

      //testCaseCovered = new ArrayList<Integer>();
      //Store the information in the ArrayList to the Array.
      for(int i=0; i<tempAl.size(); i++){
        coverageMatrix[i] = tempAl.get(i).toCharArray();
      }

      for(int i=0; i<columnNum; i++){
        boolean covered = false;
        for(int j = 0; j< coverageMatrix.length; j++){
          if(coverageMatrix[j][i] == '1'){
            covered = true;
            break;
          }
        }
        if(covered){
          testCaseCovered.add(i);
        }
      }
			/*Check
			for(int i=0; i<this.CoverageMatrix.length; i++){
				for(int j=0; j<this.CoverageMatrix[0].length; j++){
					if(this.CoverageMatrix[i][j] != '1' && this.CoverageMatrix[i][j] != '0'){
						System.out.println("this.CoverageMatrix is Wrong."+this.CoverageMatrix[i][j]);
						System.exit(1);
					}
				}
			}*/
      //this.Print(testCaseCovered);
      br.close();
    }catch(Exception e){
      e.printStackTrace();
    }
    return metric;
  }

  public float getAveragePercentageCoverage(List<Test> tests) {
    int[] chromosome = new int[tests.size()];
    for(int i = 0, len = tests.size(); i < len; i++)
      chromosome[i] = this.cm.getTestIndex(tests.get(i));
    return this.getAveragePercentageCoverage(chromosome);
  }

  //Compute the Average Percentage Block/Statement/Branch Coverage
  public float getAveragePercentageCoverage(int[] Chromosome){
//    System.out.println(this.testCaseCovered.size() + " vs " + this.coverageMatrix[0].length);
    float AveragePercentageCoverage = 0;
    int firstCoveredSum = 0; //Sum of the first test case in the order that covers the Block/Statement/Branch i.
    //System.out.println("testCaseCovered Size: "+this.testCaseCovered.size());
    for(int k=0; k<this.testCaseCovered.size(); k++){
      for(int i=0; i<Chromosome.length; i++){
        if(this.coverageMatrix[Chromosome[i]][this.testCaseCovered.get(k)] == '1'){
          firstCoveredSum += i;
          break;
        }
      }
    }
    //System.out.println("firstCoveredSum: "+firstCoveredSum);
    AveragePercentageCoverage = 1-(float)((float)firstCoveredSum / (float)(this.GenesNum * this.testCaseCovered.size()))+(1.0F / (float)(2 * this.GenesNum));
    return AveragePercentageCoverage;
  }

  //Get all the Average Percentage Coverage Metric Value in the Population and Compute the Fitness for each Chromosome.
  public float[] getAllAveragePercentageCoverageMetricAndFitness(){
    float Metrics[] = new float[this.PopulationSize];
    float Fitness[] = new float[this.PopulationSize];

    for(int i=0; i<this.PopulationSize; i++){
      Metrics[i] = this.getAveragePercentageCoverage(this.Population[i]);
    }
    float[] tempMetrics = Arrays.copyOf(Metrics, Metrics.length); // Copy the original Array to sort it.
    Arrays.sort(tempMetrics); //Sort the temp Metric Value Array.
    //this.Print(tempMetrics);
    int[] Positions = new int[Metrics.length];
    //Get the Position value for each Chromosome.
    for(int i=0; i<Metrics.length; i++){
      for(int j=0; j<tempMetrics.length; j++){
        if(tempMetrics[j] == Metrics[i]){
          Positions[i] = j+1; //Larger APC will get larger Position Value.
          tempMetrics[j] = -1;
          break;
        }
      }
    }
    //Arrays.sort(Positions);
    //System.out.println("Positions len: "+Positions.length);
    //this.Print(Positions); // Print the Metrics Value.
    //Compute the Fitness for each Chromosome.
    for(int i=0; i<Positions.length; i++){
      Fitness[i] = 2 * ((Positions[i] -1) / (float)this.PopulationSize);
    }
    //this.Print(Fitness);
    return Fitness;
  }
  //Use Stochastic Universal Sampling(SUS) for Selection N individuals.
  public int[] Selection(int N){
    float[] Fitness = this.getAllAveragePercentageCoverageMetricAndFitness(); //Get the Fitness value for each Chromosome.
		/*float totalFitness = 0;

		for(int i=0; i<Fitness.length; i++){
			totalFitness += Fitness[i];
		}

		System.out.println("TotalFitness: "+totalFitness);*/
    //
    //this.Print(Fitness);

    float[] MaxAndMin = this.getMaxAndMin(Fitness); //get the Max and Min Fitness value.
    //System.out.println(this.Nth+" Max: "+MaxAndMin[0]+", Min: "+MaxAndMin[1]);

    int[] Choose = this.SUS(Fitness, N);
    //this.Print(Choose);
    //System.out.println(Choose[0]+":"+Fitness[Choose[0]]+", "+Choose[1]+":"+Fitness[Choose[1]]);

    return Choose;

  }
  //Stochastic Universal Sampling
  public int[] SUS(float[] Fitness, int N){
    double totalFitness = 0; //Sum of fitness.
    double P = 0; //distance between the pointers.

    for(int i=0; i<Fitness.length; i++){
      totalFitness += Fitness[i];
    }
    P = totalFitness / N;
    //System.out.println("P: "+P);
    //Pick random number between 0 and P
    double start = Math.random() * P;
    //Pick n individuals
    int[] individuals = new int[N];
    int index = 0;
    double sum = Fitness[index];
    for(int i=0; i<N; i++){
      // Determine pointer to a segment in the population
      double pointer = start + i * P;
      // Find segment, which corresponds to the pointer
      if (sum >= pointer) {
        individuals[i] = index;
      } else {
        for (++index; index < Fitness.length; index++) {
          sum += Fitness[index];
          if (sum >= pointer) {
            individuals[i] = index;
            break;
          }
        }
      }
    }
    // Return the set of indexes, pointing to the chosen individuals
    return individuals;
  }
  public int[] RWS(float[] Fitness, float[] points, int N){
    int[] keep = new int[N];
    int k=0;
    for(int i=0; i<points.length; i++){
      for(int p=0; p<Fitness.length; p++){
        float sum = 0;
        for(int q=0; q<=p; q++){
          sum += Fitness[q];
        }
        if(sum >= points[i]){
          keep[k] = p;
          k++;
          break;
        }
      }
    }
    return keep;
  }

  public int uniform(int i, int m){ // Returns a random integer i <= uniform(i,m) <= m
    return i+(int)(Math.random() * (m-i));
  }

  public int[] permute(int permutation[], int n)
  {
    int i;
    for (i = 0; i < n; i++) {
      int j = uniform(i, n -1);
      int swap = permutation[i];
      permutation[i] = permutation[j];
      permutation[j] = swap;
    }
    return permutation;
  }
  //Generate the Random Population
  public void GenerateRandomPopulation(){
    int[] Sample = new int[this.GenesNum];
    for(int i=0; i<Sample.length; i++){
      Sample[i] = i;
    }

    for(int j=0; j< this.PopulationSize; j++){
      int[] temp = Arrays.copyOf(Sample, Sample.length);
      this.Population[j] = this.permute(temp, temp.length);
      //this.Print(this.Population[j]); //Print the Population.
    }
  }

  public float[] getMaxAndMin(float[] a){
    float[] results = new float[2];
    results[0] = a[0];
    results[1] = a[0];
    for(int i=0; i<a.length; i++){
      if(a[i] > results[0]){
        results[0] = a[i]; //get the Max.
      }else if(a[i] < results[1]){
        results[1] = a[i]; //get the Min.
      }
    }
    return results;
  }
  public void Print(ArrayList<Integer> a){
    for(int i=0; i<a.size(); i++){
      System.out.print(a.get(i)+" ");
    }
    System.out.println();
  }
  public void Print(int[] a){
    for(int i=0; i<a.length; i++){
      System.out.print(a[i]+" ");
    }
    System.out.println();
  }
  public void Print(float[] a){
    for(int i=0; i<a.length; i++){
      System.out.print(a[i]+" ");
    }
    System.out.println();
  }
  //CrossOver the 2 input Chromosome
  public Object[] CrossOver(int[] a, int[] b){
    if(a.length != b.length){
      System.out.println("Two Array Size is NOT Equal: "+a.length+", "+b.length);
      System.exit(0);
    }
    int len = a.length;
    int[] p1 = Arrays.copyOf(a,  len);
    int[] p2 = Arrays.copyOf(b,  len);

    int random = (int)(Math.random() * len);//2;
    int[] o1 = new int[len], o2 = new int[len];
    ArrayList<Integer> a1 = new ArrayList<Integer>();
    ArrayList<Integer> a2 = new ArrayList<Integer>();

    for(int i=0; i<random; i++){
      o1[i] = p1[i];
      a1.add(o1[i]);
      o2[i] = p2[i];
      a2.add(o2[i]);
    }
    for(int i=0; i<len; i++){
      if(a1.contains(p2[i])){
        p2[i] = -1;
      }
    }
    for(int i=0, j= random; i<len  && j < len; i++){
      if(p2[i] != -1){
        o1[j] = p2[i];
        j++;
      }
    }
    for(int i=0, j = 0; i<len && j<random; i++){
      if(a2.contains(p1[i])){
        p1[i] = -1;
      }
    }
    for(int i=0, j=random; i<len && j < len; i++){
      if(p1[i] != -1){
        o2[j] = p1[i];
        j++;
      }
    }
    //Print(o1);
    //Print(o2);

    return new Object[]{o1, o2};
    //p1 = o1;
    //p2 = o2;
  }

  public void Mutation(int[] Chromosome){ //
    //Randomly select two Genes and exchange their value;
    int pos0=0, pos1=0;

    while(pos0 == pos1){
      pos0 = this.uniform(0, this.GenesNum);
      pos1 = this.uniform(0, this.GenesNum);
			/*System.out.println("ERROR: Mutation() pos0 == pos1.");
			System.exit(1);*/
    }
    //Exchange the two Genes.
    int temp = Chromosome[pos0];
    Chromosome[pos0] = Chromosome[pos1];
    Chromosome[pos1] = temp;
    //System.out.println("Mutation:");
    //this.Print(Chromosome);
    //return Chromosome;
  }
  //Return the Selected Test Case Sequence.
  public int[] StartGeneration(){
    int Generations = 100; //The total number of Generations.

    this.GenerateRandomPopulation(); // Generate the Initial Population.

    //Start the Whole Process for the number of Generations.
    for(int g=0; g<=Generations; g++){
      this.Nth = g; //Store the Nth Generation.
      //System.out.println(g+" Generation Start-----------");
      this.AveragePercentageCoverageCheck(g);
      //this.PopulationCheck("1");
      int[] Individuals = this.Selection(this.PopulationSize); //Select the next generation.
      //this.PopulationCheck("2");

      int[][] tempPopulation = new int[this.PopulationSize][this.GenesNum];
      //System.out.println("Here1.");
      //System.out.print("check");
      //this.Print(Individuals);
      for(int i=0; i<Individuals.length; i++){
        tempPopulation[i] = this.Population[Individuals[i]];
      }
      //this.Print(this.Population[0]);
      this.Population = tempPopulation; // reassign the Selected Population to the Current Population.
      //float[] Fitness = this.getAllAveragePercentageCoverageMetricAndFitness();//Check
      //System.out.print("check");
      //this.Print(Fitness);//Check
      //this.Print(this.Population[0]);
      //this.PopulationCheck("3");

      //CrossOver 80 Chromosomes and Mutate 10 Chromosomes.
      this.CrossOverAndMutate2();

    }//End of the Whole Process.

    float[] Fitness = this.getAllAveragePercentageCoverageMetricAndFitness(); //Get the Result Fitness.
    //System.out.println("Fitness Result: ");
    //this.Print(Fitness);
    // Evaluating the result sequence as the best so far
    int argmax = 0;
    for(int i = 0; i < Fitness.length; i++) {
      if(Fitness[argmax] < Fitness[i])
        argmax = i;
    }
    this.resultSequence = Population[argmax];
    return this.resultSequence;
  }

  public void CrossOverAndMutate2(){//CrossOver 80 Chromosomes and Mutate 10 Chromosomes.
    int[] originalArray = new int[this.PopulationSize];
    for(int i=0; i<this.PopulationSize; i++){ //Initialize the Original Array.
      originalArray[i] = i;
    }
    int[] CrossOverArray = KnuthShuffle(originalArray);
    //this.Print(originalArray);
    //After Randomly select 80 Chromosomes, CrossOver them.
    int CrossOverNum = 80;

    for(int i=0; i<CrossOverNum; i = i+2){
      int parent0 = CrossOverArray[i], parent1 = CrossOverArray[i+1];
      Object[] Offsprings =  this.CrossOver(this.Population[parent0], this.Population[parent1]); //Crossover the 2 Parents.
      //System.out.println("Here3.");
      if(Offsprings.length != 2){
        System.out.println("ERROR: Offersprings len is not 2!");
        System.exit(1);
      }
      this.Population[parent0] = (int[]) Offsprings[0];
      this.Population[parent1] = (int[]) Offsprings[1];
    }
    //Random Select 10 Chromosomes and Mutate.
    int[] MutationArray = KnuthShuffle(originalArray);
    int MutationNum = 10; //Random Select 10 Chromosomes to Mutate.

    for(int i=0; i<MutationNum; i++){
      int select = MutationArray[i];
      this.Mutation(this.Population[select]);
    }
  }

  public int[] KnuthShuffle(int[] a ){
    //Use  Fisher–Yates shuffle(Knuth Shuffle).
    int[] originalArray = Arrays.copyOf(a, a.length);
    Random rnd = new Random();
    for (int i = originalArray.length - 1; i > 0; i--)
    {
      int index = rnd.nextInt(i + 1);
      // Simple swap
      int tmp = originalArray[index];
      originalArray[index] = originalArray[i];
      originalArray[i] = tmp;
    }
    return originalArray;
  }
  public void PopulationCheck(String Message){//check that each Chromosome is Valid.
    //System.out.println(this.GenesNum+">>");
    for(int i=0; i<this.PopulationSize; i++){
      boolean valid = true;
      int validValue = 2211;
      int currentValue = 0;
      for(int j=0; j<this.GenesNum; j++){
        currentValue += this.Population[i][j];
      }
      if(currentValue != validValue){
        System.out.println("ERROR: PopulationCheck()--"+Message);
        this.Print(this.Population[i]);
        System.out.println("-----------------------------");
      }
    }
  }

  public void ChromosomeCheck(int[] c, String message){//check the Chromosome is valid.
    int sum = 0;
    for(int i=0; i<c.length; i++){
      sum += c[i];
    }
		/*if(sum != 2211){
			System.out.println("ERROR: Chromosome is Wrong.--"+message);
			this.Print(c);
		}*/
  }
  public void AveragePercentageCoverageCheck(int g){
    //Print the Max Average Percentage Coverage.
    float Metrics[] = new float[this.PopulationSize];
    float Max = 0, Sum = 0;
    ArrayList<Integer> MaxAPC = new ArrayList<Integer>(); //Store the Chromosome that has the Largest APC.

    for(int i=0; i<this.PopulationSize; i++){
      Metrics[i] = this.getAveragePercentageCoverage(this.Population[i]);
      if(Metrics[i] > Max){
        Max = Metrics[i];
      }
      Sum += Metrics[i];
    }
    for(int i=0; i<Metrics.length; i++){
      if(Metrics[i] == Max){
        MaxAPC.add(i);
      }
    }
//    System.out.println("Max APC: "+Max+", Average: "+(Sum / this.PopulationSize)+", Max APC Num: "+MaxAPC.size());
  }

  //Return the Number of '1' in the Test Case Coverage Array
  public int getNumberOfOneInArray(char[] a){
    int num = 0;
    for(int i=0; i<a.length; i++){
      if(a[i] == '1'){
        num++;
      }
    }
    return num;
  }
  //Merge the New Coverage Array to the Old Array.
  public void MergeTwoCoverageArray(char[] newArray, char[] oldArray){
    if(newArray.length != oldArray.length){
      System.out.println("ERROR: MergeTwoCoverageArray(): 2 Arrays length are not equal.");
    }
    for(int i=0; i<oldArray.length; i++){
      if(newArray[i] == '1'){
        oldArray[i] = newArray[i];
      }
    }
  }


  public static final String NAME = "Genetic";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public void setUp(StrategyPaths paths) {
    this.setCoverageReportPath(paths.getPreviousCoveragePath());
  }

  @Override
  public Permutation prioritize(TestSuite suite) {
    if(this.cm == null)
      this.createCm(suite);
    this.fillCoverageMatrix();
    Permutation permutation = new Permutation();
    int[] selected = this.StartGeneration();
    for(int test: selected)
      permutation.addTest(this.cm.getTestFromIndex(test));
    return permutation;
  }

  private void createCm(TestSuite suite) {
    CloverCoverageParser parser = new CloverCoverageParser();
    CoverageReport report = parser.parse(this.coverageReportPath);
    this.cm = CoverageMatrix.create(suite, report);
  }

  public void setCoverageMatrix(CoverageMatrix cm) {
    this.cm = cm;
  }

  public Genetic setCoverageReportPath(Path coverageReportPath) {
    this.coverageReportPath = coverageReportPath;
    return this;
  }

	/*For Unit Test.
	public static void main(String[] args){
		String directory = "your owen directory";
		String outputFile = "statement_matrix.txt";
		Genetic tc = new Genetic(directory, outputFile);
		tc.StartGeneration();

		//tc.run();
		//int[] p1 = {4, 2, 3, 6, 8}, p2 = {8, 4, 6, 3, 2};
		//Object [] result;
		//result = tc.CrossOver(p1, p2);
		//p1 = (int[])result[0];
		//p2 = (int[])result[1];
		//tc.Print(p1);
		//tc.Print(p2);
		//int Generations = 300; //The total number of Generations.
		//tc.getCoverageMatrix(tc.CoverageFile);
		//tc.GenerateRandomPopulation();
		//tc.getAllAveragePercentageCoverageMetricAndFitness();
		//tc.Selection();

	}*/
}
