package it.unina.dieti.tkprio.benchmarks;

import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

public class AssertjBenchmark {


  @State(Scope.Thread)
  public static class ExecutionState {

    @Param("assertj")
    private String project;

    @Param({"total", "diff", "diff-QS", "MTK", "MTK-QS"})
    private String strategy;

    @Param({"1->2", "1->5", "1->6", "1->7", "1->8", "2->5", "2->6", "2->7", "2->8",
            "5->6", "5->7", "5->8", "6->7", "6->8", "7->8"})
    private String pair;

    private PrioritizationStrategyI technique;

    private TestSuite suite;

    @Setup
    public void setUp() {
      String[] tokens = this.pair.split(Utils.PAIR_SEPARATOR);
      int previousOrder = Integer.parseInt(tokens[0]);
      int currentOrder = Integer.parseInt(tokens[1]);
      StrategyPaths paths = Utils.getPaths(this.project, previousOrder, currentOrder);
      this.suite = Utils.getCommonSuite(this.project, previousOrder, currentOrder);
      this.technique = Utils.getStrategyByName(this.strategy);
      // Setting up the technique
      this.technique.setUp(paths);
    }

  }

  @Benchmark
  public void execute(ExecutionState state, Blackhole bh) {
    bh.consume(state.technique.prioritize(state.suite));
  }
}
