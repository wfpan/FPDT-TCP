package it.unina.dieti.tkprio.generation.faults.domain;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class LineGrainedCoverageReport {

  private final List<Test> tests = new LinkedList<>();

  public List<Test> getTests() {
    return tests;
  }

  public void addTest(Test test) {
    this.tests.add(test);
  }

  public void addTests(Collection<Test> tests) {
    this.tests.addAll(tests);
  }
}
