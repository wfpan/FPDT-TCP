package it.unina.dieti.tkprio.experiments;

import java.util.*;

/**
 * Class aggregating results for metric.
 */
public class MetricAggregatedResult {

  private String project;
  private String previous;
  private int previousOrder;
  private String current;
  private int currentOrder;
  private String metric;

  private Set<String> strategies;
  private final Map<Integer, VariantResults> results = new HashMap<>();

  public String getProject() {
    return project;
  }

  public MetricAggregatedResult setProject(String project) {
    this.project = project;
    return this;
  }

  public String getPrevious() {
    return previous;
  }

  public MetricAggregatedResult setPrevious(String previous) {
    this.previous = previous;
    return this;
  }

  public int getPreviousOrder() {
    return previousOrder;
  }

  public MetricAggregatedResult setPreviousOrder(int previousOrder) {
    this.previousOrder = previousOrder;
    return this;
  }

  public String getCurrent() {
    return current;
  }

  public MetricAggregatedResult setCurrent(String current) {
    this.current = current;
    return this;
  }

  public int getCurrentOrder() {
    return currentOrder;
  }

  public MetricAggregatedResult setCurrentOrder(int currentOrder) {
    this.currentOrder = currentOrder;
    return this;
  }

  public String getMetric() {
    return metric;
  }

  public MetricAggregatedResult setMetric(String metric) {
    this.metric = metric;
    return this;
  }

  public void addResultForVariant(int variant, VariantResults result) {
    this.results.put(variant, result);
  }

  public List<Integer> getVariants() {
    List<Integer> variants = new ArrayList<>(this.results.keySet());
    variants.sort(Integer::compareTo);
    return variants;
  }

  public VariantResults getForVariant(int variant) {
    return this.results.get(variant);
  }

  public Set<String> getStrategies() {
    if(this.strategies == null) {
      this.strategies = new HashSet<>();
      for(VariantResults vr: this.results.values())
        this.strategies.addAll(vr.getStrategies());
    }
    return this.strategies;
  }

  public void updateStrategies() {

  }
}
