package it.unina.dieti.tkprio;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.exceptions.NoFaultsDiscoveredException;
import it.unina.dieti.tkprio.exceptions.NoSuchVariantException;
import it.unina.dieti.tkprio.exceptions.VariantsNotAvailableException;
import it.unina.dieti.tkprio.experiments.Experiment;
import it.unina.dieti.tkprio.experiments.ExperimentResult;
import it.unina.dieti.tkprio.experiments.db.ExperimentDB;
import it.unina.dieti.tkprio.io.FaultMatrixSerializer;
import it.unina.dieti.tkprio.io.ProjectDiscoverer;
import it.unina.dieti.tkprio.io.SurefireReportParser;
import it.unina.dieti.tkprio.rtp.metrics.*;
import it.unina.dieti.tkprio.rtp.strategies.ARTMaxMin;
import it.unina.dieti.tkprio.rtp.strategies.Genetic;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * Main class to execute experiments for non-deterministic baselines.
 */
public class NonDeterministicBaselines {

	private static final Logger LOG = LoggerFactory.getLogger(NonDeterministicBaselines.class);

	private static final int REPETITIONS = 30;

	public static void main(String[] args) {
		ProjectDiscoverer discoverer = new ProjectDiscoverer(Configuration.fromDotenv().getProjectsFolder());
		for (String project : discoverer.getProjects()) {
			System.out.println("Evaluating project " + project);
			executeExperimentsForProject(project, discoverer);
		}
	}

	private static void executeExperimentsForProject(String project, ProjectDiscoverer discoverer) {
		List<String> versions = discoverer.getVersionsForProject(project);
		// Each version is paired with all of its previous versions
		for (int i = 1, versionsLen = versions.size(); i < versionsLen; i++) {
			String current = versions.get(i);
			Path currentFolder = Configuration.fromDotenv().getProjectsFolder().resolve(project).resolve(current);
			System.out.println("  Current version: " + current + " (" + (i + 1) + ")");
			// Checking if there is the variants.xml file for the current version
			if (!Files.isRegularFile(currentFolder.resolve("variants.xml"))) {
				System.out.println("No variants XML found for this version. Skipping");
				continue;
			}
			try {
				for (int j = 0; j < i; j++) {
					String previous = versions.get(j);
					System.out.println("    Previous version: " + previous + " (" + (j + 1) + ")");
					// Repeatedly executing strategies
					try {
						executeAndSaveExperiment(project, previous, j + 1, current, i + 1);
					} catch (NoSuchVariantException e) {
						// In case there are no variants from the previous version,
						// The previous version is skipped
						LOG.warn("No variants for " + project + " " + current + " when paired with " + previous);
					}
				}
			} catch (VariantsNotAvailableException e) {
				// In case no variant is present, experiments
				// with this version as current are skipped
				LOG.warn("No variants found for " + project + " " + current + ". Skipping.");
			}
		}
	}

	private static void executeAndSaveExperiment(String project, String previous, int previousOrder, String current,
			int currentOrder) throws VariantsNotAvailableException, NoSuchVariantException {
		LOG.info("Executing " + REPETITIONS + " repetitions on " + project + " " + previous + " -> " + current);
		ExperimentDB db = new ExperimentDB();
		List<MetricI> metrics = Arrays.asList(new APFDMetric(), new PTFMetric(), new PTLMetric(), new TTLMetric());
		StrategyPaths paths = createPaths(project, previous, current);
		// Extracting common test suite
		SurefireReportParser reportParser = new SurefireReportParser();
		TestSuite previousSuite = reportParser.parse(paths.getPreviousSurefireReportsFolder());
		TestSuite currentSuite = reportParser.parse(paths.getCurrentSurefireReportsFolder());
		TestSuite common = TestSuite.withCommonTests(previousSuite, currentSuite);

		// Creating and setting up techniques
		ARTMaxMin art = new ARTMaxMin();
		Genetic genetic = new Genetic();
		art.setUp(paths);
		genetic.setUp(paths);

		// Starting repetitions of techniques
		List<Permutation> artPermutations = new ArrayList<>(REPETITIONS);
		List<Permutation> geneticPermutations = new ArrayList<>(REPETITIONS);
		System.out.print("      Repetitions:");
		for (int i = 0; i < REPETITIONS; i++) {
			System.out.print(" " + (i + 1));
			artPermutations.add(art.prioritize(common));
			geneticPermutations.add(genetic.prioritize(common));
		}
		System.out.println();
		// Evaluating average for each metric on all variants
		LOG.info("Evaluating metrics for all variants");
		for (MetricI metric : metrics) {
			for (int vId = 1; vId <= 100; vId++) {
				Path faultMatrixPath = Configuration.fromDotenv().getFaultMatricesFolder().resolve(project)
						.resolve(current).resolve(previous).resolve(vId + ".csv");
				if (!Files.isRegularFile(faultMatrixPath)) {
					LOG.warn("No variants found for " + project + " " + current + ". Skipping.");
					continue;
				}
				FaultMatrix matrix = new FaultMatrixSerializer().deserialize(faultMatrixPath);
				metric.setUp(matrix);
				try {
					// Evaluating the scores for the techniques
					List<Float> artScores = new ArrayList<>(REPETITIONS);
					for (Permutation permutation : artPermutations)
						artScores.add(metric.evaluate(permutation));
					List<Float> geneticScores = new ArrayList<>(REPETITIONS);
					for (Permutation permutation : geneticPermutations)
						geneticScores.add(metric.evaluate(permutation));
					float artAvg = (float) artScores.stream().mapToDouble(v -> v).average().getAsDouble();
					float geneticAvg = (float) geneticScores.stream().mapToDouble(v -> v).average().getAsDouble();
					// Creating a dummy experiment for persistence and saving data
					Experiment experiment = new Experiment().setExecutedAt(new Date()).setProject(project)
							.setPrevious(previous).setPreviousOrder(previousOrder).setCurrent(current)
							.setCurrentOrder(currentOrder).addStrategy(art).addStrategy(genetic).addMetric(metric)
							.setVariantId(vId);
					experiment
							.addResult(new ExperimentResult(experiment).setMetric(metric).setStrategy(art)
									.setValue(artAvg))
							.addResult(new ExperimentResult(experiment).setMetric(metric).setStrategy(genetic)
									.setValue(geneticAvg));
					LOG.info("Saving experiment into DB");
					db.save(experiment);
				} catch (NoFaultsDiscoveredException e) {
					LOG.warn("No faults discovered for " + project + " " + previous + " -> " + current + " variant: "
							+ vId + ". Skipping");
				}
			}
		}
	}

	private static StrategyPaths createPaths(String project, String previous, String current) {
		StrategyPaths paths = new StrategyPaths();
		// Getting paths for the current version
		Path currentVersionFolder = Configuration.fromDotenv().getProjectsFolder().resolve(project).resolve(current);
		paths.setCurrentSurefireReportsFolder(currentVersionFolder.resolve("surefire-reports"));
		// Getting paths for the previous version
		Path previousVersionFolder = Configuration.fromDotenv().getProjectsFolder().resolve(project).resolve(previous);
		paths.setPreviousSurefireReportsFolder(previousVersionFolder.resolve("surefire-reports"));
		paths.setPreviousCoveragePath(previousVersionFolder.resolve("clover-report-method-1.1.xml"));
		return paths;
	}

}
