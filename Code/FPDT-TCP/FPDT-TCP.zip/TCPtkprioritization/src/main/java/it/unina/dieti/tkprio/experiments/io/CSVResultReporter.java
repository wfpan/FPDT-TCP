package it.unina.dieti.tkprio.experiments.io;

import it.unina.dieti.tkprio.experiments.MetricAggregatedResult;
import it.unina.dieti.tkprio.experiments.VariantResults;
import it.unina.dieti.tkprio.experiments.db.ExperimentDB;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Class responsible to extract data from DB and
 * to save it in CSV format.
 */
public class CSVResultReporter {

  private static final Logger LOG = LoggerFactory.getLogger(CSVResultReporter.class);

  private final char delimiter;


  public CSVResultReporter() {
    this(',');
  }

  public CSVResultReporter(char delimiter) {
    this.delimiter = delimiter;
  }

  /**
   * Saves all the results for the pair of versions of the
   * given project available in the database to CSV files
   * in the output result folder.
   *
   * @param project    The project's name
   * @param previous   The previous version in the pair
   * @param current    The current version in the pair
   * @param outputRoot The root of the output result folder
   */
  public void save(String project, String previous, String current, Path outputRoot) {
    ExperimentDB db = new ExperimentDB();
    Path projectResultFolder = outputRoot.resolve(project);
    try {
      if(!Files.isDirectory(projectResultFolder))
        Files.createDirectories(projectResultFolder);
      Collection<MetricAggregatedResult> results = db.retrieveForPair(project, previous, current);
      for(MetricAggregatedResult mar : results)
        this.saveAggregatedResult(mar, projectResultFolder);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private void saveAggregatedResult(MetricAggregatedResult mar, Path folder) {
    Path csvFile = folder.resolve(mar.getMetric() + "_" + mar.getPreviousOrder()
        + "_" + mar.getCurrentOrder() + ".csv");
    try(PrintWriter writer = new PrintWriter(csvFile.toFile())) {
      // Writing header
      List<String> strategies = new ArrayList<>(mar.getStrategies());
      StringBuilder sb = new StringBuilder();
      for(String strategy : strategies)
        sb.append(strategy).append(this.delimiter);
      sb.deleteCharAt(sb.length() - 1);
      writer.println(sb);
      // Writing all results
      for(int variant: mar.getVariants()) {
        VariantResults vr = mar.getForVariant(variant);
        sb = new StringBuilder();
        for(String strategy: strategies)
          sb.append(vr.getResultForStrategy(strategy)).append(this.delimiter);
        sb.deleteCharAt(sb.length() - 1);
        writer.println(sb);
      }
      LOG.info("Data saved to " + csvFile);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    }
  }

}
