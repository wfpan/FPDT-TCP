package it.unina.dieti.tkprio.util;

import it.unina.dieti.tkprio.ast.ASTNode;
import it.unina.dieti.tkprio.ast.ASTRepresentation;

import java.util.Stack;

public class ASTPrinter {

  private ASTPrinter() { }

  public static void print(ASTRepresentation body) {
    if(body == null) {
      System.out.println("//");
      return;
    }
    Stack<ASTNode> nodeStack = new Stack<>();
    Stack<Integer> indentStack = new Stack<>();
    nodeStack.push(body.getAstRoot());
    indentStack.push(0);
    while(!nodeStack.isEmpty()) {
      ASTNode node = nodeStack.pop();
      int indent = indentStack.pop();
      System.out.print("  ".repeat(indent));
      if(node.getChildren().size() > 0) {
        System.out.println(node.getAstContent().getInstructionType());
        // Adding children in reverse order to preserve source file's original order
        for(int i = node.getNoOfChildren() - 1; i >= 0; i--) {
          ASTNode child = node.getChildrenAsAstNodes().get(i);
          nodeStack.push(child);
          indentStack.push(indent + 1);
        }
      } else  // Leaf
        System.out.println(node.getAstContent().getLexeme());
    }
  }

}
