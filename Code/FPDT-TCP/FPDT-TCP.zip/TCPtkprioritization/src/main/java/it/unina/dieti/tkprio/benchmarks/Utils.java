package it.unina.dieti.tkprio.benchmarks;

import it.unina.dieti.tkprio.Configuration;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.io.ProjectDiscoverer;
import it.unina.dieti.tkprio.io.SourceFileLister;
import it.unina.dieti.tkprio.io.SurefireReportParser;
import it.unina.dieti.tkprio.rtp.strategies.*;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

import java.nio.file.Path;
import java.util.List;

public class Utils {

  // Characters separating pairs in a string
  public static final String PAIR_SEPARATOR = "->";

  private Utils() { }

  public static StrategyPaths getPaths(String project, int previousOrder, int currentOrder) {
    StrategyPaths paths = new StrategyPaths();
    Path projectsRoot = Configuration.fromDotenv().getProjectsFolder();
    ProjectDiscoverer discoverer = new ProjectDiscoverer(projectsRoot);
    List<String> versions = discoverer.getVersionsForProject(project);
    String previous = getShaFromOrder(project, previousOrder);
    String current = getShaFromOrder(project, currentOrder);
    Path previousCoverage = projectsRoot.resolve(project).resolve(previous).resolve("clover-report-method-1.1.xml");
    SourceFileLister lister = new SourceFileLister(projectsRoot);
    paths.setPreviousSources(lister.listForOriginalVersion(project, previous));
    paths.setCurrentSources(lister.listForOriginalVersion(project, current));
    paths.setPreviousCoveragePath(previousCoverage);
    paths.setPreviousSurefireReportsFolder(getSurefireReportsPath(project, previous));
    paths.setCurrentSurefireReportsFolder(getSurefireReportsPath(project, current));
    return paths;
  }

  public static PrioritizationStrategyI getStrategyByName(String name) {
    switch(name) {
      case "total":
        return new TotalPrioritization();
      case "diff":
        return new DiffPrioritization();
      case "diff-QS":
        return new QuotientSetPrioritization(new DiffPrioritization());
      case "MTK":
        return new MTKPrioritization();
      case "MTK-QS":
        return new QuotientSetPrioritization(new MTKPrioritization());
      default:
        throw new RuntimeException("Strategy unknown: " + name);
    }
  }

  public static TestSuite getCommonSuite(String project, int previousOrder, int currentOrder) {
    String previous = getShaFromOrder(project, previousOrder);
    String current = getShaFromOrder(project, currentOrder);
    SurefireReportParser parser = new SurefireReportParser();
    TestSuite previousSuite = parser.parse(getSurefireReportsPath(project, previous));
    TestSuite currentSuite = parser.parse(getSurefireReportsPath(project, current));
    return TestSuite.withCommonTests(previousSuite, currentSuite);
  }

  public static String getShaFromOrder(String project, int order) {
    ProjectDiscoverer discoverer = new ProjectDiscoverer(Configuration.fromDotenv().getProjectsFolder());
    List<String> versions = discoverer.getVersionsForProject(project);
    return versions.get(order - 1);
  }

  private static Path getSurefireReportsPath(String project, String version) {
    return Configuration.fromDotenv().getProjectsFolder().resolve(project)
        .resolve(version).resolve("surefire-reports");
  }

}
