package it.unina.dieti.tkprio.rtp.metrics;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;

public interface MetricI {

	String name();

	void setUp(FaultMatrix matrix);

	float evaluate(Permutation permutation);

}
