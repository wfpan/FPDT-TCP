package it.unina.dieti.tkprio.ast;

import it.uniroma2.sag.kelp.data.representation.structure.StructureElement;

import javax.annotation.Nonnull;

public class ASTContent extends StructureElement {
  // Empty instruction type
  public static final String EMPTY_IT = "empty";

  // Content for empty nodes
  public static final ASTContent EMPTY_CONTENT = new ASTContent();

  // Initializes the empty content
  static {
    ASTContent.EMPTY_CONTENT.setInstructionType(ASTContent.EMPTY_IT);
  }

  // Constant used to define syntactic sugar
  private static final String SQ_LEFT_BRACKET = "[";
  private static final String SQ_RIGHT_BRACKET = "]";
  private static final String SEPARATOR_ATTR = ";";
  private static final String SEPARATOR_NAME_VALUE = "=";

  // Constant used to fixed attribute name, as instruction types and intervals
  private static final String ATTR_NAME_IT = "it";
  private static final String ATTR_NAME_LEXEME = "lex";

  // Type of instruction
  private String instructionType = "";

  // Lexeme of the node if it is a leaf
  private String lexeme;

  public String getInstructionType() {
    return this.instructionType;
  }

  public void setInstructionType(String instructionType) {
    this.instructionType = instructionType;
  }

  public String getLexeme() {
    return lexeme;
  }

  public void setLexeme(String lexeme) {
    this.lexeme = lexeme;
  }

  /**
   * Defines the way content has to be created from text.
   * @param astElementDescription - The text content of the node
   * @throws Exception if the text content is invalid
   * */
  @Override
  public void setDataFromText(String astElementDescription) throws Exception {
    // Getting indexes of opening and closing brackets
    int oIndex = astElementDescription.indexOf(ASTContent.SQ_LEFT_BRACKET);
    int cIndex = astElementDescription.indexOf(ASTContent.SQ_RIGHT_BRACKET);
    if(oIndex == -1) throw new Exception("Content opening symbol not found");
    if(cIndex == -1) throw new Exception("Content closing symbol not found");
    // Extracting attributes from content
    String contentDescription = astElementDescription.substring(oIndex + 1, cIndex);
    for(String attrDesc: contentDescription.split(ASTContent.SEPARATOR_ATTR))
      this.parseAttribute(attrDesc);
  }

  /**
   * Gets text representation of data contained in the node.
   * @return String - Text representation of node content
   * */
  @Override
  public String getTextFromData() {
    return (this.instructionType == null || this.instructionType.equals("") ?
        this.lexeme : this.instructionType);
  }

  public boolean isLexeme() {
    return !"".equals(this.instructionType);
  }

  /**
   * Gets the extensive description of content.
   * @return String
   * */
  public String getExtensiveTextFromData() {
    StringBuilder s = new StringBuilder(ASTContent.SQ_LEFT_BRACKET);  // Opening
    // Converting instruction type
    s.append(ASTContent.ATTR_NAME_IT).append(ASTContent.SEPARATOR_NAME_VALUE)
        .append(this.instructionType).append(ASTContent.SEPARATOR_ATTR);
    // Converting lexeme if any
    if(this.lexeme != null) {
      s.append(ASTContent.SEPARATOR_ATTR).append(ASTContent.ATTR_NAME_LEXEME).append(
          ASTContent.SEPARATOR_NAME_VALUE).append(this.lexeme);
    }
    // Closing and return
    return s.append(ASTContent.SQ_RIGHT_BRACKET).toString();
  }

  /**
   * Parses an attribute, that is a (name, value) match, assigning it to
   * the right field.
   * @param attrDesc Attribute description
   * @throws Exception if description text is invalid
   * */
  private void parseAttribute(@Nonnull String attrDesc) throws Exception {
    int indexSep = attrDesc.indexOf(ASTContent.SEPARATOR_NAME_VALUE);
    if(indexSep == -1) throw new Exception("Unable to find name/value separator");
    // Checking attribute's name in order to update the right field
    String attrName = attrDesc.substring(0, indexSep);
    switch (attrName) {
      case ASTContent.ATTR_NAME_IT:
        this.instructionType = attrDesc.substring(indexSep + 1);
        break;
      case ASTContent.ATTR_NAME_LEXEME:
        this.lexeme = attrDesc.substring(indexSep + 1);
        break;
      default:
        throw new Exception("Invalid attribute name");
    }
  }

}
