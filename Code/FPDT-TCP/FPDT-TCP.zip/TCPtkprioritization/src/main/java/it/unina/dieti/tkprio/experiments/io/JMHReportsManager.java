package it.unina.dieti.tkprio.experiments.io;

import it.unina.dieti.tkprio.benchmarks.Utils;
import it.unina.dieti.tkprio.experiments.ExecutionTimeResult;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class JMHReportsManager {

  public Collection<ExecutionTimeResult> parse(Path csvReport) {
    try(Scanner scanner = new Scanner(csvReport.toFile())) {
      if(!scanner.hasNextLine())
        throw new RuntimeException("Specified report is empty: " + csvReport);
      scanner.nextLine();  // Ignoring header
      Collection<ExecutionTimeResult> results = new LinkedList<>();
      while(scanner.hasNextLine()) {
        List<String> tokens = this.tokenizeLine(scanner.nextLine());
        String[] orders = tokens.get(7).split(Utils.PAIR_SEPARATOR);
        String project = tokens.get(8);
        int previousOrder = Integer.parseInt(orders[0]);
        int currentOrder = Integer.parseInt(orders[1]);
        ExecutionTimeResult result = new ExecutionTimeResult()
            .setProject(project)
            .setTechnique(tokens.get(9))
            .setTime(Float.parseFloat(tokens.get(4)))
            .setStandardDeviation(Float.parseFloat(tokens.get(5)))
            .setPreviousOrder(previousOrder)
            .setPrevious(Utils.getShaFromOrder(project, previousOrder))
            .setCurrentOrder(currentOrder)
            .setCurrent(Utils.getShaFromOrder(project, currentOrder));
        results.add(result);
      }
      return results;
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    }
  }

  private List<String> tokenizeLine(String line) {
    List<String> tokens = new LinkedList<>();
    boolean quotesOpened = false;
    int lastDivider = 0;
    char[] chars = line.toCharArray();
    for(int i = 0; i < chars.length; i++) {
      if(chars[i] == '"')  // Checking if quotes were opened
        quotesOpened = !quotesOpened;
      else if(chars[i] == ',' && !quotesOpened) {  // New token
        String token = this.normalizeToken(line.substring(lastDivider + 1, i));
        tokens.add(token);
        lastDivider = i;
      }
    }
    // Adding the last token
    tokens.add(this.normalizeToken(line.substring(lastDivider + 1, chars.length)));
    return tokens;
  }

  private String normalizeToken(String token) {
    return token.replace(",", ".")  // Correcting decimal separator
        .replace("\"", "").trim();
  }

  public void toCsv(Collection<ExecutionTimeResult> results, Path output) {
    try (PrintWriter writer = new PrintWriter(output.toFile())) {
      // Writing header
      writer.println("Project,Previous,PreviousOrder,Current,CurrentOrder,Technique,Time");
      for(ExecutionTimeResult result: results) {
        writer.println(result.getProject() + ","
            + result.getPrevious() + "," + result.getPreviousOrder() + ","
            + result.getCurrent() + "," + result.getCurrentOrder() + ","
            + result.getTechnique() + "," + result.getTime());
      }
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

}
