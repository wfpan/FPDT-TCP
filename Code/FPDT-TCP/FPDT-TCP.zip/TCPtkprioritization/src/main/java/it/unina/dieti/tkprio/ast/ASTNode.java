package it.unina.dieti.tkprio.ast;

import it.uniroma2.sag.kelp.data.representation.tree.node.TreeNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Tree node specialization in order to cope with
 * Abstract Syntax Tree nodes.
 *
 * @author Francesco Altiero
 * */
public class ASTNode extends TreeNode {

  /**
   * Creates an AST node with given id, content and parent.
   * @param id The unique identifier for the node in the tree
   * @param content Labels related to the node
   * @param parent The parent node. If this node is the root
   *               node, then <em>null</em> should be passed
   * */
  public ASTNode(int id, ASTContent content, ASTNode parent) {
    super(id, content, parent);
  }

  public void addChild(ASTNode astNode) {
    this.getChildren().add(astNode);
  }

  /**
   * Gets the content of the node, as an AstContent object.
   * @return The AST content of this node
   * */
  public ASTContent getAstContent() {
    return (ASTContent) this.getContent();
  }

  /**
   * Sets the AST content of the node.
   * @param content The node's content
   * */
  public void setAstContent(ASTContent content) {
    this.setContent(content);
  }

  /**
   * Gets the parent of this node.
   * @return The AstNode object which is parent
   *  of the node, null if this node is the tree root
   * */
  public ASTNode getParent() {
    return (ASTNode) this.getFather();
  }

  /**
   * Get the list of AST nodes which are the children
   * of this node.
   * @return The list of AstNode objects which are
   *  children of this node
   * */
  public List<ASTNode> getChildrenAsAstNodes() {
    List<ASTNode> children = new ArrayList<>();
    for(TreeNode c: this.getChildren())
      children.add((ASTNode)c);
    return children;
  }

  /**
   * Gets all AST nodes in the subtree rooted
   * in this node.
   * @return The list of AstNode objects which
   *  are in the subtree
   * */
  public List<ASTNode> getAllNodesAsAstNodes() {
    List<ASTNode> nodes = new ArrayList<>();
    nodes.add(this);
    for(ASTNode c: this.getChildrenAsAstNodes())
      nodes.addAll(c.getAllNodesAsAstNodes());
    return nodes;
  }

  /**
   * Gets all descendants, up to a given generation,
   * of this node.
   * @param generation The bound on the generation
   *                   of descendants
   * @return All descendant nodes up to the given
   *  generation
   * */
  public List<ASTNode> getDescendantsAsAstNodes(int generation) {
    if(generation <= 1)
      return this.getChildrenAsAstNodes();
    else {
      List<ASTNode> desc = new ArrayList<>();
      for(ASTNode c: this.getChildrenAsAstNodes())
        desc.addAll(c.getDescendantsAsAstNodes(generation - 1));
      return desc;
    }
  }

  /**
   * Gets the ancestor of this node of the
   * specified generation. If the search exceed
   * the root, <em>null</em> will be returned.
   * @param generation The generation for the desired
   *                   ancestor
   * @return The ancestor of the given generation or <em>null</em>
   * */
  public ASTNode getAncestorAsAstNode(int generation) {
    ASTNode anc = this;
    for(int i = 0; i < generation; i++) {
      if(anc.getParent() == null)
        return null;
      else
        anc = anc.getParent();
    }
    return anc;
  }

  /**
   * Gets all AST nodes which are leaves between
   * the children of this node.
   * @return The list of AstNode objects which are
   *  terminal (leaf) nodes between the children
   *  of this node
   * */
  public List<ASTNode> getLeavesAsAstNodes() {
    List<ASTNode> leaves = new ArrayList<>();
    for(ASTNode c: this.getChildrenAsAstNodes())
      if(!c.hasChildren())
        leaves.add(c);
    return leaves;
  }

  /**
   * Gets the position of this node in its parent.
   * @return The position of this node in the parent node
   * */
  public int getPositionInParent() {
    if(this.getFather() != null) {
      int pos = 0;
      for(TreeNode n : this.getFather().getChildren())
        if(this == n)
          return pos;
        else
          pos++;
    }
    return 0;  // Root node
  }

  /**
   * Gets the depth of this node.
   * @return The depth of the node in its subtree
   * */
  public int getDepth() {
    TreeNode n = this;
    int depth = 0;
    while(n.getFather() != null) {
      depth++;
      n = n.getFather();
    }
    return depth;
  }

  @Override
  public String toString() {
    if(this.getContent() instanceof ASTContent) {
      return this.getChildren().size() > 0 ?
          this.getAstContent().getInstructionType()
          : this.getAstContent().getLexeme();
    } else
      return this.getContent().getTextFromData();
  }
}
