package it.unina.dieti.tkprio.generation.faults.io;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Mutant;
import it.unina.dieti.tkprio.domain.Variant;
import it.unina.dieti.tkprio.domain.VariantSet;
import it.unina.dieti.tkprio.generation.faults.domain.CoveredFile;
import it.unina.dieti.tkprio.generation.faults.domain.LineGrainedCoverageReport;
import it.unina.dieti.tkprio.generation.faults.domain.Test;
import it.unina.dieti.tkprio.io.VariantParser;

import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

public class FaultMatrixGenerator {

  private final VariantParser variantParser = new VariantParser();
  private final CoverageLineParser coverageLineParser = new CoverageLineParser();

  public FaultMatrix generate(String variantsXml, String from, String cloverReport, int variantId) {
    try {
      VariantSet variantSet = variantParser.parse(Path.of(variantsXml));
      LineGrainedCoverageReport report = coverageLineParser.parse(Path.of(cloverReport));
      List<Variant> variants = variantSet.getVariantsFrom(from);
      Optional<Variant> variant = variants.stream().filter(v -> v.getId() == variantId).findAny();
      if(variant.isEmpty())
        throw new RuntimeException("Unable to find variant with id " + variantId);
      return this.generate(variant.get(), report);
    } catch (Exception ex) {
      throw new RuntimeException(ex);
    }
  }

  public FaultMatrix generate(Variant variant, LineGrainedCoverageReport report) {
    FaultMatrix matrix = new FaultMatrix();
    matrix.setProject(variant.getProject());
    matrix.setVersion(variant.getVersion());
    matrix.setVariant(variant.getId());
    // Preliminary adding all tests
    for(Test test : report.getTests())
      matrix.addTest(test.getName());
    // Searching mutants covered by tests
    for(Mutant mutant : variant.getMutants()) {
      String filename = mutant.getFile();
      int line = mutant.getLine();
      for(Test test : report.getTests()) {
        CoveredFile cf = test.getCoveredFile(filename);
        if(cf != null && cf.getLines().contains(line))
          matrix.addFaultToTest(test.getName(), mutant.getId());
      }
    }
    return matrix;
  }
}
