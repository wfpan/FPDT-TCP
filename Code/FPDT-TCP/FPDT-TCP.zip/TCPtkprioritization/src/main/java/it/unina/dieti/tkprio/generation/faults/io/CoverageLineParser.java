package it.unina.dieti.tkprio.generation.faults.io;

import it.unina.dieti.tkprio.generation.faults.domain.CoveredFile;
import it.unina.dieti.tkprio.generation.faults.domain.LineGrainedCoverageReport;
import it.unina.dieti.tkprio.generation.faults.domain.Test;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class CoverageLineParser {

  private static final String FILE_SEPARATOR = System.getProperty("file.separator");
  private static final String DEFAULT_SEPARATOR = "/";

  public LineGrainedCoverageReport parse(Path path) throws ParserConfigurationException, SAXException, IOException {
    if(!Files.isRegularFile(path))
      throw new RuntimeException("File " + path + " does not exists or is not a regular file");
    ParserTask task = new ParserTask();
    SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
    parser.parse(path.toFile(), task);
    return task.report;
  }

  /**
   * SAX parser task to create the report. Allow parallel
   * extraction of reports.
   */
  private static class ParserTask extends DefaultHandler {

    private Map<String, Test> tests;
    private LineGrainedCoverageReport report;
    private String file;
    private int line;

    private final static String E_REPORT = "coverage";
    private final static String E_PACKAGE = "package";
    private final static String E_FILE = "file";
    private final static String E_CLASS = "class";
    private final static String E_METHOD = "method";
    private final static String E_SIGNATURE = "signature";
    private final static String E_PARAMETER = "parameter";
    private final static String E_TEST = "test";
    private final static String E_LINE = "line";

    private final static String A_PACKAGE_NAME = "name";
    private final static String A_FILE_PATH = "path";
    private final static String A_FILE_NAME = "name";
    private final static String A_CLASS_NAME = "name";
    private final static String A_METHOD_NAME = "name";
    private final static String A_METHOD_VISIBILITY = "visibility";
    private final static String A_SIGN_RET_TYPE = "returnType";
    private final static String A_PARAM_TYPE = "type";
    private final static String A_PARAM_NAME = "name";
    private final static String A_TEST_NAME = "name";
    private final static String A_LINE_NUMBER = "num";


    @Override
    public void startDocument() throws SAXException {
      this.report = new LineGrainedCoverageReport();
      this.tests = new HashMap<>();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
      switch(qName) {
        case E_FILE:
          this.file = this.normalizeFilename(attributes.getValue(A_FILE_PATH));
          break;
        case E_TEST:
          Test test = this.getTest(attributes.getValue(A_TEST_NAME));
          CoveredFile cf = this.getCoveredFileForTest(test, this.file);
          cf.addLine(this.line);
          break;
        case E_LINE:
          this.line = Integer.parseInt(attributes.getValue(A_LINE_NUMBER));
          break;
      }
    }

    @Override
    public void endDocument() {
      this.report.addTests(this.tests.values());
    }

    private String getVisibility(String visibility) {
      if("package".equals(visibility))
        return "";
      return visibility;
    }

    private Test getTest(String name) {
      if(!this.tests.containsKey(name)) {
        // Newly discovered test: adding to the map
        Test test = new Test();
        test.setName(name);
        this.tests.put(name, test);
        return test;
      }
      // Already in the map: simply returning it
      return this.tests.get(name);
    }

    private String normalizeFilename(String filename) {
      String sourcesBase = FILE_SEPARATOR + "src"
          + FILE_SEPARATOR + "main" + FILE_SEPARATOR + "java" + FILE_SEPARATOR;
      int index = filename.lastIndexOf(sourcesBase);
      if(index != -1)
        return filename.substring(index + sourcesBase.length()).replace(FILE_SEPARATOR, DEFAULT_SEPARATOR);
      return filename;
    }

    private CoveredFile getCoveredFileForTest(Test test, String name) {
      CoveredFile cf = test.getCoveredFile(name);
      if(cf == null) {  // Not found: creating
        cf = new CoveredFile();
        cf.setFilename(name);
        test.addCoveredFiles(cf);  // Adding the covered file to the actual test
      }
      return cf;
    }
  }

}
