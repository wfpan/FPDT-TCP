package it.unina.dieti.tkprio.rtp.strategies.helpers;

import it.unina.dieti.tkprio.domain.Test;

import java.util.List;

public class TotalCoverageSelector implements QSSelectorI {

	@Override
	public Test select(List<Test> equivalenceClass) {
		Test selected = null;
		int maxCovered = -1;
		for (Test test : equivalenceClass) {
			int covered = test.getCoveredMethods().size();
			if (covered > maxCovered) {
				selected = test;
				maxCovered = covered;
			}
		}
		return selected;
	}
}
