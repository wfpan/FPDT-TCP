package it.unina.dieti.tkprio.domain;

public class Mutant {

	private int id;
	private String clazz;
	private String file;
	private int line;
	private String method;
	private String original;
	private String replacement;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public int getLine() {
		return line;
	}

	public void setLine(int line) {
		this.line = line;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getOriginal() {
		return original;
	}

	public void setOriginal(String original) {
		this.original = original;
	}

	public String getReplacement() {
		return replacement;
	}

	public void setReplacement(String replacement) {
		this.replacement = replacement;
	}

	@Override
	public String toString() {
		return "Mutant [id=" + id + ", clazz=" + clazz + ", file=" + file + ", line=" + line + ", method=" + method
				+ ", original=" + original + ", replacement=" + replacement + "]";
	}
}
