package it.unina.dieti.tkprio.domain;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MethodSet implements Iterable<Method> {

  private Map<String, Method> methods = new HashMap<>();

  public void addMethod(Method method) {
    this.methods.put(method.getSignature(), method);
  }

  public void merge(MethodSet methodSet) {
    this.methods.putAll(methodSet.methods);
  }

  public Method getBySignature(String signature) {
    if(this.methods.containsKey(signature))
      return this.methods.get(signature);
    return null;
  }

  @Override
  public Iterator<Method> iterator() {
    return this.methods.values().iterator();
  }
}
