package it.unina.dieti.tkprio.generation;

import it.unina.dieti.tkprio.Configuration;
import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Variant;
import it.unina.dieti.tkprio.domain.VariantSet;
import it.unina.dieti.tkprio.generation.faults.domain.LineGrainedCoverageReport;
import it.unina.dieti.tkprio.generation.faults.io.CoverageLineParser;
import it.unina.dieti.tkprio.generation.faults.io.FaultMatrixGenerator;
import it.unina.dieti.tkprio.io.FaultMatrixSerializer;
import it.unina.dieti.tkprio.io.VariantParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CreateFaultMatrices {

  private static final Logger LOG = LoggerFactory.getLogger(CreateFaultMatrices.class);

  private static final String VARIANTS_XML = "variants.xml";
  private static final String CLOVER_REPORT = "clover-report-1.1.xml";

  private final Path projectsRoot;
  private final Path faultMatricesRoot;

  private final VariantParser variantParser = new VariantParser();
  private final CoverageLineParser coverageLineParser = new CoverageLineParser();
  private final FaultMatrixGenerator faultMatrixGenerator = new FaultMatrixGenerator();
  private final FaultMatrixSerializer faultMatrixSerializer = new FaultMatrixSerializer(';');

  public CreateFaultMatrices(Path projectsRoot, Path faultMatricesRoot) {
    this.projectsRoot = projectsRoot;
    this.faultMatricesRoot = faultMatricesRoot;
  }

  public void create() {
    try {
      Files.walk(this.projectsRoot, 1)
          .filter(Files::isDirectory)
          .filter(p -> !this.projectsRoot.equals(p))
          .forEach(this::createProject);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private void createProject(Path projectPath) {
    try {
      LOG.info("Creating fault matrices for " + projectPath.getFileName());
      Files.walk(projectPath, 1)
          .filter(Files::isDirectory)
          .filter(p -> !projectPath.equals(p))
          .forEach(this::createVersion);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private void createVersion(Path versionPath) {
    Path variantsPath = versionPath.resolve(VARIANTS_XML);
    if(!Files.isRegularFile(variantsPath)) {
      LOG.warn("No variants for " + variantsPath);
      return;
    }
    try {
      VariantSet set = this.variantParser.parse(variantsPath);
      for(String from : set.getAllFroms())
        this.createVariants(versionPath, set.getVariantsFrom(from));
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  private void createVariants(Path versionPath, List<Variant> variants) {
    try {
      Path coveragePath = versionPath.resolve(CLOVER_REPORT);
      LineGrainedCoverageReport report = this.coverageLineParser.parse(coveragePath);
      for(Variant variant : variants)
        this.createVariant(report, variant);
    } catch (ParserConfigurationException | SAXException | IOException e) {
      throw new RuntimeException(e);
    }
  }

  private void createVariant(LineGrainedCoverageReport report, Variant variant) {
    try {
      FaultMatrix matrix = this.faultMatrixGenerator.generate(variant, report);
      Path outPath = this.faultMatricesRoot.resolve(variant.getProject()).resolve(variant.getVersion())
          .resolve(variant.getFrom()).resolve(variant.getId() + ".csv");
      Files.createDirectories(outPath.getParent());
      LOG.info("Creating fault matrix for " + variant.getProject()
          + " " + variant.getVersion() + " from " + variant.getFrom() + " [" + variant.getId() + "]");
      this.faultMatrixSerializer.serialize(matrix, outPath);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public static void main(String[] args) {
    Configuration configuration = Configuration.fromDotenv();
    new CreateFaultMatrices(configuration.getProjectsFolder(),
        configuration.getFaultMatricesFolder()).create();
  }
}
