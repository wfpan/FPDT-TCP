package it.unina.dieti.tkprio.rtp.strategies.helpers;

import it.unina.dieti.tkprio.domain.Method;
import it.unina.dieti.tkprio.domain.MethodSet;
import org.apache.commons.lang3.tuple.Pair;

import java.util.LinkedList;
import java.util.List;

/**
 * Auxiliary function extracting the method matching from the previous and
 * current method set.
 * return the matching pairs:Method vs. Method list
 */
public class MethodMatcher {

	private MethodMatcher() {
	}

	public static List<Pair<Method, Method>> createMethodMatching(MethodSet previousSet, MethodSet currentSet) {
		List<org.apache.commons.lang3.tuple.Pair<Method, Method>> matching = new LinkedList<>();
		for (Method previous : previousSet) {
			Method current = currentSet.getBySignature(previous.getSignature());
			if (current != null)
				matching.add(org.apache.commons.lang3.tuple.Pair.of(previous, current));
		}
		return matching;
	}

}
