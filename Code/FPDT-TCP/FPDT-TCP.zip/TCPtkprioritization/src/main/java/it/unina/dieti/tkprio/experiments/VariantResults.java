package it.unina.dieti.tkprio.experiments;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class VariantResults {

  private MetricAggregatedResult mar;

  private final Map<String, Float> results = new HashMap<>();

  public MetricAggregatedResult getMar() {
    return mar;
  }

  public VariantResults setMar(MetricAggregatedResult mar) {
    this.mar = mar;
    return this;
  }

  public Set<String> getStrategies() {
    return this.results.keySet();
  }

  public float getResultForStrategy(String strategy) {
    return this.results.get(strategy);
  }

  public VariantResults addResult(String strategy, float value) {
    this.results.put(strategy, value);
    return this;
  }
}
