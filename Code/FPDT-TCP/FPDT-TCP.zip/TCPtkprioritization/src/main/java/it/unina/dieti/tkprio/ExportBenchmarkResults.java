package it.unina.dieti.tkprio;

import it.unina.dieti.tkprio.experiments.ExecutionTimeResult;
import it.unina.dieti.tkprio.experiments.db.ExperimentDB;
import it.unina.dieti.tkprio.experiments.io.JMHReportsManager;

import java.nio.file.Path;
import java.util.Collection;

public class ExportBenchmarkResults {

	public static void main(String[] args) {
		// Saving data from JMH reports to DB
		Path file = Configuration.fromDotenv().getResultsFolder().resolve("csv").resolve("benchmark.csv");
		JMHReportsManager manager = new JMHReportsManager();
		Collection<ExecutionTimeResult> results = manager.parse(file);
		ExperimentDB db = new ExperimentDB();
		db.save(results);
		// Retrieving all time results from db and saving them completely
		results = db.allExecutionTimeResults();
		manager.toCsv(results,
				Configuration.fromDotenv().getResultsFolder().resolve("csv").resolve("technique_times.csv"));
	}

}
