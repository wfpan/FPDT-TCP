package it.unina.dieti.tkprio.io;

import it.unina.dieti.tkprio.domain.Mutant;
import it.unina.dieti.tkprio.domain.Variant;
import it.unina.dieti.tkprio.domain.VariantSet;
import it.unina.dieti.tkprio.exceptions.NoSuchVariantException;
import it.unina.dieti.tkprio.exceptions.VariantsNotAvailableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SourceFileLister {

	private final static Logger LOG = LoggerFactory.getLogger(SourceFileLister.class);

	private final Path projectsRoot;

	public SourceFileLister(Path projectsRoot) {
		this.projectsRoot = projectsRoot;
	}

	/**return the .java file list of the project with version number version*/
	public List<Path> listForOriginalVersion(String project, String version) {
		try (Stream<Path> pathStream = Files
				.walk(projectsRoot.resolve(project).resolve(version).resolve("src").resolve("main").resolve("java"))
				.filter(p -> p.toString().endsWith(".java"))) {
			return pathStream.collect(Collectors.toList());
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	//lister.listForVariant(this.project, this.current, this.previous, this.variantId)
	/**construct an variant (variantID) of the current project
	 * Using the mutant files to replace the correct files in the original system
	 * return the Path list (absolute path) of these files (denoting a variant) 
	 * */
	public List<Path> listForVariant(String project, String version, String from, int variantId)
			throws NoSuchVariantException, VariantsNotAvailableException {
		
		//get a variant from the List<Variant> of from
		Variant variant = this.getVariant(project, version, from, variantId);
		
		final Map<String, Path> map = new HashMap<>();
		
		//the mutants in the current project (cf. mutants directory in the current project)
		Path mutantFolder = this.projectsRoot.resolve(project).resolve(version).resolve("mutants");
		
		final Path originalSourceFolder = projectsRoot.resolve(project).resolve(version).resolve("src").resolve("main")
				.resolve("java");
		
		// to process the file name of the java files in the current project
		try (Stream<Path> pathStream = Files.walk(originalSourceFolder).filter(p -> p.toString().endsWith(".java"))) {
			pathStream.forEach(p -> {
				String relativePath = p.toString().replace(originalSourceFolder.toString(), "").replace("\\", "/"); // Windows
																													// path
																													// correction
				if (relativePath.startsWith("/")) // Removing the leading slash
					relativePath = relativePath.substring(1); //relativePath is as org/la4j/decomposition/CholeskyDecompositor.java
				
				//相对路径org/la4j/decomposition/CholeskyDecompositor.java 
				//绝对路径D:\E-Code\OU-JavaCourse\Dataset\Projects\la4j\5bf8a3b08baee80b97b497f1881e2932643f3e6f\src\main\java
				//\org\la4j\decomposition\CholeskyDecompositor.java
//				System.out.println("hahah ==" + relativePath + " ==" + p.toString());
//				System.exit(0);
				//保存相对路径机器相应的绝对路径
				map.put(relativePath, p); //软件的路径都保存为了绝对路径
			});
			//某个特定variant的所有mutants
			for (Mutant mutant : variant.getMutants()) {
				// the Path of the mutant file
				Path mutantPath = mutantFolder.resolve("" + mutant.getId()).resolve(mutant.getFile());
				
				// Replacing the previous file with its mutation
				String mutantFile = mutant.getFile().replace("\\", "/"); // Windows path correction
				if (map.put(mutantFile, mutantPath) == null) //用植入错误的文件替换原文件
					throw new RuntimeException("Original source file not found for " + mutantFile);
				LOG.info("Replaced " + mutant.getFile());
			}
			// Returning the list of paths
			return new ArrayList<>(map.values()); //返回变体中的所有的文件的绝对路径（src中代码文件绝对路径+mutants中错误代码绝对路径）
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	//lister.listForVariant(this.project, this.current, this.previous, this.variantId)
	/**read the variants.xml file in the current project
	 * get one variant using variantId*/
	private Variant getVariant(String project, String version, String from, int variantId)
			throws VariantsNotAvailableException, NoSuchVariantException {
		Path variantPath = this.projectsRoot.resolve(project).resolve(version).resolve("variants.xml");
		VariantParser variantParser = new VariantParser();
		//针对当前版本，得到其所有的100个变体配置(每个variant下的mutants是什么)
		VariantSet variantSet = variantParser.parse(variantPath);
		return variantSet.getVariant(from, variantId);
	}

}
