package it.unina.dieti.tkprio.domain;

import java.util.ArrayList;
import java.util.List;

/**set id, project, version, from, faultMatrix, and mutants (5)*/
public class Variant {

  private int id;
  private String project;
  private String version;
  private String from;
  private FaultMatrix faultMatrix;

  /**nutant number is set to 5 (fixed)*/
  private final List<Mutant> mutants = new ArrayList<>(5);

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getProject() {
    return project;
  }

  public void setProject(String project) {
    this.project = project;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public String getFrom() {
    return from;
  }

  public void setFrom(String from) {
    this.from = from;
  }

  public List<Mutant> getMutants() {
    return mutants;
  }

  public void addMutant(Mutant mutant) {
    this.mutants.add(mutant);
  }

  public FaultMatrix getFaultMatrix() {
    return faultMatrix;
  }

  public void setFaultMatrix(FaultMatrix faultMatrix) {
    this.faultMatrix = faultMatrix;
  }
}
