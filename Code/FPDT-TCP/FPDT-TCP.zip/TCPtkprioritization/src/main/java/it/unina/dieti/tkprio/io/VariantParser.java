package it.unina.dieti.tkprio.io;

import it.unina.dieti.tkprio.domain.Mutant;
import it.unina.dieti.tkprio.domain.Variant;
import it.unina.dieti.tkprio.domain.VariantSet;
import it.unina.dieti.tkprio.exceptions.VariantsNotAvailableException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class VariantParser {

	public VariantSet parse(Path path) throws VariantsNotAvailableException {
		try {
			if (!Files.isRegularFile(path))
				throw new VariantsNotAvailableException("No variants.xml file at " + path);
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			ParserTask task = new ParserTask();
			parser.parse(path.toFile(), task);
			return task.variantSet;
		} catch (ParserConfigurationException | IOException | SAXException e) {
			throw new RuntimeException(e);
		}
	}

  private static class ParserTask extends DefaultHandler {

    private final static String E_VARIANTS = "Variants";
    private final static String E_FROM_VERSION = "FromVersion";
    private final static String E_VARIANT = "Variant";
    private final static String E_MUTANT = "Mutant";

    private final static String A_VARIANTS_PROJECT = "project";
    private final static String A_VARIANTS_SHA = "sha";
    private final static String A_FROM_VERSION_SHA = "sha";
    private final static String A_VARIANT_ID = "id";
    private final static String A_MUTANT_ID = "id";
    private final static String A_MUTANT_CLASS = "class";
    private final static String A_MUTANT_FILE = "file";
    private final static String A_MUTANT_LINE = "line";
    private final static String A_MUTANT_METHOD = "method";
    private final static String A_MUTANT_ORIGINAL = "original";
    private final static String A_MUTANT_REPLACEMENT = "replacement";

    private VariantSet variantSet;
    private String from;
    private Variant variant;

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
      switch(qName) {
        case E_VARIANTS:
          this.variantSet = new VariantSet(attributes.getValue(A_VARIANTS_PROJECT),
              attributes.getValue(A_VARIANTS_SHA));
          break;
        case E_FROM_VERSION:
          this.from = attributes.getValue(A_FROM_VERSION_SHA);
          break;
        case E_VARIANT:
          this.variant = new Variant();
          this.variant.setId(Integer.parseInt(attributes.getValue(A_VARIANT_ID)));
          this.variant.setVersion(variantSet.getSha()); //当前project的sha
          this.variant.setProject(variantSet.getProject());//当前project
          this.variant.setFrom(this.from);//前一个project
          this.variantSet.addVariantFrom(this.from, variant);
          break;
        case E_MUTANT:
          Mutant mutant = new Mutant();
          mutant.setId(Integer.parseInt(attributes.getValue(A_MUTANT_ID)));
          mutant.setLine(Integer.parseInt(attributes.getValue(A_MUTANT_LINE)));
          mutant.setClazz(attributes.getValue(A_MUTANT_CLASS));
          mutant.setFile(attributes.getValue(A_MUTANT_FILE));
          mutant.setMethod(attributes.getValue(A_MUTANT_METHOD));
          mutant.setOriginal(attributes.getValue(A_MUTANT_ORIGINAL));
          mutant.setReplacement(attributes.getValue(A_MUTANT_REPLACEMENT));
          this.variant.addMutant(mutant);
      }
    }
  }

}
