package it.unina.dieti.tkprio.exceptions;

public class NoSuchVariantException extends Exception {
  public NoSuchVariantException(String message) {
    super(message);
  }
}
