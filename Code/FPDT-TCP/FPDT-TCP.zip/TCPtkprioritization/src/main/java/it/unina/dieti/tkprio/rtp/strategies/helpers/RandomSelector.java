package it.unina.dieti.tkprio.rtp.strategies.helpers;

import it.unina.dieti.tkprio.domain.Test;

import java.util.List;
import java.util.Random;

public class RandomSelector implements QSSelectorI {

  private final Random random;

  public RandomSelector() {
    this.random = new Random();
  }

  @Override
  public Test select(List<Test> equivalenceClass) {
    return equivalenceClass.get(random.nextInt(equivalenceClass.size()));
  }
}
