package it.unina.dieti.tkprio.generation.faults.domain;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Test {

  private String name;

  private final Map<String, CoveredFile> coveredFiles = new HashMap<>();

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Collection<CoveredFile> getCoveredFiles() {
    return coveredFiles.values();
  }

  public void addCoveredFiles(CoveredFile coveredFile) {
    this.coveredFiles.put(coveredFile.getFilename(), coveredFile);
  }

  public CoveredFile getCoveredFile(String name) {
    if(this.coveredFiles.containsKey(name))
      return this.coveredFiles.get(name);
    return null;
  }
}
