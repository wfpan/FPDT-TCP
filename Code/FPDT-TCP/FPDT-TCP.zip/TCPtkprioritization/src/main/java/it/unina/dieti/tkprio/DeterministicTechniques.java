package it.unina.dieti.tkprio;

import it.unina.dieti.tkprio.exceptions.NoFaultsDiscoveredException;
import it.unina.dieti.tkprio.exceptions.NoSuchVariantException;
import it.unina.dieti.tkprio.exceptions.VariantsNotAvailableException;
import it.unina.dieti.tkprio.experiments.Experiment;
import it.unina.dieti.tkprio.experiments.db.ExperimentDB;
import it.unina.dieti.tkprio.io.ProjectDiscoverer;
import it.unina.dieti.tkprio.rtp.metrics.APFDMetric;
import it.unina.dieti.tkprio.rtp.metrics.PTFMetric;
import it.unina.dieti.tkprio.rtp.metrics.PTLMetric;
import it.unina.dieti.tkprio.rtp.metrics.TTLMetric;
import it.unina.dieti.tkprio.rtp.strategies.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.edu.zjgsu.wfpan.file.util.CsvFileWriterUtil;
import cn.edu.zjgsu.wfpan.strategies.BugPredictionPrioritization;
import cn.edu.zjgsu.wfpan.strategies.COGPrioritization;
import cn.edu.zjgsu.wfpan.strategies.DiffPrioritizationWithMethodCognitive;
import cn.edu.zjgsu.wfpan.strategies.DiffPrioritizationWithMethodCognitiveCoreness;
import cn.edu.zjgsu.wfpan.strategies.DiffPrioritizationWithMethodCoreness;
import cn.edu.zjgsu.wfpan.strategies.IDFPrioritization;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithIDFBugPrediction;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitive;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveC2VIDF;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveCorenessIDF;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveCorenss;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDBetweenness;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDF;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDF2;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDF3;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDFBugPrediction;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDFInfluence;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveIDFKcore;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCognitiveOutDegIDF;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodCoreness;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodIDF;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodKcore;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodKcoreIDF;
import cn.edu.zjgsu.wfpan.strategies.MTKPrioritizationWithMethodPageRank;
import cn.edu.zjgsu.wfpan.strategies.QuotientSetIDFPrioritization;
import cn.edu.zjgsu.wfpan.strategies.QuotientSetIDFPrioritization2;
import cn.edu.zjgsu.wfpan.strategies.QuotientSetIDFPrioritization3;
import cn.edu.zjgsu.wfpan.strategies.QuotientSetIDFPrioritization4;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DeterministicTechniques {

	private final static Logger LOG = LoggerFactory.getLogger(DeterministicTechniques.class);

	private static final boolean FORCE_RE_EXECUTION = false;

	public static void main(String[] args) {
		ExperimentDB db = new ExperimentDB();
		ProjectDiscoverer discoverer = new ProjectDiscoverer(Configuration.fromDotenv().getProjectsFolder());
		for (String project : discoverer.getProjects()) {
			System.out.println("Evaluating project " + project);
			List<String> versions = discoverer.getVersionsForProject(project);
			for (int i = 1, versionsLen = versions.size(); i < versionsLen; i++) {
				String current = versions.get(i);
				System.out.println("Current version: " + current + " (" + (i + 1) + ")");
				try {
					for (int j = 0; j < i; j++) {
						
						String previous = versions.get(j);//i之前的都是 previous
						System.out.println("Previous version: " + previous + " (" + (j + 1) + ")");
						System.out.print("Variants:");
						try {
							// Evaluating for each variant
							for (int vId = 1; vId <= 100; vId++) {
								System.out.print(" " + vId);
								try {
									executeAndSaveExperiment(project, previous, j + 1, current, i + 1, vId, db);
								} catch (NoFaultsDiscoveredException e) {
									// If for a variant there are no faults discovered, it is skipped
									LOG.warn("No tests discovering any fault in " + project + " " + " " + previous
											+ " [" + (j + 1) + "] -> " + current + " [" + (i + 1) + "] Variant: "
											+ vId);
								}
							}
							System.out.println();
						} catch (NoSuchVariantException e) {
							// In case there are no variants from the previous version,
							// The previous version is skipped
							LOG.warn("No variants for " + project + " " + current + " when paired with " + previous);
						}
					}
				} catch (VariantsNotAvailableException e) {
					// In case no variant is present, experiments
					// with this version as current are skipped
					LOG.warn("No variants found for " + project + " " + current + ". Skipping.");
				}
			}
		}
	}
	
	public static Map<String, Float> sim = null;

	/**
	 * @param project the project under processing
	 * @param previous previous project name
	 * @param previousOrder previous project index (already index+1)
	 * @param current the current project under test
	 * @param currentOrder the index of the current project (already index+1)
	 * @param variant index
	 * @param db the sqlite DB
	 * */
	private static void executeAndSaveExperiment(String project, String previous, int previousOrder, String current,
			int currentOrder, int variantId, ExperimentDB db)
			throws NoSuchVariantException, VariantsNotAvailableException {
		LOG.info("Executing experiment on " + project + " " + previous + " -> " + current + " [" + variantId + "]");
		sim = null;
		Experiment experiment = new Experiment().setProject(project).setPrevious(previous)
				.setPreviousOrder(previousOrder).setCurrent(current).setCurrentOrder(currentOrder)
				.setVariantId(variantId)
				//FPDT-TCP
				.addStrategy(new QuotientSetIDFPrioritization3(new MTKPrioritizationWithMethodCognitiveIDF2()))//
				.addMetric(new APFDMetric())
				.addMetric(new PTFMetric()).addMetric(new PTLMetric()).addMetric(new TTLMetric());
		if (FORCE_RE_EXECUTION || !db.alreadyExecuted(experiment)) {
			System.out.println("\n" + experiment.getProject());
			experiment.execute();
			LOG.info("Experiment completed. Saving results to the DB");
			db.save(experiment);
		} else {
			LOG.info("Experiment already executed. Skipping");
		}
	}

}
