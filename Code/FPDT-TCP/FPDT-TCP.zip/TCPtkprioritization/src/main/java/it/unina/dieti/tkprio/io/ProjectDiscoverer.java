package it.unina.dieti.tkprio.io;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

public class ProjectDiscoverer {

	/**projectsRoot*/
	private final Path projectsRoot;

	public ProjectDiscoverer(Path projectsRoot) {
		this.projectsRoot = projectsRoot;
	}

	/**
	 * Gets a map (Collection) with project names as key and path to the project
	 * folder as value.
	 *
	 * @return The Collection of projects and their paths
	 */
	public Collection<String> getProjects() {
		List<String> projects = new LinkedList<>();
		try (Stream<Path> paths = Files.walk(this.projectsRoot, 1).filter(Files::isDirectory)
				.filter(p -> !p.equals(this.projectsRoot))) {
			paths.forEach(p -> {
				projects.add(p.getFileName().toString());
			});
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return projects;
	}

	public List<String> getVersionsForProject(String project) {
		List<String> versions = new LinkedList<>();
		Path sortedVersionFile = this.projectsRoot.resolve(project).resolve("sorted_version.txt");
		// Reading sorted_version.txt
		try (Scanner scanner = new Scanner(sortedVersionFile)) {
			while (scanner.hasNextLine())
				versions.add(scanner.nextLine());
			// As versions are listed from latest (top) to oldest (bottom), we reverse the
			// list
			Collections.reverse(versions);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return versions;
	}
}
