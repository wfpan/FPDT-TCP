package it.unina.dieti.tkprio.exceptions;

public class VariantsNotAvailableException extends Exception {

  public VariantsNotAvailableException(String message) {
    super(message);
  }
}
