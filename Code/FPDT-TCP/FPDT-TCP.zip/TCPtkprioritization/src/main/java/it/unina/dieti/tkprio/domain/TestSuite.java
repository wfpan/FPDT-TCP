package it.unina.dieti.tkprio.domain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class TestSuite implements Iterable<Test> {

	private final static Logger LOG = LoggerFactory.getLogger(TestSuite.class);

	/**List of test cases in the suite*/
	private final List<Test> tests = new LinkedList<>();
	/**Map-testName,Test object-*/
	private final HashMap<String, Test> testMap = new HashMap<>();

	@Override
	public Iterator<Test> iterator() {
		return this.tests.iterator();
	}
	/**add the test to testMap Map<testName,Test object> and test list List<Test> tests*/
	public void addTest(Test test) {
		this.testMap.put(test.getName(), test);
		this.tests.add(test);
	}
	/**return the test list*/
	public List<Test> getTests() {
		return this.tests;
	}
	/**return the test from testMap according to the test name */
	public Test getByName(String name) {
		if (this.testMap.containsKey(name))
			return this.testMap.get(name);
		return null;
	}
	/**return the total time cost by all the tests in testMap*/
	public float getTotalTime() {
		float time = 0;
		for (Test test : this.testMap.values())
			time += test.getTime();
		return time;
	}
	/**merge the test report of tests with the report of tests in the testMap (with the same test name);
	 * In fact, it sets the covered methods of each test in testMap as the coveredMethods of tests in 
	 * the parameter report*/
	public void mergeWithCoverage(CoverageReport report) {
		for (Test test : report.getTests()) {
			if (this.testMap.containsKey(test.getName())) {
				Test inSuite = this.testMap.get(test.getName());
				inSuite.setCoveredMethods(test.getCoveredMethods());
			}
		}
	}

	/**
	 * Joins two test suites to create a new suite in which there are tests cases
	 * with the same name between the two suites. Tests added are related to the
	 * first suite (previous) passed as parameter, as this suite stores coverage
	 * data in experiments.
	 *
	 * @param previous The previous test suite, whose test cases will be added to
	 *                 the joined suite
	 * @param current  The current test suite
	 * @return A joined test suite with tests in the previous suite which are also
	 *         present in the current suite
	 */
	public static TestSuite withCommonTests(TestSuite previous, TestSuite current) {
		TestSuite joined = new TestSuite();
		for (Test test : previous) {
			if (current.testMap.containsKey(test.getName())) {
				Test common = new Test();
				common.setName(test.getName());
				common.setCoveredMethods(test.getCoveredMethods());
				common.setTime(current.testMap.get(test.getName()).getTime());
				joined.addTest(test);
			}
		}
		return joined;
	}

}
