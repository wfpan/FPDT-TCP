package it.unina.dieti.tkprio;

import it.unina.dieti.tkprio.experiments.io.CSVResultReporter;
import it.unina.dieti.tkprio.io.ProjectDiscoverer;

import java.util.List;

public class ExportCSVResults {

	public static void main(String[] args) {
		Configuration configuration = Configuration.fromDotenv();
		ProjectDiscoverer discoverer = new ProjectDiscoverer(configuration.getProjectsFolder());
		CSVResultReporter exporter = new CSVResultReporter();
		for (String project : discoverer.getProjects()) {
			System.out.println(project);
			List<String> versions = discoverer.getVersionsForProject(project);
			for (int i = 1; i < versions.size(); i++) {
				String current = versions.get(i);
				System.out.println("  " + current);
				for (int j = 0; j < i; j++) {
					String previous = versions.get(j);
					System.out.println("    " + previous);
					exporter.save(project, previous, current, configuration.getResultsFolder().resolve("csv"));
				}
			}
		}

	}

}
