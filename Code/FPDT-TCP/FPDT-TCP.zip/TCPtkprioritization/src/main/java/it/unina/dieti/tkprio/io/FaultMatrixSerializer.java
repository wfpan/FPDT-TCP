package it.unina.dieti.tkprio.io;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class FaultMatrixSerializer {

	private static final Logger LOG = LoggerFactory.getLogger(FaultMatrixSerializer.class);

	/**the separator: ;*/
	private char separator = ';';

	public FaultMatrixSerializer() {
	}

	public FaultMatrixSerializer(char separator) {
		this.separator = separator;
	}

	public void serialize(FaultMatrix matrix, Path toPath) {
		try {
			// Creating the directories
			Files.createDirectories(toPath.getParent());
			// Opening the file
			try (FileWriter writer = new FileWriter(toPath.toFile())) {
				// Writing the header
				writer.write("testName");
				for (Integer fault : matrix.getFaults())
					writer.write(this.separator + "F" + fault);
				writer.write('\n');
				writer.flush();
				// Writing the faults
				for (String test : matrix.getTests()) {
					writer.write(test);
					for (Integer fault : matrix.getFaults())
						writer.write(this.separator + (matrix.discover(test, fault) ? "1" : "0"));
					writer.write('\n');
					writer.flush();
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**receive the faultMatrix and construct the fault matrix, i.e., fault to test list, and test to fault list: 
	 * 这个faultMatrixPath指向的是current的这个previous下的variantId变体(里面存了faultMatrix),这里面的
	 * fault对应了 current中mutant下某个具体的variant*/
	public FaultMatrix deserialize(Path fromPath) {
		try (Scanner reader = new Scanner(fromPath.toFile())) {
			FaultMatrix matrix = new FaultMatrix();
			// Extracting faults (fault id) from faultMatrix (csv:the first line): it is the same as 
			// the Mutants (mutant id) in the variants.xml of the current project
			List<Integer> faults = this.extractFaultsFromHeader(reader.nextLine());
			for (int fault : faults)
				matrix.addFault(fault);
			// Creating tests
			while (reader.hasNextLine()) {
				String[] tokens = reader.nextLine().split("" + this.separator);
				String test = tokens[0]; // First value is the qualified name of the test
				matrix.addTest(test);
				for (int i = 1; i < tokens.length; i++)
					if (tokens[i].equals("1"))
						matrix.addFaultToTest(test, faults.get(i - 1));
			}
			return matrix;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**It returns the list of faults:
	 * the first line is: testName;F1570;F420;F2052;F646;F747
	 * it returns 1570, 420, 2052, 646, and 747, without the prefix F
	 * */
	private List<Integer> extractFaultsFromHeader(String header) {
		List<Integer> faults = new LinkedList<>();
		String[] tokens = header.split("" + this.separator);
		if (tokens.length < 2)
			throw new RuntimeException("No faults found in fault matrix!");
		for (int i = 1; i < tokens.length; i++)
			faults.add(Integer.parseInt(tokens[i].replace("F", "")));
		return faults;
	}

}
