package it.unina.dieti.tkprio.rtp.metrics;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.exceptions.NoFaultsDiscoveredException;

public class PTFMetric implements MetricI {

  private static final String NAME = "PTF";

  private FaultMatrix matrix;

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public void setUp(FaultMatrix matrix) {
    this.matrix = matrix;
  }

  @Override
  public float evaluate(Permutation permutation) {
    int idx = 1;
    int n = permutation.getTests().size();
    for(Test test: permutation) {
      if(!this.matrix.getFaultsForTest(test.getName()).isEmpty())
        break;
      idx++;
    }
    // No faults discovered when the test index is greater than the total number of tests
    if(idx > n)
      throw new NoFaultsDiscoveredException("No faults discovered when evaluating " + NAME);
    return (float)idx / n;
  }
}
