package it.unina.dieti.tkprio.rtp.strategies;

import it.unina.dieti.tkprio.domain.CoverageReport;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.io.CloverCoverageParser;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Path;

public class TotalPrioritization implements PrioritizationStrategyI {

	private static final Logger LOG = LoggerFactory.getLogger(TotalPrioritization.class);

	private static final String NAME = "total";

	private Path coverageReportPath;

	private CoverageReport coverageReport;

	/**
	 * Sets the coverage report directly.
	 *
	 * @param coverageReport The coverage report already extracted
	 */
	public TotalPrioritization setCoverageReport(CoverageReport coverageReport) {
		this.coverageReport = coverageReport;
		return this;
	}

	@Override
	public String name() {
		return NAME;
	}

	/**It sets up the coverageReportPath*/
	@Override
	public void setUp(StrategyPaths paths) {
		this.coverageReportPath = paths.getPreviousCoveragePath();
	}

	@Override
	public Permutation prioritize(TestSuite suite) {
		if (this.coverageReport == null)
			this.loadCoverage();
		suite.mergeWithCoverage(this.coverageReport);
		Permutation permutation = new Permutation(suite);
		// Evaluating scores summing the number of covered methods
		for (Test test : permutation)
			test.setScore((float) test.getCoveredMethods().size());
		// Sorting the test cases by score in descending order
		permutation.getTests().sort((t1, t2) -> Float.compare(t2.getScore(), t1.getScore()));
		return permutation;
	}

	private void loadCoverage() {
		LOG.info("Loading coverage report");
		CloverCoverageParser parser = new CloverCoverageParser();
		this.coverageReport = parser.parse(this.coverageReportPath);
	}
}
