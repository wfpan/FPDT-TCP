package it.unina.dieti.tkprio.experiments;

import it.unina.dieti.tkprio.rtp.metrics.MetricI;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;

public class ExperimentResult {

  private Experiment experiment;
  private PrioritizationStrategyI strategy;
  private MetricI metric;
  private float value;

  public ExperimentResult() {}

  public ExperimentResult(Experiment experiment) {
    this.experiment = experiment;
  }

  public Experiment getExperiment() {
    return experiment;
  }

  public PrioritizationStrategyI getStrategy() {
    return strategy;
  }

  public ExperimentResult setStrategy(PrioritizationStrategyI strategy) {
    this.strategy = strategy;
    return this;
  }

  public MetricI getMetric() {
    return metric;
  }

  public ExperimentResult setMetric(MetricI metric) {
    this.metric = metric;
    return this;
  }

  public float getValue() {
    return value;
  }

  public ExperimentResult setValue(float value) {
    this.value = value;
    return this;
  }
}
