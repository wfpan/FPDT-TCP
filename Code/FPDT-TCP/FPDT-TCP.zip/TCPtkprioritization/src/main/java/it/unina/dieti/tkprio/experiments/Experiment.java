package it.unina.dieti.tkprio.experiments;

import it.unina.dieti.tkprio.Configuration;
import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.exceptions.NoSuchVariantException;
import it.unina.dieti.tkprio.exceptions.VariantsNotAvailableException;
import it.unina.dieti.tkprio.io.FaultMatrixSerializer;
import it.unina.dieti.tkprio.io.SourceFileLister;
import it.unina.dieti.tkprio.io.SurefireReportParser;
import it.unina.dieti.tkprio.rtp.metrics.MetricI;
import it.unina.dieti.tkprio.rtp.strategies.PrioritizationStrategyI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

import java.nio.file.Path;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class Experiment {

	private Date executedAt;

	private String project;
	private String current;
	private int currentOrder;
	private String previous;
	private int previousOrder;

	private int variantId;

	private final List<PrioritizationStrategyI> strategies = new LinkedList<>();
	private final List<MetricI> metrics = new LinkedList<>();

	private final List<ExperimentResult> results = new LinkedList<>();

	public Date getExecutedAt() {
		return executedAt;
	}

	public Experiment setExecutedAt(Date executedAt) {
		this.executedAt = executedAt;
		return this;
	}

	public String getProject() {
		return project;
	}

	public Experiment setProject(String project) {
		this.project = project;
		return this;
	}

	public String getCurrent() {
		return current;
	}

	public Experiment setCurrent(String current) {
		this.current = current;
		return this;
	}

	public int getCurrentOrder() {
		return currentOrder;
	}

	public Experiment setCurrentOrder(int currentOrder) {
		this.currentOrder = currentOrder;
		return this;
	}

	public String getPrevious() {
		return previous;
	}

	public Experiment setPrevious(String previous) {
		this.previous = previous;
		return this;
	}

	public int getPreviousOrder() {
		return previousOrder;
	}

	public Experiment setPreviousOrder(int previousOrder) {
		this.previousOrder = previousOrder;
		return this;
	}

	public List<PrioritizationStrategyI> getStrategies() {
		return strategies;
	}

	public Experiment addStrategy(PrioritizationStrategyI strategy) {
		this.strategies.add(strategy);
		return this;
	}

	public List<MetricI> getMetrics() {
		return metrics;
	}

	public Experiment addMetric(MetricI metric) {
		this.metrics.add(metric);
		return this;
	}

	public int getVariantId() {
		return variantId;
	}

	public Experiment setVariantId(int variantId) {
		this.variantId = variantId;
		return this;
	}

	public List<ExperimentResult> getResults() {
		return results;
	}

	public Experiment addResult(ExperimentResult result) {
		this.results.add(result);
		return this;
	}

	public Experiment execute() throws NoSuchVariantException, VariantsNotAvailableException {
		System.out.println("\nRunning execute()...");
		// Execution time stored
		this.executedAt = new Date();
		Configuration configuration = Configuration.fromDotenv();
		// Getting paths used by techniques
		StrategyPaths paths = this.createPaths();
		
//		System.exit(0); // here

		// Extracting the common test suite
		SurefireReportParser reportParser = new SurefireReportParser();
		TestSuite currentSuite = reportParser.parse(paths.getCurrentSurefireReportsFolder());
		TestSuite previousSuite = reportParser.parse(paths.getPreviousSurefireReportsFolder());
		TestSuite common = TestSuite.withCommonTests(previousSuite, currentSuite);

		// Extracting the fault matrix for metric evaluation
		FaultMatrix matrix = this.loadFaultMatrix();
		for (MetricI metric : this.metrics)
			metric.setUp(matrix);

		// Executing the experiment
		for (PrioritizationStrategyI strategy : this.strategies) {
			// Setting up the strategy
			strategy.setUp(paths);
			// Executing the technique
			Permutation permutation = strategy.prioritize(common);
			
//			System.out.println("===================");
//			permutation.getTests().stream().forEach(System.out::println);
//			System.exit(0);
			
			// Evaluating all metrics
			for (MetricI metric : this.metrics) {
				float value = metric.evaluate(permutation);
				this.results.add(new ExperimentResult(this).setStrategy(strategy).setMetric(metric).setValue(value));
			}
		}
		return this;
	}
	/**surefire-reports,clover-report-method-1.1.xml,source code, etc. */
	private StrategyPaths createPaths() throws NoSuchVariantException, VariantsNotAvailableException {
		StrategyPaths paths = new StrategyPaths();
		
		// Getting paths for the current version
		Path currentVersionFolder = Configuration.fromDotenv().getProjectsFolder().resolve(this.project)
				.resolve(this.current);
		paths.setCurrentSurefireReportsFolder(currentVersionFolder.resolve("surefire-reports"));
		
		// Getting paths for the previous version
		Path previousVersionFolder = Configuration.fromDotenv().getProjectsFolder().resolve(this.project)
				.resolve(this.previous);
		paths.setPreviousSurefireReportsFolder(previousVersionFolder.resolve("surefire-reports"));
		paths.setPreviousCoveragePath(previousVersionFolder.resolve("clover-report-method-1.1.xml"));
		
		//softwareNetworkPath 这个部分是我自己加的，用于读取方法调用网络
		paths.setSoftwareNetworkPath(previousVersionFolder.resolve("SoftNet").resolve("MCN_Pan").resolve("MCN_WD_SoftNet.net"));
		//cognitiveFilePath
		paths.setCognitiveFilePath(previousVersionFolder.resolve("methodCogValue.csv"));
		//buggyFilePath 需要读取当前版本的bugPredictions.txt文件，而不是前一个的
//		paths.setBuggyFilePath(previousVersionFolder.resolve("bugPredictions.txt"));
		paths.setBuggyFilePath(currentVersionFolder.resolve("bugPredictions.txt"));
		paths.setRealBuggyFilePath(currentVersionFolder.resolve("buggy_pred.txt"));
		
		// Extracting sources for both versions
		SourceFileLister lister = new SourceFileLister(Configuration.fromDotenv().getProjectsFolder());
		//get all java files in the previous project
		paths.setPreviousSources(lister.listForOriginalVersion(this.project, this.previous));
		//get a variant version of the current project (the absolute path of all the code: original code + code with faults)
		paths.setCurrentSources(lister.listForVariant(this.project, this.current, this.previous, this.variantId));
		return paths;
	}

	private FaultMatrix loadFaultMatrix() {
		//这个faultMatrixPath指向的是current的这个previous下的variantId变体，跟variants.xml的结构一样：
		//Variants-project下的FromVersion下的Variant
		Path faultMatrixPath = Configuration.fromDotenv().getFaultMatricesFolder().resolve(this.project)
				.resolve(this.current).resolve(this.previous).resolve("" + this.variantId + ".csv");
		return new FaultMatrixSerializer().deserialize(faultMatrixPath);
	}
}
