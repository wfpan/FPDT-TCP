package it.unina.dieti.tkprio.domain;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Permutation implements Iterable<Test> {

  private final List<Test> tests;

  public Permutation() {
    this.tests = new LinkedList<>();
  }

  public Permutation(TestSuite suite) {
    this.tests = new ArrayList<>(suite.getTests());
  }

  public List<Test> getTests() {
    return this.tests;
  }

  public void addTest(Test test) {
    this.tests.add(test);
  }

  @Override
  public Iterator<Test> iterator() {
    return this.tests.iterator();
  }
}
