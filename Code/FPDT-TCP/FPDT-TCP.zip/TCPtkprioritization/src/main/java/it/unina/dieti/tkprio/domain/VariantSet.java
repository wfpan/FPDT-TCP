package it.unina.dieti.tkprio.domain;

import it.unina.dieti.tkprio.exceptions.NoSuchVariantException;

import java.util.*;

/**set project, sha, and a map<from, List<variant>*/
public class VariantSet implements Iterable<Map.Entry<String, List<Variant>>> {

	private final String project;
	private final String sha;

	/**<String, list<variant>>: key is the "from" attribute*/
	private final Map<String, List<Variant>> map = new HashMap<>();

	/**set the project name and sha*/
	public VariantSet(String project, String sha) {
		this.project = project;
		this.sha = sha;
	}

	public String getProject() {
		return project;
	}

	public String getSha() {
		return sha;
	}

	public Set<String> getAllFroms() {
		return this.map.keySet();
	}

	public List<Variant> getVariantsFrom(String from) {
		return this.map.get(from);
	}

	public Variant getVariant(String from, int variantId) throws NoSuchVariantException {
		if (this.map.containsKey(from))
			return this.map.get(from).get(variantId - 1);
		throw new NoSuchVariantException("Variant not found: " + from + " [" + variantId + "]");
	}

	public void addFrom(String from) {
		this.map.put(from, new ArrayList<>());
	}

	/**<String, list<variant>>: key is the "from" attribute*/
	public void addVariantFrom(String from, Variant variant) {
		if (!this.map.containsKey(from))
			this.addFrom(from);
		this.map.get(from).add(variant);
	}

	@Override
	public Iterator<Map.Entry<String, List<Variant>>> iterator() {
		return map.entrySet().iterator();
	}
}
