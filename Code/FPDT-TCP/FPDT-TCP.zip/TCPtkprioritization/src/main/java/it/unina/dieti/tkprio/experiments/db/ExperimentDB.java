package it.unina.dieti.tkprio.experiments.db;

import it.unina.dieti.tkprio.Configuration;
import it.unina.dieti.tkprio.experiments.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;

public class ExperimentDB {

	private static final Logger LOG = LoggerFactory.getLogger(ExperimentDB.class);

	private final Path dbPath;

	private final String uri;

	public ExperimentDB() {
		try {
			Configuration configuration = Configuration.fromDotenv();
			this.dbPath = configuration.getDatabasePath();
			this.uri = "jdbc:sqlite:" + this.dbPath.toString().replace("\\", "/");
			
//			System.out.println(this.uri);
//			System.exit(0);
			
			if (!Files.isRegularFile(this.dbPath)) {
				LOG.warn("Database file not found at " + this.dbPath + ". Creating a new DB");
				Files.createDirectories(dbPath.getParent());
				this.createSchema();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private void createSchema() {
		try (Connection conn = this.connect()) {
			// Experiments' tables
			String sql = "CREATE TABLE Experiments (" + "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "  executed_at TIMESTAMP NOT NULL," + "  project VARCHAR(256) NOT NULL,"
					+ "  previous VARCHAR(256) NOT NULL," + "  current VARCHAR(256) NOT NULL,"
					+ "  previousOrder INTEGER NOT NULL," + "  currentOrder INTEGER NOT NULL," + "  variant INTEGER"
					+ ")";
			Statement st = conn.createStatement();
			st.executeUpdate(sql);
			sql = "CREATE TABLE ExperimentResults (" + "  experiment INTEGER NOT NULL,"
					+ "  technique VARCHAR(64) NOT NULL," + "  metric VARCHAR(64) NOT NULL," + "  value FLOAT NOT NULL,"
					+ "  FOREIGN KEY (experiment) REFERENCES Experiments(id)" + ")";
			st.executeUpdate(sql);
			// Execution times' table
			sql = "CREATE TABLE ExecutionTimes (" + "  project VARCHAR(256) NOT NULL,"
					+ "  previous VARCHAR(256) NOT NULL," + "  previousOrder INTEGER NOT NULL,"
					+ "  current VARCHAR(256) NOT NULL," + "  currentOrder INTEGER NOT NULL,"
					+ "  technique VARCHAR(64) NOT NULL," + "  time FLOAT NOT NULL," + "  stddev FLOAT NOT NULL" + ")";
			st.executeUpdate(sql);
			st.close();
		} catch (SQLException e) {
			LOG.warn("Error while creating schema.");
			try {
				Files.delete(this.dbPath);
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
			throw new RuntimeException(e);
		}
	}

	private Connection connect() {
		try {
			return DriverManager.getConnection(uri);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void save(Experiment experiment) {
		System.out.println("storing the results...");
		try (Connection conn = this.connect()) {
			String sql = "INSERT INTO Experiments "
					+ "(executed_at, project, previous, previousOrder, current, currentOrder, variant) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement st = conn.prepareStatement(sql);
			st.setTimestamp(1, new Timestamp(experiment.getExecutedAt().getTime()));
			st.setString(2, experiment.getProject());
			st.setString(3, experiment.getPrevious());
			st.setInt(4, experiment.getPreviousOrder());
			st.setString(5, experiment.getCurrent());
			st.setInt(6, experiment.getCurrentOrder());
			st.setInt(7, experiment.getVariantId());
			st.executeUpdate();
			st.close();
			int id = this.lastInsertedId(conn);//我刚刚插进去的那条记录的 ID 是多少
			st = conn.prepareStatement("INSERT INTO ExperimentResults " + "(experiment, technique, metric, value) "
					+ "VALUES (?, ?, ?, ?)");
			for (ExperimentResult result : experiment.getResults()) {
				st.setInt(1, id);
				st.setString(2, result.getStrategy().name());
				st.setString(3, result.getMetric().name());
				st.setFloat(4, result.getValue());
				st.addBatch();
			}
			st.executeBatch();
			st.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Checks if an experiment has been already executed, i.e., if an experiment
	 * with the same project name, involving the very versions and the same variant
	 * id is already stored in the DB.
	 *
	 * @param experiment The experiment which needs to be checked
	 * @return true if the experiment has already been executer, false otherwise
	 */
	public boolean alreadyExecuted(Experiment experiment) {
		try (Connection conn = this.connect()) {
			PreparedStatement st = conn.prepareStatement("SELECT *" + "  FROM Experiments"
					+ "  WHERE project = ? AND previous = ? AND current = ? AND variant = ?");
			st.setString(1, experiment.getProject());
			st.setString(2, experiment.getPrevious());
			st.setString(3, experiment.getCurrent());
			st.setInt(4, experiment.getVariantId());
			ResultSet rs = st.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	private int lastInsertedId(Connection conn) throws SQLException {
		Statement st = conn.createStatement();
		ResultSet rs = st.executeQuery("SELECT last_insert_rowid()");
		if (!rs.next())
			throw new RuntimeException("Unable to retrieve last inserted id");
		return rs.getInt(1);
	}

	/**
	 * Retrieves all the experiments for a version pair in a project.
	 *
	 * @param project  The project
	 * @param previous The SHA of the previous version
	 * @param current  The SHA of the current version
	 * @return The list of experiments involving these versions
	 */
	public List<MetricAggregatedResult> retrieveForPair(String project, String previous, String current) {
		try (Connection conn = this.connect()) {
			String sql = "SELECT E.id AS id, E.executed_at AS executed_at, E.project AS project,"
					+ "    E.previous AS previous, E.previousOrder AS previousOrder,"
					+ "    E.current AS current, E.currentOrder AS currentOrder, "
					+ "    E.variant AS variant, ER.technique AS strategy, "
					+ "    ER.metric AS metric, ER.value AS value" + "  FROM Experiments E, ExperimentResults ER"
					+ "  WHERE E.id = ER.experiment" + "    AND UPPER(E.project) = UPPER(?)" + "    AND E.previous = ?"
					+ "    AND E.current = ?";
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, project);
			st.setString(2, previous);
			st.setString(3, current);
			ResultSet rs = st.executeQuery();
			Map<String, MetricAggregatedResult> resultMap = new HashMap<>();
			while (rs.next()) {
				String metric = rs.getString("metric");
				if (!resultMap.containsKey(metric)) {
					MetricAggregatedResult mar = new MetricAggregatedResult();
					mar.setProject(rs.getString("project"));
					mar.setPrevious(rs.getString("previous"));
					mar.setPreviousOrder(rs.getInt("previousOrder"));
					mar.setCurrent(rs.getString("current"));
					mar.setCurrentOrder(rs.getInt("currentOrder"));
					mar.setMetric(metric);
					resultMap.put(metric, mar);
				}
				MetricAggregatedResult mar = resultMap.get(metric);
				int variant = rs.getInt("variant");
				if (mar.getForVariant(variant) == null) {
					VariantResults vr = new VariantResults();
					vr.setMar(mar);
					mar.addResultForVariant(variant, vr);
				}
				VariantResults vr = mar.getForVariant(variant);
				vr.addResult(rs.getString("strategy"), rs.getFloat("value"));
			}
			return new ArrayList<>(resultMap.values());
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public void save(Collection<ExecutionTimeResult> results) {
		String sql = "INSERT INTO ExecutionTimes "
				+ " (project, previous, previousOrder, current, currentOrder, technique, time, stddev) "
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		try (Connection conn = this.connect()) {
			PreparedStatement st = conn.prepareStatement(sql);
			for (ExecutionTimeResult result : results) {
				st.setString(1, result.getProject());
				st.setString(2, result.getPrevious());
				st.setInt(3, result.getPreviousOrder());
				st.setString(4, result.getCurrent());
				st.setInt(5, result.getCurrentOrder());
				st.setString(6, result.getTechnique());
				st.setFloat(7, result.getTime());
				st.setFloat(8, result.getStandardDeviation());
				st.addBatch();
			}
			st.executeBatch();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public Collection<ExecutionTimeResult> allExecutionTimeResults() {
		try (Connection conn = this.connect()) {
			String sql = "SELECT * FROM ExecutionTimes ET";
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(sql);
			Collection<ExecutionTimeResult> results = new LinkedList<>();
			while (rs.next()) {
				ExecutionTimeResult result = new ExecutionTimeResult().setProject(rs.getString("project"))
						.setPrevious(rs.getString("previous")).setPreviousOrder(rs.getInt("previousOrder"))
						.setCurrent(rs.getString("current")).setCurrentOrder(rs.getInt("currentOrder"))
						.setTechnique(rs.getString("technique")).setTime(rs.getFloat("time"))
						.setStandardDeviation(rs.getFloat("stddev"));
				results.add(result);
			}
			return results;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
