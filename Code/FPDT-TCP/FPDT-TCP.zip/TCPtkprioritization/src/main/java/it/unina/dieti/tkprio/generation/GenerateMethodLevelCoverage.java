package it.unina.dieti.tkprio.generation;

import it.unina.dieti.tkprio.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class GenerateMethodLevelCoverage {

  private static final Logger LOG = LoggerFactory.getLogger(GenerateMethodLevelCoverage.class);

  private static final String INPUT_REPORT_NAME = "clover-report-1.1.xml";
  private static final String OUTPUT_REPORT_NAME = "clover-report-method-1.1.xml";

  public void generate(final Path projectsRoot) {
    try {
      Files.walk(projectsRoot, 1)
          .filter(p -> !p.equals(projectsRoot))
          .forEach(this::generateForProject);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private void generateForProject(final Path projectPath) {
    try {
      LOG.info("Analyzing project: " + projectPath.getFileName());
      Files.walk(projectPath, 1)
          .filter(p -> !p.equals(projectPath))
          .filter(Files::isDirectory)
          .filter(Files::isDirectory)
          .forEach(this::generateForVersion);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  private void generateForVersion(Path versionPath) {
    LOG.info("Analyzing version: " + versionPath.getFileName());
    Path coverageIn = versionPath.resolve(INPUT_REPORT_NAME);
    Path coverageOut = versionPath.resolve(OUTPUT_REPORT_NAME);
    if(!Files.isRegularFile(coverageIn))
      throw new RuntimeException("Unable to find coverage: " + coverageIn);
    this.generateMethodLevelCoverage(coverageIn, coverageOut);
  }

  private void generateMethodLevelCoverage(Path in, Path out) {
    try {
      Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(in.toFile());
      NodeList nl = document.getElementsByTagName("line");
      for(int i = nl.getLength() - 1; i >= 0; i--) {
        Element line = (Element) nl.item(i);
        line.getParentNode().removeChild(line);
      }
      // Saving
      Transformer transformer = TransformerFactory.newInstance().newTransformer();
      Result output = new StreamResult(out.toFile());
      transformer.transform(new DOMSource(document), output);
      LOG.info("Report saved in " + out);
    } catch (SAXException | ParserConfigurationException | IOException | TransformerException e) {
      throw new RuntimeException(e);
    }
  }

  public static void main(String[] args) {
    new GenerateMethodLevelCoverage().generate(Configuration.fromDotenv().getProjectsFolder());
  }
}
