package it.unina.dieti.tkprio.ast;

import it.uniroma2.sag.kelp.data.representation.tree.TreeRepresentation;

public class ASTRepresentation extends TreeRepresentation {

  public ASTRepresentation() {}

  public ASTRepresentation(ASTNode node) {
    super(node);
  }

  public ASTNode getAstRoot() {
    return (ASTNode) this.root;
  }

}
