package it.unina.dieti.tkprio.generation.faults.domain;

import java.util.HashSet;
import java.util.Set;

public class CoveredFile {

  private String filename;

  private final Set<Integer> lines = new HashSet<>();

  public String getFilename() {
    return filename;
  }

  public void setFilename(String filename) {
    this.filename = filename;
  }

  public Set<Integer> getLines() {
    return this.lines;
  }

  public void addLine(int line) {
    this.lines.add(line);
  }
}
