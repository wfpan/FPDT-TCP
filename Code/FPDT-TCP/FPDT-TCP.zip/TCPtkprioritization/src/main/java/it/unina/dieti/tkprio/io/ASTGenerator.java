package it.unina.dieti.tkprio.io;

import com.github.gumtreediff.client.Run;
import com.github.gumtreediff.gen.TreeGenerators;
import com.github.gumtreediff.tree.Tree;
import com.github.gumtreediff.tree.TreeContext;
import it.unina.dieti.tkprio.ast.ASTContent;
import it.unina.dieti.tkprio.ast.ASTNode;
import it.unina.dieti.tkprio.ast.ASTRepresentation;
import it.unina.dieti.tkprio.domain.Method;
import it.unina.dieti.tkprio.domain.MethodSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ASTGenerator {

	private static final Logger LOG = LoggerFactory.getLogger(ASTGenerator.class);

	/**return the method set in the filename*/
	public MethodSet generateFromSource(Path filename, boolean withAsts) {
		try {
			GeneratorTask task = new GeneratorTask().setWithAsts(withAsts);
			task.generate(filename);
			return task.methodSet;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private static class GeneratorTask {

		boolean withAsts;

		int id;

		String pkg; // Actual package

		MethodSet methodSet = new MethodSet();

		RandomAccessFile fileReader;

		public GeneratorTask setWithAsts(boolean withAsts) {
			this.withAsts = withAsts;
			return this;
		}

		private void generate(Path src) throws IOException {
			Run.initGenerators();
			if (Files.isDirectory(src))
				this.generateForFolder(src);
			else
				this.generateForSourceFile(src);
		}

		private void generateForFolder(Path folder) throws IOException {
			Stream<Path> paths = Files.walk(folder).filter(Files::isRegularFile)
					.filter(p -> p.toString().endsWith(".java"));
			List<Path> sourceFiles = paths.collect(Collectors.toList());
			paths.close();
			for (Path source : sourceFiles)
				this.generateForSourceFile(source);
		}

		private void generateForSourceFile(Path filename) throws IOException {
			// Closing previous opened file and opening this one to extract the body text
			if (this.fileReader != null)
				this.fileReader.close();
			this.fileReader = new RandomAccessFile(filename.toFile(), "r");
			// Searching for methods and generating ASTs
			TreeContext tc = TreeGenerators.getInstance().getTree(filename.toString());
			for (Tree t : tc.getRoot().getChildren()) {
				if (this.isClassDeclarationNode(t))
					this.generateClass(t, null);
				else if (this.isPackageDeclarationNode(t))
					this.pkg = this.extractPackageName(t);
			}
		}

		private void generateClass(Tree classDecl, String parents) throws IOException {
			String clazz = (this.pkg != null ? this.pkg + "." : "") + (parents != null ? parents + "." : "")
					+ this.extractNameFromClassDeclaration(classDecl);
			for (Tree t : classDecl.getChildren()) {
				if (this.isClassDeclarationNode(t)) // Recursively generating inner classes
					this.generateClass(t, clazz);
				else if (this.isMethodDeclarationNode(t))
					this.methodSet.addMethod(this.generateMethod(t, clazz));
				else if (this.isStaticBlock(t))
					this.methodSet.addMethod(this.generateStaticBlock(t, clazz));
			}
		}

		private Method generateStaticBlock(Tree t, String clazz) throws IOException {
			Method block = new Method();
			block.setName("<clinit>"); // Class init keyword
			if (this.withAsts) { // Extracting AST only if needed
				for (Tree child : t.getChildren())
					if ("Block".equals(child.getType().toString()))
						block.setAst(this.extractAstBody(child));
			}
			block.setSignature(clazz + "#" + block.getName() + "()");
			block.setBody(this.readBodyText(t));
			return block;
		}

		private Method generateMethod(Tree methodDecl, String clazz) throws IOException {
			Method method = new Method();
			Tree bodyBlock = this.getBodyBlock(methodDecl);
			Signature signature;
			// If there is a method body, the signature is formed by the list
			// of all its left siblings
			if (bodyBlock != null) {
				signature = this.extractSignature(methodDecl.getChildren().subList(0, bodyBlock.positionInParent()));
				if (this.withAsts) // Extracting ASTs only if needed
					method.setAst(this.extractAstBody(bodyBlock));
				// Extracting the textual body representation
				method.setBody(this.readBodyText(bodyBlock));
			} else // Otherwise the whole subtree of declaration is the signature
				signature = this.extractSignature(methodDecl.getChildren());
			method.setSignature(this.getMethodSignature(signature, clazz));
			return method;
		}

		private String getMethodSignature(Signature signature, String clazz) {
			StringBuilder sb = new StringBuilder(clazz);
			sb.append("#").append(signature.name).append("(");
			if (signature.arguments.size() > 0) {
				for (Argument argument : signature.arguments)
					sb.append(argument.type).append(",");
				sb.deleteCharAt(sb.length() - 1); // Removing last coma
			}
			return sb.append(")").toString();
		}

		private String readBodyText(Tree bodyBlock) throws IOException {
			int start = bodyBlock.getPos();
			int length = bodyBlock.getLength();
			byte[] buffer = new byte[length];
			this.fileReader.seek(start);
			this.fileReader.read(buffer, 0, length);
			// Removing comments before returning the body
			return this.removeComments(new String(buffer));
		}

		private String removeComments(String content) {
			return content.replaceAll("(?s)/\\*.*\\*/", "").replaceAll("//.*", "").replaceAll("\r", "");
		}

		private Tree getBodyBlock(Tree n) {
			for (Tree c : n.getChildren())
				if (c.getType().toString().equals("Block"))
					return c;
			return null;
		}

		private static class Signature {
			private String returnType;
			private String name;
			private final List<Argument> arguments = new LinkedList<>();
		}

		private static class Argument {
			private String type;
			private String name;
		}

		private Signature extractSignature(List<Tree> trees) {
			Signature signature = new Signature();
			for (Tree t : trees) {
				if (t.getType().toString().equals("SimpleName"))
					signature.name = t.getLabel();
				else if (t.getType().toString().equals("SingleVariableDeclaration"))
					signature.arguments.add(this.extractArgument(t));
				else if (this.isTypeNode(t))
					signature.returnType = this.getType(t);
			}
			return signature;
		}

		private Argument extractArgument(Tree t) {
			Argument arg = new Argument();
			for (Tree child : t.getChildren()) {
				if ("SimpleName".equals(child.getType().toString()))
					arg.name = child.getLabel();
				else if (this.isSimpleTypeNode(child))
					arg.type = this.getType(child);
				else if ("ArrayType".equals(child.getType().toString()))
					arg.type = this.getArrayType(child);
				else if ("ParameterizedType".equals(child.getType().toString()))
					arg.type = this.getParameterizedType(child);
				else if ("SingleVariableDeclaration".equals(child.getType().toString())
						&& "VARARGS_TYPE".equals(child.getChild(0).getType().toString()))
					this.getVariadicType(child, arg);
				else
					arg.type = "<UNKNOWN>";
			}
			return arg;
		}

		private String getType(Tree t) {
			switch (t.getType().toString()) {
			case "PrimitiveType":
				return this.getPrimitiveType(t);
			case "SimpleType":
				return this.getSimpleType(t);
			case "ArrayType":
				return this.getArrayType(t);
			case "ParameterizedType":
				return this.getParameterizedType(t);
			case "WildcardType":
				return this.getWildcardType(t);
			default:
				return "<UNKNOWN>";
			}
		}

		private String getPrimitiveType(Tree t) {
			return t.getLabel();
		}

		private String getSimpleType(Tree t) {
			for (Tree child : t.getChildren())
				if (child.getType().toString().equals("SimpleName"))
					return child.getLabel();
			return "<UNKNOWN>";
		}

		private String getArrayType(Tree t) {
			String type = "<UNKNOWN>";
			// Counting dimensions
			int dimensions = 0;
			for (Tree child : t.getChildren())
				if (this.isTypeNode(child))
					type = this.getType(child);
				else if (child.getType().toString().equals("Dimension"))
					dimensions++;
			return type + "[]".repeat(dimensions);
		}

		private String getParameterizedType(Tree t) {
			int genericCount = 0;
			StringBuilder type = new StringBuilder();
			for (Tree child : t.getChildren()) {
				if (isTypeNode(child)) {
					if (type.length() == 0) // First type
						type.append(this.getType(child)).append("<");
					else {
						genericCount++;
						type.append(this.getType(child)).append(", "); // Other parameters
					}
				}
			}
			if (genericCount > 0)
				type.delete(type.length() - 2, type.length());
			return type.append(">").toString();
		}

		private String getWildcardType(Tree t) {
			StringBuilder type = new StringBuilder();
			if (t.getType().toString().equals("WildcardType")) {
				type.append("?");
				if (t.getChildren().size() == 1 && isTypeNode(t.getChild(0))) {
					type.append(" extends ").append(this.getType(t.getChild(0)));
				}
			}
			return type.toString();
		}

		private void getVariadicType(Tree t, Argument arg) {
			for (Tree child : t.getChildren()) {
				if ("SimpleName".equals(child.getType().toString()))
					arg.name = child.getLabel();
				else if ("VARARGS_TYPE".equals(child.getType().toString())) {
					for (Tree nephew : child.getChildren())
						if (this.isTypeNode(nephew))
							arg.type = this.getType(nephew);
				}
			}
		}

		private boolean isClassDeclarationNode(Tree n) {
			if (n.getType().toString().equals("TypeDeclaration"))
				for (Tree t : n.getChildren())
					if (t.getType().toString().equals("TYPE_DECLARATION_KIND") && t.getLabel().equals("class"))
						return true;
			return false;
		}

		private boolean isPackageDeclarationNode(Tree n) {
			return n.getType().toString().equals("PackageDeclaration");
		}

		private boolean isStaticBlock(Tree n) {
			return "Initializer".equals(n.getType().toString());
		}

		private boolean isMethodDeclarationNode(Tree n) {
			return n.getType().toString().equals("MethodDeclaration");
		}

		private boolean isSimpleTypeNode(Tree n) {
			switch (n.getType().toString()) {
			case "PrimitiveType":
			case "SimpleType":
			case "WildcardType":
				return true;
			default:
				return false;
			}
		}

		private boolean isTypeNode(Tree n) {
			switch (n.getType().toString()) {
			case "PrimitiveType":
			case "SimpleType":
			case "ArrayType":
			case "ParameterizedType":
			case "WildcardType":
				return true;
			default:
				return false;
			}
		}

		private String extractPackageName(Tree pkgDecl) {
			for (Tree t : pkgDecl.getChildren())
				switch (t.getType().toString()) {
				case "QualifiedName":
				case "SimpleName":
					return t.getLabel();
				}
			return "<UNKNOWN>";
		}

		private ASTNode extractNode(Tree t, ASTNode parent) {
			try {
				switch (t.getType().toString()) {
				case "IfStatement":
					return this.generateIfNode(t, parent);
				case "ForStatement":
					return this.generateForNode(t, parent);
				case "TryStatement":
					return this.generateTryNode(t, parent);
				case "NullLiteral":
					return this.generateNullNode(t, parent);
				case "ThisExpression":
					return this.generateThisNode(t, parent);
				case "EmptyStatement":
					return this.generateEmptyStatementNode(t, parent);
				case "WhileStatement":
					return this.generateWhileStatementNode(t, parent);
				case "DoStatement":
					return this.generateDoWhileStatementNode(t, parent);
				case "BreakStatement":
					return this.generateBreakStatementNode(t, parent);
//          case "SwitchStatement":  // Untreated actually
				default:
					return this.generateDefaultNode(t, parent);
				}
			} catch (Error e) {
				LOG.error(t.toTreeString());
				throw e;
			}
		}

		private ASTNode generateNullNode(Tree t, ASTNode parent) {
			ASTContent nullContent = this.generateContent(t.getType().toString());
			ASTNode nullNode = new ASTNode(id++, nullContent, parent);
			nullNode.addChild(new ASTNode(id++, this.generateLexeme("NULL"), parent));
			return nullNode;
		}

		private ASTNode generateThisNode(Tree t, ASTNode parent) {
			ASTContent thisContent = this.generateContent(t.getType().toString());
			ASTNode thisNode = new ASTNode(id++, thisContent, parent);
			ASTNode thisLexeme = new ASTNode(id++, this.generateLexeme("this"), thisNode);
			thisNode.addChild(thisLexeme);
			return thisNode;
		}

		private ASTNode generateBreakStatementNode(Tree t, ASTNode parent) {
			ASTNode breakNode = new ASTNode(id++, this.generateContent(t.getType().toString()), parent);
			breakNode.addChild(new ASTNode(id++, this.generateLexeme("break"), parent));
			return breakNode;
		}

		private ASTNode generateIfNode(Tree t, ASTNode parent) {
			// If T has 3 children, the first is the condition, the 2nd the then block
			// and the 3rd is the else block (if any)
			Tree conditionNode = t.getChild(0);
			Tree thenNode = t.getChild(1);
			Tree elseNode = t.getChildren().size() == 3 ? t.getChild(2) : null;
			ASTContent ifContent = this.generateContent(t.getType().toString());
			ASTNode ifNode = new ASTNode(id++, ifContent, parent);
			// Condition node
			ASTContent conditionContent = this.generateContent("IfCondition");
			ASTNode condition = new ASTNode(id++, conditionContent, ifNode);
			condition.addChild(this.extractNode(conditionNode, condition));
			ifNode.addChild(condition);
			// Then node
			ASTContent thenContent = this.generateContent("Then");
			ASTNode then = new ASTNode(id++, thenContent, ifNode);
			then.addChild(this.extractNode(thenNode, then));
			ifNode.addChild(then);
			// Else if it is present
			if (elseNode != null) {
				ASTContent elseContent = this.generateContent("Else");
				ASTNode elze = new ASTNode(id++, elseContent, ifNode);
				elze.addChild(this.extractNode(elseNode, elze));
				ifNode.addChild(elze);
			}
			return ifNode;
		}

		private ASTNode generateForNode(Tree t, ASTNode parent) {
			ASTNode forNode = new ASTNode(id++, this.generateContent(t), parent);
			for (Tree child : t.getChildren())
				forNode.addChild(this.extractNode(child, forNode));
			return forNode;
		}

		private ASTNode generateWhileStatementNode(Tree t, ASTNode parent) {
			ASTNode whileNode = new ASTNode(id++, this.generateContent(t), parent);
			Tree condition = t.getChild(0);
			ASTNode loopCondition = new ASTNode(id++, this.generateContent("LoopCondition"), whileNode);
			loopCondition.addChild(this.extractNode(condition, whileNode));
			whileNode.addChild(loopCondition);
			Tree body = t.getChild(1);
			ASTNode loopBody = new ASTNode(id++, this.generateContent("LoopBody"), whileNode);
			for (Tree child : body.getChildren())
				loopBody.addChild(this.extractNode(child, loopBody));
			whileNode.addChild(loopBody);
			return whileNode;
		}

		private ASTNode generateDoWhileStatementNode(Tree t, ASTNode parent) {
			ASTNode doNode = new ASTNode(id++, this.generateContent(t), parent);
			// Creating the condition node first (for matching purposes)
			Tree condition = t.getChild(1);
			ASTNode loopCondition = new ASTNode(id++, this.generateContent("LoopCondition"), doNode);
			loopCondition.addChild(this.extractNode(condition, doNode));
			doNode.addChild(loopCondition);
			// ...then we create the body
			Tree body = t.getChild(0);
			ASTNode loopBody = new ASTNode(id++, this.generateContent("LoopBody"), doNode);
			for (Tree child : body.getChildren())
				loopBody.addChild(this.extractNode(child, loopBody));
			doNode.addChild(loopBody);
			return doNode;
		}

		private ASTNode generateEmptyStatementNode(Tree t, ASTNode parent) {
			ASTContent emptyContent = this.generateContent(t.getType().toString());
			ASTNode emptyNode = new ASTNode(id++, emptyContent, parent);
			ASTContent lexeme = this.generateLexeme(";");
			emptyNode.addChild(new ASTNode(id++, lexeme, emptyNode));
			return emptyNode;
		}

		private ASTNode generateTryNode(Tree t, ASTNode parent) {
			ASTContent content = this.generateContent(t.getType().toString());
			ASTNode node = new ASTNode(id++, content, parent);
			ASTContent tryContent = this.generateContent("TryKeyword");
			ASTContent tryLexeme = this.generateLexeme("try");
			ASTNode tryNode = new ASTNode(id++, tryContent, node);
			tryNode.addChild(new ASTNode(id++, tryLexeme, tryNode));
			node.addChild(tryNode);
			for (Tree child : t.getChildren())
				node.addChild(this.extractNode(child, node));
			return node;
		}

		private ASTNode generateDefaultNode(Tree t, ASTNode parent) {
			ASTContent content = this.generateContent(t.getType().toString());
			ASTNode node = new ASTNode(id++, content, parent);
			// If a node has a label, a terminal node is added
			if (!t.getLabel().isEmpty()) {
				ASTContent childContent = this.generateLexeme(t.getLabel());
				node.addChild(new ASTNode(id++, childContent, node));
			}
			// Fix for wildcard type
			if (t.getType().toString().equals("WildcardType"))
				node.addChild(new ASTNode(id++, this.generateLexeme("?"), node));
			// Fix for array type
			if (t.getType().toString().equals("Dimension") && t.getChildren().isEmpty())
				node.addChild(new ASTNode(id++, this.generateLexeme("[]"), node));
			// Fix for constructor invocation without arguments
			if (t.getType().toString().equals("ConstructorInvocation") && t.getChildren().isEmpty())
				node.addChild(new ASTNode(id++, this.generateLexeme("<no_args>"), node));
			// Fix for return without value
			if (t.getType().toString().equals("ReturnStatement") && t.getChildren().isEmpty())
				node.addChild(new ASTNode(id++, this.generateLexeme("<no_value>"), node));
			// Fix for default label in switch
			if (t.getType().toString().equals("SwitchCase") && t.getChildren().isEmpty())
				node.addChild(new ASTNode(id++, this.generateLexeme("default"), node));
			// Evaluating children
			for (Tree child : t.getChildren())
				node.addChild(this.extractNode(child, node));
			return node;
		}

		private String extractNameFromClassDeclaration(Tree classDecl) {
			for (Tree t : classDecl.getChildren())
				if (t.getType().toString().equals("SimpleName"))
					return t.getLabel();
			return "<UNKNOWN>";
		}

		private ASTRepresentation extractAstBody(Tree body) {
			this.id = 0;
			return new ASTRepresentation(this.extractNode(body, null));
		}

		private ASTContent generateContent(Tree t) {
			return this.generateContent(t.getType().toString());
		}

		private ASTContent generateContent(String instructionType) {
			ASTContent ctx = new ASTContent();
			ctx.setInstructionType(instructionType);
			return ctx;
		}

		private ASTContent generateLexeme(String lexeme) {
			ASTContent ctx = new ASTContent();
			ctx.setLexeme(lexeme);
			return ctx;
		}
	}

}
