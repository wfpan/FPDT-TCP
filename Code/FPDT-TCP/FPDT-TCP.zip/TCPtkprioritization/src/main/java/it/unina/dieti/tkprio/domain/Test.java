package it.unina.dieti.tkprio.domain;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**the class to store info of each test, including test name, 
 * cost time, list of covered methods, and score*/
public class Test {

	private String name;

	private Float time;

	/**coveredMethods list of this test*/
	private List<Method> coveredMethods = new LinkedList<>();
	/**Score assigned by prioritization techniques*/
	private Float score; 

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Float getTime() {
		return time;
	}

	public void setTime(Float time) {
		this.time = time;
	}

	public Float getScore() {
		return score;
	}

	public void setScore(Float score) {
		this.score = score;
	}

	public List<Method> getCoveredMethods() {
		return coveredMethods;
	}

	public void addCoveredMethod(Method method) {
		this.coveredMethods.add(method);
	}

	public void setCoveredMethods(List<Method> methods) {
		this.coveredMethods = methods;
	}

	/**
	 * Checks if this test covers a method with the given signature.
	 *
	 * @param methodSignature The signature of the method
	 * @return true if this test covers a method with the same signature, false
	 *         otherwise
	 */
	public boolean coversBySignature(String methodSignature) {
		for (Method method : this.coveredMethods)
			if (method.getSignature().equals(methodSignature))
				return true;
		return false;
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.name);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Test test = (Test) o;
		return name.equals(test.name);
	}

	@Override
	public String toString() {
		return "Test [name=" + name + ", score=" + score + "]";
	}

	
	
	
}
