package it.unina.dieti.tkprio.rtp.strategies;

import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.rtp.strategies.helpers.QSSelectorI;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;
import it.unina.dieti.tkprio.rtp.strategies.helpers.TotalCoverageSelector;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class QuotientSetPrioritization implements PrioritizationStrategyI {

	private final static String SUFFIX = "-QS";

	private final PrioritizationStrategyI strategy;

	private final QSSelectorI selector;

	public QuotientSetPrioritization(PrioritizationStrategyI strategy) {
		this(strategy, new TotalCoverageSelector());
	}

	public QuotientSetPrioritization(PrioritizationStrategyI strategy, QSSelectorI selector) {
		this.strategy = strategy;
		this.selector = selector;
	}

	@Override
	public String name() {
		return this.strategy.name() + SUFFIX;
	}

	@Override
	public void setUp(StrategyPaths paths) {
		// Proxying to the original strategy setUp method
		this.strategy.setUp(paths);
	}

	@Override
	public Permutation prioritize(TestSuite suite) {
		// Creating the quotient set using the wrapped prioritization strategy
		Map<Float, List<Test>> quotientSet = this.createQuotientSet(this.strategy.prioritize(suite));
		// Obtaining zero scored class and removing it from the QS
		List<Test> zeroClass = null;
		if (quotientSet.containsKey(0f)) {
			zeroClass = quotientSet.get(0f);
			quotientSet.remove(0f);
		}
		Permutation permutation = new Permutation();
		// Obtaining sorted scores (using as a queue)
		List<Float> scores = quotientSet.keySet().stream().sorted((s1, s2) -> Float.compare(s2, s1))
				.collect(Collectors.toList());
		while (!scores.isEmpty()) {
			// Retrieving the first score
			float actual = scores.remove(0);
			List<Test> equivalenceClass = quotientSet.get(actual);
			// Selecting a test from the equivalence class
			Test selected = this.selector.select(equivalenceClass);
			equivalenceClass.remove(selected);
			permutation.addTest(selected);
			// Adding the score in last position if there are still test cases
			if (!equivalenceClass.isEmpty())
				scores.add(actual);
		}
		// Adding back the zero class if it was present
		if (zeroClass != null)
			for (Test test : zeroClass)
				permutation.addTest(test);
		return permutation;
	}

	//原来的版本
	private Map<Float, List<Test>> createQuotientSet(Permutation permutation) {
		Map<Float, List<Test>> quotient = new HashMap<>();
		for (Test test : permutation) {
			if (!quotient.containsKey(test.getScore())) {
				quotient.put(test.getScore(), new LinkedList<>());
			}
			quotient.get(test.getScore()).add(test);
		}
		return quotient;
	}
	
	@Deprecated
	private Map<Float, List<Test>> createQuotientSet2(Permutation permutation) {
		Map<Float, List<Test>> quotient = new HashMap<>();
		float eps = 1e-6f;
		for (Test test : permutation) {
			float target = test.getScore();
			boolean contains = quotient.keySet()
                    .stream()
                    .anyMatch(k -> Math.abs(k - target) < eps);
			
			if (!contains) {
				quotient.put(test.getScore(), new LinkedList<>());
			}
			
			List<Test> tList = quotient.entrySet()
	                 .stream()
	                 .filter(e -> Math.abs(e.getKey() - target) < eps)
	                 .map(Map.Entry::getValue)
	                 .findFirst()          // 只拿第一条
	                 .orElse(Collections.emptyList());        // 如果没有返回 null，也可以 orElseThrow()
			tList.add(test);
		}
		return quotient;
	}

}
