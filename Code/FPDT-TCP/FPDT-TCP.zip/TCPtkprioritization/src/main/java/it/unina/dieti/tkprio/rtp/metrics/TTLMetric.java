package it.unina.dieti.tkprio.rtp.metrics;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.exceptions.NoFaultsDiscoveredException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

public class TTLMetric implements MetricI {

  private static final Logger LOG = LoggerFactory.getLogger(TTLMetric.class);

  public static final String NAME = "TTL";

  private FaultMatrix matrix;

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public void setUp(FaultMatrix matrix) {
    this.matrix = matrix;
  }

  @Override
  public float evaluate(Permutation permutation) {
    Set<Integer> faultsToDiscover = this.matrix.getFaultsDiscoveredByPermutation(permutation);
    if(faultsToDiscover.isEmpty()) {
      LOG.warn("No faults discovered by permutation when evaluating " + NAME);
      throw new NoFaultsDiscoveredException("No faults discovered by permutation");
    }
    float totalTime = permutation.getTests().stream().reduce(0f, (sub, test) -> sub + test.getTime(), Float::sum);
    float time = 0;
    for(Test test: permutation) {
      this.matrix.getFaultsForTest(test.getName()).forEach(faultsToDiscover::remove);
      time += test.getTime();
      if(faultsToDiscover.isEmpty())
        break;
    }
    if(time > totalTime)
      throw new NoFaultsDiscoveredException("No faults discovered when evaluating " + NAME);
    return time / totalTime;
  }
}
