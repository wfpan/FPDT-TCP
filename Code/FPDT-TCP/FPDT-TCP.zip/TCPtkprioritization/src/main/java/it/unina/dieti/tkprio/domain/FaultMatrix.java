package it.unina.dieti.tkprio.domain;

import java.util.*;

public class FaultMatrix {

	private String project;

	private String version;

	private int variant;
	
	/**tests set Set-String-*/
	private final Set<String> tests = new HashSet<>();
	/**faults set Set-Integer- faults*/
	private final Set<Integer> faults = new HashSet<>();
	/**Map-String, List- Integer--: test to the fault list*/
	private final Map<String, List<Integer>> testMap = new HashMap<>();
	/**Map-Integer, List-String--: fault to the test list */
	private final Map<Integer, List<String>> faultMap = new HashMap<>();

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public int getVariant() {
		return variant;
	}

	public void setVariant(int variant) {
		this.variant = variant;
	}

	public Set<String> getTests() {
		return tests;
	}

	/**1. add the test to test set
	 * 2. add the test to testMap: test vs. list*/
	public void addTest(String test) {
		this.tests.add(test);
		this.testMap.put(test, new LinkedList<>());
	}

	public Set<Integer> getFaults() {
		return faults;
	}

	/**add the fault to the set Set-Integer-*/
	public void addFault(Integer fault) {
		this.faults.add(fault);
	}

	public boolean discover(String test, Integer fault) {
		return this.testMap.containsKey(test) && this.testMap.get(test).contains(fault);
	}

	public List<Integer> getFaultsForTest(String test) {
		if (this.testMap.containsKey(test))
			return this.testMap.get(test);
		return new ArrayList<>();
	}
	/**It builds two maps: 1) test to the fault list, and 2) fault to the test list*/
	public void addFaultToTest(String test, int fault) {
		this.faults.add(fault); // Adding the fault if is not present
		if (!this.testMap.containsKey(test))
			this.addTest(test);
		this.testMap.get(test).add(fault);
		// Adding the test to the faults
		if (!this.faultMap.containsKey(fault))
			this.faultMap.put(fault, new LinkedList<>());
		this.faultMap.get(fault).add(test);
	}

	public Set<Integer> getFaultsDiscoveredByPermutation(Permutation permutation) {
		Set<Integer> discovered = new HashSet<>();
		for (int fault : this.faults)
			if (permutation.getTests().stream().anyMatch(t -> this.discover(t.getName(), fault)))
				discovered.add(fault);
		return discovered;
	}
}
