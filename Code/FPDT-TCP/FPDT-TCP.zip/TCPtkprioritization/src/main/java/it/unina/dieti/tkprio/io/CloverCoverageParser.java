package it.unina.dieti.tkprio.io;

import it.unina.dieti.tkprio.domain.CoverageReport;
import it.unina.dieti.tkprio.domain.Method;
import it.unina.dieti.tkprio.domain.Test;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class CloverCoverageParser {

	/**
	 * Parses the content of the clover coverage report in the given path.
	 *
	 * @param path The path to the coverage report in XML format
	 * @return The report domain model (a report object)
	 */
	public CoverageReport parse(Path path) {
		if (!Files.isRegularFile(path))
			throw new RuntimeException("File " + path + " does not exists or is not a regular file");
		try {
			ParserTask task = new ParserTask();
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			parser.parse(path.toFile(), task);
			return task.report;
		} catch (ParserConfigurationException | SAXException | IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * SAX parser task to create the report. Allow parallel extraction of reports.
	 */
	private static class ParserTask extends DefaultHandler {
		/**Map:String vs test; the test has CoveredMethod*/
		private Map<String, Test> tests;
		private CoverageReport report;
		private String pkg;
		private String clazz;
		private Method method;
		/**the method name including parameters*/
		private StringBuilder signature;
		/**clover-report-method-1.1 without line elements (it uses this one);
		 * clover-report-1.1 with line elements*/
		private boolean insideLine;

		private final static String E_PACKAGE = "package";
		private final static String E_CLASS = "class";
		private final static String E_METHOD = "method";
		private final static String E_SIGNATURE = "signature";
		private final static String E_PARAMETER = "parameter";
		private final static String E_TEST = "test";
		private final static String E_LINE = "line";

		private final static String A_PACKAGE_NAME = "name";
		private final static String A_CLASS_NAME = "name";
		private final static String A_METHOD_NAME = "name";
		private final static String A_PARAM_TYPE = "type";
		private final static String A_TEST_NAME = "name";

		@Override
		public void startDocument() throws SAXException {
			this.report = new CoverageReport();
			this.tests = new HashMap<>();
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes)
				throws SAXException {
			switch (qName) {
			case E_PACKAGE:
				this.pkg = attributes.getValue(A_PACKAGE_NAME);
				break;
			case E_CLASS:
				this.clazz = attributes.getValue(A_CLASS_NAME);
				break;
			case E_METHOD:
				this.method = new Method();
				this.method.setName(this.buildMethodQualifiedName(attributes.getValue(A_METHOD_NAME)));
				this.signature = new StringBuilder();
				break;
			case E_SIGNATURE:
				this.signature.append(this.method.getName()).append("(");
				break;
			case E_PARAMETER:
				this.signature.append(attributes.getValue(A_PARAM_TYPE)).append(",");
				break;
			case E_TEST:
				if (!this.insideLine) { // Adding method only if the test is not inside a line element
					Test test = this.getTest(attributes.getValue(A_TEST_NAME));
					test.addCoveredMethod(this.method);
				}
				break;
			case E_LINE:
				this.insideLine = true;
				break;
			}
		}

		@Override
		public void endElement(String uri, String localName, String qName) throws SAXException {
			switch (qName) {
			case E_METHOD:
				this.method.setSignature(this.signature.toString());
				this.report.addMethod(this.method);
				break;
			case E_SIGNATURE:
				if (this.signature.lastIndexOf(",") == this.signature.length() - 1) //判断最后是不是多了个逗号,
					this.signature.deleteCharAt(this.signature.length() - 1); //删除多余的逗号
				this.signature.append(")");
				break;
			case E_LINE:
				this.insideLine = false;
				break;
			}
		}

		@Override
		public void endDocument() throws SAXException {
			for (Test test : this.tests.values())
				this.report.addTest(test); // add the test (with coveraged method) to the test set of report
		}

		private Test getTest(String name) {
			if (!this.tests.containsKey(name)) {
				// Newly discovered test: adding to the map
				Test test = new Test();
				test.setName(name);
				this.tests.put(name, test);
				return test;
			}
			// Already in the map: simply returning it
			return this.tests.get(name);
		}

		/**build the full method name, i.e., package.class.method*/
		private String buildMethodQualifiedName(String name) {
			return (this.pkg.isEmpty() ? "" : this.pkg + ".") + this.clazz + Method.CLASS_DELIMITER + name;
		}
	}
}
