package it.unina.dieti.tkprio.rtp.strategies.helpers;

import java.nio.file.Path;
import java.util.List;

/**
 * Commodity class to set up all the paths in prioritization strategies.
 */
public class StrategyPaths {

	private Path previousSurefireReportsFolder;
	private Path previousCoveragePath;
	private List<Path> previousSources;

	private Path currentSurefireReportsFolder;
	private List<Path> currentSources;

	//----自己增加的---------------------//
	private Path softwareNetworkPath;
	private Path cognitiveFilePath;
	private Path buggyFilePath;
	private Path realBuggyFilePath;
	//----------------------------------//

	public Path getPreviousSurefireReportsFolder() {
		return previousSurefireReportsFolder;
	}

	public StrategyPaths setPreviousSurefireReportsFolder(Path previousSurefireReportsFolder) {
		this.previousSurefireReportsFolder = previousSurefireReportsFolder;
		return this;
	}

	public Path getPreviousCoveragePath() {
		return previousCoveragePath;
	}

	public StrategyPaths setPreviousCoveragePath(Path previousCoveragePath) {
		this.previousCoveragePath = previousCoveragePath;
		return this;
	}

	public Path getCurrentSurefireReportsFolder() {
		return currentSurefireReportsFolder;
	}

	public StrategyPaths setCurrentSurefireReportsFolder(Path currentSurefireReportsFolder) {
		this.currentSurefireReportsFolder = currentSurefireReportsFolder;
		return this;
	}

	public List<Path> getPreviousSources() {
		return previousSources;
	}

	public StrategyPaths setPreviousSources(List<Path> previousSources) {
		this.previousSources = previousSources;
		return this;
	}

	public List<Path> getCurrentSources() {
		return currentSources;
	}

	public StrategyPaths setCurrentSources(List<Path> currentSources) {
		this.currentSources = currentSources;
		return this;
	}

	public Path getSoftwareNetworkPath() {
		return softwareNetworkPath;
	}

	public void setSoftwareNetworkPath(Path softwareNetworkPath) {
		this.softwareNetworkPath = softwareNetworkPath;
	}

	public Path getCognitiveFilePath() {
		return cognitiveFilePath;
	}

	public void setCognitiveFilePath(Path cognitiveFilePath) {
		this.cognitiveFilePath = cognitiveFilePath;
	}

	public Path getBuggyFilePath() {
		return buggyFilePath;
	}

	public void setBuggyFilePath(Path buggyFilePath) {
		this.buggyFilePath = buggyFilePath;
	}

	public Path getRealBuggyFilePath() {
		return realBuggyFilePath;
	}

	public void setRealBuggyFilePath(Path realBuggyFilePath) {
		this.realBuggyFilePath = realBuggyFilePath;
	}

}
