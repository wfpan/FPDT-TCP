package it.unina.dieti.tkprio.rtp.metrics;

import it.unina.dieti.tkprio.domain.FaultMatrix;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.exceptions.NoFaultsDiscoveredException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;

public class PTLMetric implements MetricI {

  private static final Logger LOG = LoggerFactory.getLogger(PTLMetric.class);

  public static final String NAME = "PTL";

  private FaultMatrix matrix;

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public void setUp(FaultMatrix matrix) {
    this.matrix = matrix;
  }

  @Override
  public float evaluate(Permutation permutation) {
    Set<Integer> faultsToDiscover = this.matrix.getFaultsDiscoveredByPermutation(permutation);
    if(faultsToDiscover.isEmpty()) {
      LOG.warn("No faults discovered by permutation when evaluating " + NAME);
      throw new NoFaultsDiscoveredException("No faults discovered by permutation");
    }
    int idx = 1;
    int n = permutation.getTests().size();
    for(Test test: permutation) {
      this.matrix.getFaultsForTest(test.getName()).forEach(faultsToDiscover::remove);
      if(faultsToDiscover.isEmpty())
        break;
      idx++;
    }
    if(idx > n)
      throw new NoFaultsDiscoveredException("No faults discovered when evaluating " + NAME);
    return (float) idx / n;
  }
}
