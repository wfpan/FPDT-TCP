package it.unina.dieti.tkprio.rtp.strategies;

import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

public class NoPrioritization implements PrioritizationStrategyI {

  public static final String NAME = "NOP";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public void setUp(StrategyPaths paths) {
    // Nothing to do
  }

  @Override
  public Permutation prioritize(TestSuite suite) {
    // Simply returns a permutation with all tests in the same order
    return new Permutation(suite);
  }
}
