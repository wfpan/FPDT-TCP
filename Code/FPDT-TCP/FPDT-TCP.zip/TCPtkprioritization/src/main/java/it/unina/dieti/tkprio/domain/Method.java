package it.unina.dieti.tkprio.domain;

import it.unina.dieti.tkprio.ast.ASTRepresentation;

import java.util.Objects;

public class Method {

	/** Standard delimiter to split classpath from method's name */
	public static final String CLASS_DELIMITER = "#";

	private String signature;

	private String name;

	private ASTRepresentation ast;

	private String body;

	private Float dissimilarity;
	
	/**存储不相似性*/
	private Float disWolf =0.f;
	private Float mIDF = 0.f;

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ASTRepresentation getAst() {
		return ast;
	}

	public void setAst(ASTRepresentation ast) {
		this.ast = ast;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Float getDissimilarity() {
		return dissimilarity;
	}

	public void setDissimilarity(Float dissimilarity) {
		this.dissimilarity = dissimilarity;
	}
	
	public Float getDisWolf() {
		return disWolf;
	}

	public void setDisWolf(Float disWolf) {
		this.disWolf = disWolf;
	}
	

	public Float getmIDF() {
		return mIDF;
	}

	public void setmIDF(Float mIDF) {
		this.mIDF = mIDF;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Method method = (Method) o;
		return this.signature.equals(method.signature);
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.signature);
	}
}
