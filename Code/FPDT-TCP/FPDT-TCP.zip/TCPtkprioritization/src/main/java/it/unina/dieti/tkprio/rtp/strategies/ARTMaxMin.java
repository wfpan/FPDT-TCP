/*******************************************************************************
 * MIT License
 *
 * Copyright (c) 2023 Università degli Studi di Napoli Federico II
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

package it.unina.dieti.tkprio.rtp.strategies;
/*
 * Use ART-MaxMin Algorithm for Test Case Prioritization.
 * Yafeng.Lu@cs.utdallas.edu
 */

import it.unina.dieti.tkprio.domain.CoverageReport;
import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.io.CloverCoverageParser;
import it.unina.dieti.tkprio.rtp.strategies.helpers.CoverageMatrix;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;


public class ARTMaxMin implements PrioritizationStrategyI {

  private Path coverageReportPath;

  CoverageMatrix cm;
  char[][] coverageMatrix;
  final String sep = File.separator;
  ArrayList<Integer> coveredZero = new ArrayList<Integer>(); //Store the test case in case it covers 0 statements/methods/branches.

  public ARTMaxMin() {
  }

  public ARTMaxMin setCoverageReportPath(Path coveragePath) {
    this.coverageReportPath = coveragePath;
    return this;
  }

  public ARTMaxMin setCoverageMatrix(CoverageMatrix matrix) {
    this.cm = matrix;
    this.fillCoverageMatrix();
    return this;
  }

  private void fillCoverageMatrix() {
    this.coverageMatrix = new char[this.cm.getNumTests()][this.cm.getNumElements()];
    for(Test t: this.cm.getTests()) {
      int i = this.cm.getTestIndex(t);
      for(int j = 0; j < this.cm.getNumElements(); j++)
        this.coverageMatrix[i][j] = this.cm.isCovered(i, j) ? '1' : '0';
    }
  }

  private void createCm(TestSuite suite) {
    CloverCoverageParser parser = new CloverCoverageParser();
    CoverageReport report = parser.parse(this.coverageReportPath);
    this.cm = CoverageMatrix.create(suite, report);
  }

  public int[] getSelectedTestSequence(){

    int len = this.coverageMatrix.length, columnNum = this.coverageMatrix[0].length;
    int[] selectedTestSequence = new int[len];
    ArrayList<Integer> selected = new ArrayList<Integer>(); //Store the current selected test cases.

    final int LIMIT = 10; //The size of candidate tests, WARNING: test case number should be more than 10.
    //Generate procedure
    int first = (int)(len * Math.random()); //Randomly select the first element.
    selected.add(first);

    while(selected.size() < len){
      //Generate procedure
      ArrayList<Integer> candidate = new ArrayList<Integer>(); //Store the already selected candidate tests.

      char[] covered = new char[columnNum]; //Record the already covered statements/methods/branches.
      this.clearArray(covered);
      int coveredNum = 0; //Store the number of statements/methods/branches.
      boolean stop = false;
      //this.Print(selected);
      //Randomly select the first candidate.
      //int firstRandomCandidate = -1;
      ArrayList<Integer> tempList = new ArrayList<Integer>();
      for(int i=0; i<len; i++){
        if(! selected.contains(i)){
          tempList.add(i);
        }
      }
      int firstRandom = (int)(Math.random() * tempList.size());
      candidate.add(tempList.get(firstRandom));
      //tempList.remove(firstRandom);
      this.mergeIntoCurrentArray(covered, this.coverageMatrix[firstRandom]);
      coveredNum = this.getCoveredNumber(covered);

      //while(candidate.size() < LIMIT){
      while(true){
        //int[] leftCandidate = new int[len - selected];

        ArrayList<Integer> leftToChoose = new ArrayList<Integer>(); //int[len-selected.size()-candidate.size()]; //The left unselected candidates to choose.
        for(int i=0; i<len; i++){
          if(!selected.contains(i) && !candidate.contains(i)){
            leftToChoose.add(i);
          }
        }
        if(leftToChoose.size() == 0){
          //System.out.println("Nothing to choose.");
          break;
        }

        int selectedRandom = (int)(Math.random() * leftToChoose.size()); //Randomly select the next candidate.
        //System.out.println(selectedRandom+","+leftToChoose.size());
        int newCandidateIndex = leftToChoose.get(selectedRandom); //Get the index of new selected candidate.
        //if(this.getCoveredNumber(this.CoverageMatrix[newCandidateIndex]) == 0) continue;
        this.mergeIntoCurrentArray(covered, this.coverageMatrix[newCandidateIndex]); //Merge the new statements/methods/branches coverage into the covered array.
        int currentCovered = this.getCoveredNumber(covered);
        if(currentCovered > coveredNum){
          coveredNum = currentCovered;
          candidate.add(newCandidateIndex); //Add the selected candidate to the candidate arraylist.
          //leftCandidates[newCandidateIndex] = -1;
        }else{
          //System.out.println(newCandidateIndex+" break :");this.Print(this.CoverageMatrix[newCandidateIndex]);
          break; //If the statements/methods/branches coverage is not increase, then stop.
        }
      }
      //if(candidate.size() ==0) continue;
      //this.Print(candidate);
      //Select procedure
      //double[][] Distance = new double[selected.size()][candidate.size()]; //Store the distances of selected test cases to candidates.
      double[] MaxDistances = new double[candidate.size()]; //Get the maximum distance from the candidate minimum distances.
      for(int j=0; j<candidate.size(); j++){
        int candidateNo = candidate.get(j);
        double[] MinDistance = new double[selected.size()]; //Get the minimum distance from the selected minimum distances.
        for(int i=0; i<selected.size(); i++){
          int testCaseNo = selected.get(i);
          MinDistance[i] = this.getJaccardDistance(this.coverageMatrix[testCaseNo], this.coverageMatrix[candidateNo]);
				/*if(MinDistance[i] == Double.NEGATIVE_INFINITY || MinDistance[i] == Double.NaN){
					MinDistance[i] = 0;
					System.out.println("Got a MinDistance is Double.NaN");
				}*/
        }
        int MinIndex = this.getMinIndex(MinDistance);
        if(MinIndex == -1){
          System.out.println("ERROR: getSelectedTestSequence MinIndex == -1"); this.Print(MinDistance);this.Print(selected);this.Print(candidate);System.exit(1);
        }
        MaxDistances[j] = MinDistance[MinIndex]; //Assign each candidate's minimum distance to the MaxDistances array.
      }
      int MaxIndex = this.getMaxIndex(MaxDistances);
      if(MaxIndex == -1){
        System.out.println("ERROR: getSelectedTestSequence MaxIndex == -1"); this.Print(MaxDistances);this.Print(selected);this.Print(candidate);System.exit(1);
      }
      //Select the candidate to selected arraylist.
      selected.add(candidate.get(MaxIndex));
      //leftCandidates[newCandidateIndex] = -1;
    }
    //Add the elements of selected arraylist to the test case sequence.
    for(int i=0; i<selected.size(); i++){
      selectedTestSequence[i] = selected.get(i);
    }
    return selectedTestSequence;
  }
  //Calculate the Jaccard distance between two vector.
  public double getJaccardDistance(char[] a, char[] b){
    if(a.length != b.length){
      System.out.println("ERROR: length not equal.");
      System.exit(0);
    }
    int len = a.length;
    double distance = 0;
    int join = 0, combine = 0;
    char[] combinedArray = new char[len]; //Store the combined result of a and b.

    for(int i=0; i<len; i++){
      if(a[i] == '1' && b[i] == '1'){
        join++;
      }
      if(a[i] == '1'){
        combinedArray[i] = '1';
      }
      if(b[i] == '1'){
        combinedArray[i] = '1';
      }
    }
    combine = this.getCoveredNumber(combinedArray);
    if(combine == 0){
      return 0;
    }
    distance = 1.0 - (join / (double)combine);
    return distance;
  }
  //Return the minimum element's index of the double[].
  public int getMinIndex(double[] a){
    double min = Double.MAX_VALUE;
    int index = -1;
    for(int i=0; i<a.length; i++){
      if(a[i] < min){
        min = a[i];
        index = i;
      }
    }
    return index;
  }
  //Return the maximum element's index of the double[].
  public int getMaxIndex(double[] a){
    double max = -Double.MAX_VALUE;
    int index = -1;
    for(int i=0; i<a.length; i++){
      if(a[i] > max){
        max = a[i];
        index = i;
      }
    }
    return index;
  }
  //Calculate the number of '1' in the array.
  public int getCoveredNumber(char[] a){
    int num = 0;
    for(int i=0; i<a.length; i++){
      if(a[i] == '1'){
        num++;
      }
    }
    return num;
  }
  //Set all elements '0' in the array.
  public void clearArray(char[] a){
    for(int i=0; i<a.length; i++){
      a[i] = '0';
    }
  }
  //Merge all the '1's in the new array into the current array.
  public void mergeIntoCurrentArray(char[] current, char[] newArray){
    if(current.length != newArray.length){
      System.out.println("ERROR: mergeIntoCurrentArray: length is not equal.");
      System.exit(1);
    }
    int len = current.length;
    for(int i=0; i<len; i++){
      if(newArray[i] == '1')
        current[i] = newArray[i];
    }
  }
  public void Print(char[] a){
    System.out.println("------char[] Start-----Len: "+a.length);
    for(int i=0; i<a.length; i++){
      System.out.print(a[i]+",");
    }
    System.out.println("\n------char[] End------");
  }
  public void Print(int[] a){
    System.out.println("------int[] Start-----Len: "+a.length);
    for(int i=0; i<a.length; i++){
      System.out.print(a[i]+",");
    }
    System.out.println("\n------int[] End------");
  }
  public void Print(double[] a){
    System.out.println("------double[] Start-----Len: "+a.length);
    for(int i=0; i<a.length; i++){
      System.out.print(a[i]+",");
    }
    System.out.println("\n------double[] End------");
  }
  public void Print(ArrayList<Integer> a){
    System.out.println("------ArrayList<Integer> Start-----Len: "+a.size());
    for(int i=0; i<a.size(); i++){
      System.out.print(a.get(i)+",");
    }
    System.out.println("\n------ArrayList<Integer> End------");
  }

  public static final String NAME = "ART-MaxMin";

  @Override
  public String name() {
    return NAME;
  }

  @Override
  public void setUp(StrategyPaths paths) {
    this.coverageReportPath = paths.getPreviousCoveragePath();
  }

  @Override
  public Permutation prioritize(TestSuite suite) {
    Permutation permutation = new Permutation();
    if(this.cm == null)
      this.createCm(suite);
    this.fillCoverageMatrix();
    int[] selected = this.getSelectedTestSequence();
    for(int testIdx: selected)
      permutation.addTest(this.cm.getTestFromIndex(testIdx));
    return permutation;
  }

		/*//For Unit Test.
	public static void main(String[] args){
		ARTMaxMin art = new ARTMaxMin("you owen directory", "BranchCommonTestCasesMatrix.txt");
		art.Print(art.getSelectedTestSequence());

	}*/
}
