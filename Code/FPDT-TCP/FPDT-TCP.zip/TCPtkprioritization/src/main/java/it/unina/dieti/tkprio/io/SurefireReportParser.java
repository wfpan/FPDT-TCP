package it.unina.dieti.tkprio.io;

import it.unina.dieti.tkprio.domain.Test;
import it.unina.dieti.tkprio.domain.TestSuite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SurefireReportParser {

	private final static Logger LOG = LoggerFactory.getLogger(SurefireReportParser.class);

	/**To collect the information of each test case, including its class name, name, and time, and return 
	 * a TestSuite suite*/
	public TestSuite parse(Path reportFolder) {
		if (!Files.isDirectory(reportFolder))
			throw new RuntimeException("Path " + reportFolder + " is not a directory");
		try {
			ParserTask task = new ParserTask();
			final SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			Stream<Path> stream = Files.walk(reportFolder).filter(Files::isRegularFile)
					.filter(p -> p.toString().endsWith(".xml"));
			List<Path> reports = stream.collect(Collectors.toList());
			stream.close();
			for (Path report : reports)
				parser.parse(report.toFile(), task);
			return task.suite;
		} catch (IOException | ParserConfigurationException | SAXException e) {
			throw new RuntimeException(e);
		}
	}

	public static class ParserTask extends DefaultHandler {

		private final TestSuite suite;
		/**The suffix E means that it is an element*/
		private final static String E_TEST_CASE = "testcase";
		/**The suffix A means that it is an attribute*/
		private final static String A_TEST_CASE_CLASSNAME = "classname";
		private final static String A_TEST_CASE_NAME = "name";
		private final static String A_TEST_CASE_TIME = "time";

		private ParserTask() {
			this.suite = new TestSuite();
		}

		@Override
		public void startElement(String uri, String localName, String qName, Attributes attributes)
				throws SAXException {
			if (qName.equals(E_TEST_CASE)) {
				String name = this.normalizeTestName(
						attributes.getValue(A_TEST_CASE_CLASSNAME) + "#" + attributes.getValue(A_TEST_CASE_NAME));
				String timeStr = attributes.getValue(A_TEST_CASE_TIME);
				Float time = null;
				if (timeStr != null)
					time = Float.valueOf(timeStr);
				// Checking if the test is already in the suite
				if (suite.getByName(name) == null) {
					Test test = new Test();
					test.setName(name); //这里的test case应该指的是 test method
					test.setTime(time);
					this.suite.addTest(test);
				} else if (time != null) { // Parametric test already present: adding total time
					Test test = this.suite.getByName(name);
					if (test.getTime() == null)
						test.setTime(time);
					else
						test.setTime(test.getTime() + time);
				}
			}
		}

		/**
		 * Normalizes name for parametric tests.
		 *
		 * @param qualifiedName The full test name
		 * @return The name without parameters information
		 */
		private String normalizeTestName(String qualifiedName) {
			if (qualifiedName.endsWith("]")) {
				int idx = qualifiedName.lastIndexOf('[');
				if (idx != -1)
					qualifiedName = qualifiedName.substring(0, idx);
			}
			return qualifiedName;
		}

	}

}
