package it.unina.dieti.tkprio.rtp.strategies;

import it.unina.dieti.tkprio.domain.Permutation;
import it.unina.dieti.tkprio.domain.TestSuite;
import it.unina.dieti.tkprio.rtp.strategies.helpers.StrategyPaths;

public interface PrioritizationStrategyI {

	String name();

	void setUp(StrategyPaths paths);

	Permutation prioritize(TestSuite suite);

}
