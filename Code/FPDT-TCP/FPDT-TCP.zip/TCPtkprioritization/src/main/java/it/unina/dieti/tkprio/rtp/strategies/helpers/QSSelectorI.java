package it.unina.dieti.tkprio.rtp.strategies.helpers;

import it.unina.dieti.tkprio.domain.Test;

import java.util.List;

public interface QSSelectorI {

  Test select(List<Test> equivalenceClass);

}
