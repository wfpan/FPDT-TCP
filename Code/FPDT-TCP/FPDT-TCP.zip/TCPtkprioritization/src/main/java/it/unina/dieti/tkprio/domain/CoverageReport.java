package it.unina.dieti.tkprio.domain;

import java.util.HashSet;
import java.util.Set;
/**this class contains method set, test set, and their getter/setter methods*/
public class CoverageReport {
	/**the method set in this report*/
	private final HashSet<Method> methods = new HashSet<>();
	/**the test set in this report; each test has a coveragedMethod set*/
	private final Set<Test> tests = new HashSet<>();
	/**get the method set*/
	public Set<Method> getMethods() {
		return methods;
	}
	/**add a method to the method set*/
	public void addMethod(Method method) {
		this.methods.add(method);
	}
	/**get the test set; each test has a coveragedMethod set*/
	public Set<Test> getTests() {
		return this.tests;
	}
	/**add a test to the test set*/
	public void addTest(Test test) {
		this.tests.add(test);
	}
}
