package it.unina.dieti.tkprio.experiments;

public class ExecutionTimeResult {

  private String project;

  private String technique;

  private String previous;
  private int previousOrder;

  private String current;
  private int currentOrder;

  private float time;
  private float standardDeviation;

  public String getProject() {
    return project;
  }

  public ExecutionTimeResult setProject(String project) {
    this.project = project;
    return this;
  }

  public String getTechnique() {
    return technique;
  }

  public ExecutionTimeResult setTechnique(String technique) {
    this.technique = technique;
    return this;
  }

  public String getPrevious() {
    return previous;
  }

  public ExecutionTimeResult setPrevious(String previous) {
    this.previous = previous;
    return this;
  }

  public int getPreviousOrder() {
    return previousOrder;
  }

  public ExecutionTimeResult setPreviousOrder(int previousOrder) {
    this.previousOrder = previousOrder;
    return this;
  }

  public String getCurrent() {
    return current;
  }

  public ExecutionTimeResult setCurrent(String current) {
    this.current = current;
    return this;
  }

  public int getCurrentOrder() {
    return currentOrder;
  }

  public ExecutionTimeResult setCurrentOrder(int currentOrder) {
    this.currentOrder = currentOrder;
    return this;
  }

  public float getTime() {
    return time;
  }

  public ExecutionTimeResult setTime(float time) {
    this.time = time;
    return this;
  }

  public float getStandardDeviation() {
    return standardDeviation;
  }

  public ExecutionTimeResult setStandardDeviation(float standardDeviation) {
    this.standardDeviation = standardDeviation;
    return this;
  }
}
