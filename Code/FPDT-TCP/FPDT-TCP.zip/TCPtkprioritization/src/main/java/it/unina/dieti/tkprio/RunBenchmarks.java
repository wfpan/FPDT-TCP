package it.unina.dieti.tkprio;

import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.results.format.ResultFormatType;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.RunnerException;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.openjdk.jmh.runner.options.TimeValue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

public class RunBenchmarks {

	private static final int WARMUP_ITERATIONS = 0;
	private static final int WARMUP_TIME = 10;
	private static final int MEASUREMENT_ITERATIONS = 15;
	private static final int FORKS = 2;

	public static void main(String[] args) throws IOException, RunnerException {
		Path output = Configuration.fromDotenv().getResultsFolder().resolve("csv").resolve("benchmark.csv");
		Files.createDirectories(output.getParent());
		Options opts = new OptionsBuilder().include("it.unina.dieti.tkprio.benchmarks.*").mode(Mode.SingleShotTime)
				.timeUnit(TimeUnit.MILLISECONDS).warmupIterations(WARMUP_ITERATIONS)
				.warmupTime(TimeValue.seconds(WARMUP_TIME)).measurementIterations(MEASUREMENT_ITERATIONS)
				.jvmArgsPrepend("-server").forks(FORKS).result(output.toString()).resultFormat(ResultFormatType.CSV)
				.build();
		new Runner(opts).run();
	}

}
