



## Replication of the experiment for paper "_Regression Test Prioritization Leveraging Source Code Similarity with Tree Kernels_"

This repository contains the JAVA implementation of all the experiments performed in the paper.

### Configuration
To replicate the experiment, a complete version of the dataset should be available on the disk.

This project uses a _dotenv_ file to set up the configuration properties. It is necessary to create a _.env_ file in the _resources_ folder (or anyway available on the classpath) and set up all paths. A _.env.sample_ file is provided to ease the configuration. The easiest way to configure the project is simply copying the _.env.sample_ file, renaming it in _.env_ and then open it with a text editor and set the properties. These are:

- **DATASET.ROOT**: the _absolute_ path main folder of the dataset (e.g., _/usr/local_).
- **DATASET.FOLDERS.PROJECTS**: the _relative_ path (from _DATASET.ROOT_) of the folder in which the projects are stored (e.g., _Projects_).
- **DATASET.FOLDERS.FAULT_MATRICES**: the _relative_ path (from _DATASET.ROOT_) of the main folder in which the CSV files for the fault matrices are stored (e.g., _FaultMatrices_). 
- **EXPERIMENTS.DB.LOCATION**: the _absolute_ path for the SQLite Database to save and query the results of the experiments (e.g., _/usr/local/sqlite.db_).
- **RESULTS.FOLDER**: the _absolute_ path to the folder in which the CSV reports for the evaluated results should be stored (e.g., _/usr/share/Results_).

### Compilation
_Maven_ has been used to manage the project dependencies and its lifecycle. All the dependencies are present on the _Maven Central Repository_, except for _KeLP_ dependencies, which have a different repository already configured in the _pom.xml_. To avoid unavailability issues with these dependencies, we included KeLP _jars_ in the _libs_ folder. They can be installed locally using maven, or they can be simply put on the classpath.

### Execution
There are 5 main classes in the _it.unina.dieti.tkprio_ package:
- _DeterministicTechniques_: executes all the experiments of the strategies proposed in the paper and the deterministic baselines, excluding ART-MaxMin and Genetic. The script saves all the results in the SQLITE db specified in configuration.
- _NonDeterministicBaselines_: executes the non-deterministic techniques, i.e., ART-MaxMin and Genetic. They are executed separately due the different approach in evaluating their results due to their nondeterminism. The results are saved in the SQLITE db specified in configuration.
- _ExportCSVResults_: for each experimental pair, loads the results from the SQLITE db and converts it in CSV format, in the result folder specified in the configuration.
- _RunBenchmarks_: execute the JMH benchmarks to obtain the execution time of all the technique, for all the version pairs involved in the experimentation. The results are saved in the SQLITE db.
- _ExportBenchmarkResults_: loads the benchmark results from the SQLITE db and saves them in CSV format, in the result folder specified in the configuration.

### Architecture
The source code of the project is divided in different packages:
 - _ast_: contains the basic types to create the _Abstract Syntax Trees_ that are used by the _KeLP_ framework with the _Partial Tree Kernel_.
 - _domain_: contains the domain classes, used to model the different entities involved in the approaches, such as tests, methods and test suite permutations.
 - _io_: contains the different classes used to perform I/O operation on reports and sources. It includes classes to generate ASTs using the _GumTreeDiff_ library, analyze the source code of project, and parse coverage and test reports.
 - _rtp_: contains all the implemented strategies and the used metrics. It is subdivided in two packages:
   - _metrics_: all the source code to evaluate the metrics used in the paper.
   - _strategies_: includes _MTK_ and _QS_ approaches, as well as all the baseline techniques and all the auxiliary procedures needed to perform their execution.
 - _experiments_: abstracts all the logic to perform the experiments, to collect the metrics and to save and retrieve data from the SQLITE db.
 - _benchmarks_: contains the benchmark class to perform the analysis using the JMH framework. Classes within are loaded by the _RunBenchmark_ main class.
 - _generation_: used to extract auxiliary data, such as fault matrices and method level coverage reports from the statement level reports. These data are pre-generated and already available in the dataset. 
 - _utils_: contains some shared auxiliary function which found no place in other packages, according to the worst engineering practices... 